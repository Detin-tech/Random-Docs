📝 Tutorials
🎤 Speech To Text
🎤 Speech To Text
📄️

🗨️  Configuration
Open Web UI supports both local, browser, and remote speech to text.
📄️

Environment Variables
For a complete list of all Open WebUI environment variables, see the Environment Variable Configuration page.
Previous
💾 Backups
Next
🗨️  Configuration

---

**Related:**

- [[tutorials/speech-to-text/env-variables]]
- [[tutorials/speech-to-text/stt-config]]