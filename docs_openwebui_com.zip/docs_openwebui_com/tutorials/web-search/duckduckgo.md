📝 Tutorials
🌐 Web Search
DuckDuckGo
On this page
DuckDuckGo
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


DuckDuckGo API
​


Setup
​


No setup is required to use DuckDuckGo API for Open WebUI's built in web search! DuckDuckGo works out of the box in Open WebUI.


note
There is a possibility of your web searches being rate limited.
Edit this page
Previous
Brave
Next
Exa
DuckDuckGo API
Setup

---

**Related:**

- [[category/-web-search]]
- [[getting-started/env-configuration]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]