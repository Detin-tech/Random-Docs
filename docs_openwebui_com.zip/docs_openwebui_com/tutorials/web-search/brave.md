📝 Tutorials
🌐 Web Search
Brave
On this page
Brave
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Brave API
​


Docker Compose Setup
​


Add the following environment variables to your Open WebUI
docker-compose.yaml
 file:


services
:

open-webui
:

environment
:

ENABLE_RAG_WEB_SEARCH
:

True

RAG_WEB_SEARCH_ENGINE
:

"brave"

BRAVE_SEARCH_API_KEY
:

"YOUR_API_KEY"

RAG_WEB_SEARCH_RESULT_COUNT
:

3

RAG_WEB_SEARCH_CONCURRENT_REQUESTS
:

10
Edit this page
Previous
Bing
Next
DuckDuckGo
Brave API
Docker Compose Setup

---

**Related:**

- [[category/-web-search]]
- [[getting-started/env-configuration]]
- [[troubleshooting/microphone-error]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/duckduckgo]]