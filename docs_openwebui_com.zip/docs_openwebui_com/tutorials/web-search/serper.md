📝 Tutorials
🌐 Web Search
Serper
Serper
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.
Edit this page
Previous
SearXNG
Next
Serply

---

**Related:**

- [[category/-web-search]]
- [[getting-started/env-configuration]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serply]]