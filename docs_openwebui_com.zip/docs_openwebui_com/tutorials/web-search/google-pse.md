📝 Tutorials
🌐 Web Search
Google PSE
On this page
Google PSE
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Google PSE API
​


Setup
​




Go to Google Developers, use
Programmable Search Engine
, and log on or create account.


Go to
control panel
 and click
Add
 button


Enter a search engine name, set the other properties to suit your needs, verify you're not a robot and click
Create
 button.


Generate
API key
 and get the
Search engine ID
. (Available after the engine is created)


With
API key
 and
Search engine ID
, open
Open WebUI Admin panel
 and click
Settings
 tab, and then click
Web Search


Enable
Web search
 and Set
Web Search Engine
 to
google_pse


Fill
Google PSE API Key
 with the
API key
 and
Google PSE Engine Id
 (# 4)


Click
Save






Note
​


You have to enable
Web search
 in the prompt field, using plus (
+
) button.
Search the web ;-)


Edit this page
Previous
Exa
Next
Jina
Google PSE API
Setup

---

**Related:**

- [[category/-web-search]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/jina]]