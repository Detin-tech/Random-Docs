📝 Tutorials
🌐 Web Search
Yacy
On this page
Yacy
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Yacy API
​


Setup
​






Navigate to:
Admin Panel
 ->
Settings
 ->
Web Search






Toggle
Enable Web Search






Set
Web Search Engine
 from dropdown menu to
yacy






Set
Yacy Instance URL
 to one of the following examples:




http:[[../../index]]yacy:8090
 (using the container name and exposed port, suitable for Docker-based setups)


http:[[../../index]]host.docker.internal:8090
 (using the
host.docker.internal
 DNS name and the host port, suitable for Docker-based setups)


https:[[../../index]]<yacy.local>:8443
 (using a local domain name, suitable for local network access)


https:[[../../index]]yacy.example.com
 (using a custom domain name for a self-hosted Yacy instance, suitable for public or private access)


https:[[../../index]]yacy.example.com:8443
 (using https over the default Yacy https port)








Optionally, enter your Yacy username and password if authentication is required for your Yacy instance. If both are left blank, digest authentication will be skipped






Press save






Edit this page
Previous
SerpApi
Next
External
Yacy API
Setup

---

**Related:**

- [[category/-web-search]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/serpapi]]