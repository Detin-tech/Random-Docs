📝 Tutorials
🌐 Web Search
Mojeek
On this page
Mojeek
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Mojeek Search API
​


Setup
​




Please visit
Mojeek Search API page
 to obtain an
API key


With
API key
, open
Open WebUI Admin panel
 and click
Settings
 tab, and then click
Web Search


Enable
Web search
 and Set
Web Search Engine
 to
mojeek


Fill
Mojeek Search API Key
 with the
API key


Click
Save




Docker Compose Setup
​


Add the following environment variables to your Open WebUI
docker-compose.yaml
 file:


services
:

open-webui
:

environment
:

ENABLE_RAG_WEB_SEARCH
:

True

RAG_WEB_SEARCH_ENGINE
:

"mojeek"

BRAVE_SEARCH_API_KEY
:

"YOUR_MOJEEK_API_KEY"

RAG_WEB_SEARCH_RESULT_COUNT
:

3

RAG_WEB_SEARCH_CONCURRENT_REQUESTS
:

10
Edit this page
Previous
Kagi
Next
SearchApi
Mojeek Search API
Setup
Docker Compose Setup

---

**Related:**

- [[category/-web-search]]
- [[getting-started/env-configuration]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/searchapi]]