📝 Tutorials
🌐 Web Search
Bing
On this page
Bing
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Bing API
​


Setup
​




Navigate to the
AzurePortal
 and create a new resource. After creation, you’ll be redirected to the resource overview page. From there, select "Click here to manage keys."


On the key management page, locate Key1 or Key2 and copy your desired key.


Open the Open WebUI Admin Panel, switch to the Settings tab, and then select Web Search.


Enable the Web search option and set the Web Search Engine to bing.


Fill
SearchApi API Key
 with the
API key
 that you copied in step 2 from
AzurePortal
 dashboard.


Click
Save
.


Edit this page
Previous
🌐 Web Search
Next
Brave
Bing API
Setup

---

**Related:**

- [[category/-web-search]]
- [[getting-started/env-configuration]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/serpapi]]