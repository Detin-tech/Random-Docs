📝 Tutorials
🎨 Image Generation
On this page
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


🎨 Image Generation


Open WebUI supports image generation through three backends:
AUTOMATIC1111
,
ComfyUI
, and
OpenAI DALL·E
. This guide will help you set up and use either of these options.


AUTOMATIC1111
​


Open WebUI supports image generation through the
AUTOMATIC1111

API
. Here are the steps to get started:


Initial Setup
​






Ensure that you have
AUTOMATIC1111
 installed.






Launch AUTOMATIC1111 with additional flags to enable API access:


.[[../webui.sh]] --api --listen






For Docker installation of WebUI with the environment variables preset, use the following command:


docker run -d -p 3000:8080 --add-host=host.docker.internal:host-gateway -e AUTOMATIC1111_BASE_URL=http://host.docker.internal:7860/ -e ENABLE_IMAGE_GENERATION=True -v open-webui:[[app/backend[[../data]]]] --name open-webui --restart always ghcr.io[[open-webui/open-webui:main]]






Setting Up Open WebUI with AUTOMATIC1111
​






In Open WebUI, navigate to the
Admin Panel
 >
Settings
 >
Images
 menu.






Set the
Image Generation Engine
 field to
Default (Automatic1111)
.






In the API URL field, enter the address where AUTOMATIC1111's API is accessible:


http://<your_automatic1111_address>:7860/


If you're running a Docker installation of Open WebUI and AUTOMATIC1111 on the same host, use
http://host.docker.internal:7860/
 as your address.






ComfyUI
​


ComfyUI provides an alternative interface for managing and interacting with image generation models. Learn more or download it from its
GitHub page
. Below are the setup instructions to get ComfyUI running alongside your other tools.


Initial Setup
​






Download and extract the ComfyUI software package from
GitHub
 to your desired directory.






To start ComfyUI, run the following command:


python main.py


For systems with low VRAM, launch ComfyUI with additional flags to reduce memory usage:


python main.py --lowvram






For Docker installation of WebUI with the environment variables preset, use the following command:


docker run -d -p 3000:8080 --add-host=host.docker.internal:host-gateway -e COMFYUI_BASE_URL=http://host.docker.internal:7860/ -e ENABLE_IMAGE_GENERATION=True -v open-webui:[[app/backend[[../data]]]] --name open-webui --restart always ghcr.io[[open-webui/open-webui:main]]






Setting Up Open WebUI with ComfyUI
​


Setting Up FLUX.1 Models
​




Model Checkpoints
:






Download either the
FLUX.1-schnell
 or
FLUX.1-dev
 model from the
black-forest-labs HuggingFace page
.


Place the model checkpoint(s) in both the
models[[../checkpoints]]
 and
models[[../unet]]
 directories of ComfyUI. Alternatively, you can create a symbolic link between
models[[../checkpoints]]
 and
models[[../unet]]
 to ensure both directories contain the same model checkpoints.






VAE Model
:






Download
ae.safetensors
 VAE from
here
.


Place it in the
models[[../vae]]
 ComfyUI directory.






CLIP Model
:






Download
clip_l.safetensors
 from
here
.


Place it in the
models[[../clip]]
 ComfyUI directory.






T5XXL Model
:






Download either the
t5xxl_fp16.safetensors
 or
t5xxl_fp8_e4m3fn.safetensors
 model from
here
.


Place it in the
models[[../clip]]
 ComfyUI directory.




To integrate ComfyUI into Open WebUI, follow these steps:


Step 1: Configure Open WebUI Settings
​




Navigate to the
Admin Panel
 in Open WebUI.


Click on
Settings
 and then select the
Images
 tab.


In the
Image Generation Engine
 field, choose
ComfyUI
.


In the
API URL
 field, enter the address where ComfyUI's API is accessible, following this format:
http://<your_comfyui_address>:8188/
.




Set the environment variable
COMFYUI_BASE_URL
 to this address to ensure it persists within the WebUI.








Step 2: Verify the Connection and Enable Image Generation
​




Ensure ComfyUI is running and that you've successfully verified the connection to Open WebUI. You won't be able to proceed without a successful connection.


Once the connection is verified, toggle on
Image Generation (Experimental)
. More options will be presented to you.


Continue to step 3 for the final configuration steps.




Step 3: Configure ComfyUI Settings and Import Workflow
​




Enable developer mode within ComfyUI. To do this, look for the gear icon above the
Queue Prompt
 button within ComfyUI and enable the
Dev Mode
 toggle.


Export the desired workflow from ComfyUI in
API format
 using the
Save (API Format)
 button. The file will be downloaded as
workflow_api.json
 if done correctly.


Return to Open WebUI and click the
Click here to upload a workflow.json file
 button.


Select the
workflow_api.json
 file to import the exported workflow from ComfyUI into Open WebUI.


After importing the workflow, you must map the
ComfyUI Workflow Nodes
 according to the imported workflow node IDs.


Set
Set Default Model
 to the name of the model file being used, such as
flux1-dev.safetensors




info
You may need to adjust an
Input Key
 or two within Open WebUI's
ComfyUI Workflow Nodes
 section to match a node within your workflow.
For example,
seed
 may need to be renamed to
noise_seed
 to match a node ID within your imported workflow.


tip
Some workflows, such as ones that use any of the Flux models, may utilize multiple nodes IDs that is necessary to fill in for their node entry fields within Open WebUI. If a node entry field requires multiple IDs, the node IDs should be comma separated (e.g.
1
 or
1, 2
).




Click
Save
 to apply the settings and enjoy image generation with ComfyUI integrated into Open WebUI!




After completing these steps, your ComfyUI setup should be integrated with Open WebUI, and you can use the Flux.1 models for image generation.


Configuring with SwarmUI
​


SwarmUI utilizes ComfyUI as its backend. In order to get Open WebUI to work with SwarmUI you will have to append
ComfyBackendDirect
 to the
ComfyUI Base URL
. Additionally, you will want to setup SwarmUI with LAN access. After aforementioned adjustments, setting up SwarmUI to work with Open WebUI will be the same as
Step one: Configure Open WebUI Settings
 as outlined above.



SwarmUI API URL
​


The address you will input as the ComfyUI Base URL will look like:
http://<your_swarmui_address>:7801[[../ComfyBackendDirect]]


OpenAI DALL·E
​


Open WebUI also supports image generation through the
OpenAI DALL·E APIs
. This option includes a selector for choosing between DALL·E 2 and DALL·E 3, each supporting different image sizes.


Initial Setup
​




Obtain an
API key
 from OpenAI.




Configuring Open WebUI
​




In Open WebUI, navigate to the
Admin Panel
 >
Settings
 >
Images
 menu.


Set the
Image Generation Engine
 field to
Open AI (Dall-E)
.


Enter your OpenAI API key.


Choose the DALL·E model you wish to use. Note that image size options will depend on the selected model:




DALL·E 2
: Supports
256x256
,
512x512
, or
1024x1024
 images.


DALL·E 3
: Supports
1024x1024
,
1792x1024
, or
1024x1792
 images.








Azure OpenAI
​


Using Azure OpenAI Dall-E directly is unsupported, but you can
set up a LiteLLM proxy
 which is compatible with the
Open AI (Dall-E)
 Image Generation Engine.


Using Image Generation
​






First, use a text generation model to write a prompt for image generation.


After the response has finished, you can click the Picture icon to generate an image.


After the image has finished generating, it will be returned automatically in chat.




tip
You can also edit the LLM's response and enter your image generation prompt as the message
to send off for image generation instead of using the actual response provided by the
LLM.
Edit this page
Previous
🗨️ Openedai-speech Using Docker
Next
🌐 Web Search
AUTOMATIC1111
Initial Setup
Setting Up Open WebUI with AUTOMATIC1111
ComfyUI
Initial Setup
Setting Up Open WebUI with ComfyUI
Configuring with SwarmUI
OpenAI DALL·E
Initial Setup
Configuring Open WebUI
Azure OpenAI
Using Image Generation

---

**Related:**

- [[features]]
- [[features/code-execution/artifacts]]
- [[features/document-extraction]]
- [[features/document-extraction/docling]]
- [[features/document-extraction/mistral-ocr]]
- [[features/plugin/tools]]
- [[features/plugin/tools/development]]
- [[features/workspace/permissions]]
- [[getting-started/env-configuration]]
- [[tutorials/jupyter]]
- [[tutorials/tips/contributing-tutorial]]
- [[tutorials/tips/special_arguments]]