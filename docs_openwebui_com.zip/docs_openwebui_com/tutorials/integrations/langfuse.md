📝 Tutorials
🔗 Integrations
💥 Monitoring and Debugging with Langfuse
On this page
Langfuse Integration with Open WebUI


Langfuse
 (
GitHub
) offers open source observability and evaluations for Open WebUI. By enabling the Langfuse integration, you can trace your application data with Langfuse to develop, monitor, and improve the use of Open WebUI, including:




Application
traces


Usage patterns


Cost data by user and model


Replay sessions to debug issues


Evaluations




How to integrate Langfuse with Open WebUI
​




Langfuse integration steps


Pipelines
 in Open WebUI is an UI-agnostic framework for OpenAI API plugins. It enables the injection of plugins that intercept, process, and forward user prompts to the final LLM, allowing for enhanced control and customization of prompt handling.


To trace your application data with Langfuse, you can use the
Langfuse pipeline
, which enables real-time monitoring and analysis of message interactions.


Quick Start Guide
​


Step 1: Setup Open WebUI
​


Make sure to have Open WebUI running. To do so, have a look at the
Open WebUI documentation
.


Step 2: Set Up Pipelines
​


Launch
Pipelines
 by using Docker. Use the following command to start Pipelines:


docker run -p 9099:9099 --add-host=host.docker.internal:host-gateway -v pipelines:[[app[[pipelines]]]] --name pipelines --restart always ghcr.io[[open-webui[[pipelines]]:main]]


Step 3: Connecting Open WebUI with Pipelines
​


In the
Admin Settings
, create and save a new connection of type OpenAI API with the following details:




URL:

http://host.docker.internal:9099
 (this is where the previously launched Docker container is running).


Password:
 0p3n-w3bu! (standard password)






Step 4: Adding the Langfuse Filter Pipeline
​


Next, navigate to
Admin Settings
 ->
Pipelines
 and add the Langfuse Filter Pipeline. Specify that Pipelines is listening on
http://host.docker.internal:9099
 (as configured earlier) and install the
Langfuse Filter Pipeline
 by using the
Install from Github URL
 option with the following URL:


[[open-webui[[pipelines]]]]/blob/main/examples/filters/langfuse_filter_pipeline.py


Now, add your Langfuse API keys below. If you haven't signed up to Langfuse yet, you can get your API keys by creating an account
here
.




Note:
 Capture usage (token counts) for OpenAi models while streaming is enabled, you have to navigate to the model settings in Open WebUI and check the "Usage"
box
 below
Capabilities
.


Step 5: See your traces in Langfuse
​


You can now interact with your Open WebUI application and see the traces in Langfuse.


Example trace
 in the Langfuse UI:




Learn more
​


For a comprehensive guide on Open WebUI Pipelines, visit
this post
.
Edit this page
Previous
🕵🏻‍♀️ Monitor your LLM requests with Helicone
Next
🔠 LibreTranslate Integration
How to integrate Langfuse with Open WebUI
Quick Start Guide
Step 1: Setup Open WebUI
Step 2: Set Up Pipelines
Step 3: Connecting Open WebUI with Pipelines
Step 4: Adding the Langfuse Filter Pipeline
Step 5: See your traces in Langfuse
Learn more

---

**Related:**

- [[category/-integrations]]
- [[features]]
- [[pipelines]]
- [[pipelines/filters]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/libre-translate]]