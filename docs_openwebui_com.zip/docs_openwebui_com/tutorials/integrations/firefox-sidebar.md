📝 Tutorials
🔗 Integrations
🦊 Firefox AI Chatbot Sidebar
On this page
🦊 Firefox AI Chatbot Sidebar
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


🦊 Firefox AI Chatbot Sidebar
​


Integrating Open WebUI as a Local AI Chatbot Browser Assistant in Mozilla Firefox


Prerequisites
​


Before integrating Open WebUI as a AI chatbot browser assistant in Mozilla Firefox, ensure you have:




Open WebUI instance URL (local or domain)


Firefox browser installed




Enabling AI Chatbot in Firefox
​




Click on the hamburger button (three horizontal lines button at the top right corner, just below the
X
 button)


Open up Firefox settings


Click on the
Firefox Labs
 section


Toggle on
AI Chatbot




Alternatively, you can enable AI Chatbot through the
about:config
 page (described in the next section).


Configuring about
:config
 Settings
​




Type
about:config
 in the Firefox address bar


Click
Accept the Risk and Continue


Search for
browser.ml.chat.enabled
 and toggle it to
true
 if it's not already enabled through Firefox Labs


Search for
browser.ml.chat.hideLocalhost
 and toggle it to
false




browser.ml.chat.prompts.#
​


To add custom prompts, follow these steps:




Search for
browser.ml.chat.prompts.#
 (replace
#
 with a number, e.g.,
0
,
1
,
2
, etc.)


Click the
+
 button to add a new prompt


Enter the prompt label, value, and ID (e.g.,
{"id":"My Prompt", "value": "This is my custom prompt.", "label": "My Prompt"}
)


Repeat the process to add more prompts as desired




browser.ml.chat.provider
​




Search for
browser.ml.chat.provider


Enter your Open WebUI instance URL, including any optional parameters (e.g.,
https://my-open-webui-instance.com/?model=browser-productivity-assistant&temporary-chat=true&tools=jina_web_scrape
)




URL Parameters for Open WebUI
​


The following URL parameters can be used to customize your Open WebUI instance:


Models and Model Selection
​




models
: Specify multiple models (comma-separated list) for the chat session (e.g.,
[[../../index]]
)


model
: Specify a single model for the chat session (e.g.,
[[../../index]]
)




YouTube Transcription
​




youtube
: Provide a YouTube video ID to transcribe the video in the chat (e.g.,
[[../../index]]
)




Web Search
​




web-search
: Enable web search functionality by setting this parameter to
true
 (e.g.,
[[../../index]]
)




Tool Selection
​




tools
 or
tool-ids
: Specify a comma-separated list of tool IDs to activate in the chat (e.g.,
[[../../index]]
 or
[[../../index]]
)




Call Overlay
​




call
: Enable a video or call overlay in the chat interface by setting this parameter to
true
 (e.g.,
[[../../index]]
)




Initial Query Prompt
​




q
: Set an initial query or prompt for the chat (e.g.,
[[../../index]]
)




Temporary Chat Sessions
​




temporary-chat
: Mark the chat as a temporary session by setting this parameter to
true
 (e.g.,
[[../../index]]
)




See
[[../../features/chat-features/url-params]]
 for more info on URL parameters and how to use them.


Additional about
:config
 Settings
​


The following
about:config
 settings can be adjusted for further customization:




browser.ml.chat.shortcuts
: Enable custom shortcuts for the AI chatbot sidebar


browser.ml.chat.shortcuts.custom
: Enable custom shortcut keys for the AI chatbot sidebar


browser.ml.chat.shortcuts.longPress
: Set the long press delay for shortcut keys


browser.ml.chat.sidebar
: Enable the AI chatbot sidebar


browser.ml.checkForMemory
: Check for available memory before loading models


browser.ml.defaultModelMemoryUsage
: Set the default memory usage for models


browser.ml.enable
: Enable the machine learning features in Firefox


browser.ml.logLevel
: Set the log level for machine learning features


browser.ml.maximumMemoryPressure
: Set the maximum memory pressure threshold


browser.ml.minimumPhysicalMemory
: Set the minimum physical memory required


browser.ml.modelCacheMaxSize
: Set the maximum size of the model cache


browser.ml.modelCacheTimeout
: Set the timeout for model cache


browser.ml.modelHubRootUrl
: Set the root URL for the model hub


browser.ml.modelHubUrlTemplate
: Set the URL template for the model hub


browser.ml.queueWaitInterval
: Set the interval for queue wait


browser.ml.queueWaitTimeout
: Set the timeout for queue wait




Accessing the AI Chatbot Sidebar
​


To access the AI chatbot sidebar, use one of the following methods:




Press
CTRL+B
 to open the bookmarks sidebar and switch to AI Chatbot


Press
CTRL+Alt+X
 to open the AI chatbot sidebar directly


Edit this page
Previous
🔗 Okta OIDC SSO Integration
Next
🐳 Installing Docker
🦊 Firefox AI Chatbot Sidebar
Prerequisites
Enabling AI Chatbot in Firefox
Configuring about Settings
browser.ml.chat.prompts.#
browser.ml.chat.provider
URL Parameters for Open WebUI
Models and Model Selection
YouTube Transcription
Web Search
Tool Selection
Call Overlay
Initial Query Prompt
Temporary Chat Sessions
Additional about Settings
Accessing the AI Chatbot Sidebar