📝 Tutorials
💡 Tips & Tricks
🤝 Contributing Tutorials
On this page
warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.


Contributing Tutorials


We appreciate your interest in contributing tutorials to the Open WebUI documentation. Follow the steps below to set up your environment and submit your tutorial.


Steps
​






Fork the
openwebui[[../../docs]]
 GitHub Repository




Navigate to the
Open WebUI Docs Repository
 on GitHub.


Click the
Fork
 button at the top-right corner to create a copy under your GitHub account.








Enable GitHub Actions




In your forked repository, navigate to the
Actions
 tab.


If prompted, enable GitHub Actions by following the on-screen instructions.








Enable GitHub Pages




Go to
Settings
 >
Pages
 in your forked repository.


Under
Source
, select the branch you want to deploy (e.g.,
main
) and the folder (e.g.,
[[../../docs]]
).


Click
Save
 to enable GitHub Pages.








Configure GitHub Environment Variables




In your forked repository, go to
Settings
 >
Secrets and variables
 >
Actions
 >
Variables
.


Add the following environment variables:




BASE_URL
 set to
[[../../docs]]
 (or your chosen base URL for the fork).


SITE_URL
 set to
https:[[../../index]]<your-github-username>.github.io/
.












📝 Updating the GitHub Pages Workflow and Config File
​


If you need to adjust deployment settings to fit your custom setup, here’s what to do:


a.
Update
.github[[../../workflows/gh-pages.yml]]






Add environment variables for
BASE_URL
 and
SITE_URL
 to the build step if necessary:



-

name
:
 Build

env
:

BASE_URL
:
 $
{
{
 vars.BASE_URL
}
}

SITE_URL
:
 $
{
{
 vars.SITE_URL
}
}

run
:
 npm run build






b.
Modify
docusaurus.config.ts
 to Use Environment Variables






Update
docusaurus.config.ts
 to use these environment variables, with default values for local or direct deployment:


const
 config
:
 Config
=

{
  title
:

"Open WebUI"
,
  tagline
:

"ChatGPT-Style WebUI for LLMs (Formerly Ollama WebUI)"
,
  favicon
:

"images[[../../favicon.png"]]
,
  url
:
 process
.
env
.
SITE_URL

||

"https:/[[../open]]webui.com"
,
  baseUrl
:
 process
.
env
.
BASE_URL

||

"[[../../"]]
,

...
}
;






This setup ensures consistent deployment behavior for forks and custom setups.










Run the
gh-pages
 GitHub Workflow




In the
Actions
 tab, locate the
gh-pages
 workflow.


Trigger the workflow manually if necessary, or it may run automatically based on your setup.








Browse to Your Forked Copy




Visit
https:[[../../index]]<your-github-username>.github.io[[../../<BASE_URL]]>
 to view your forked documentation.








Draft Your Changes




In your forked repository, navigate to the appropriate directory (e.g.,
docs[[../../tutorial]]
).


Create a new markdown file for your tutorial or edit existing ones.


Ensure that your tutorial includes the unsupported warning banner.








Submit a Pull Request




Once your tutorial is ready, commit your changes to your forked repository.


Navigate to the original
open-webui[[../../docs]]
 repository.


Click
New Pull Request
 and select your fork and branch as the source.


Provide a descriptive title and description for your PR.


Submit the pull request for review.








Important
​


Community-contributed tutorials must include the the following:


:::warning
This tutorial is a community contribution and is not supported by the Open WebUI team. It serves only as a demonstration on how to customize Open WebUI for your specific use case. Want to contribute? Check out the contributing tutorial.
:::




How to Test Docusaurus Locally
You can test your Docusaurus site locally with the following commands:
npm install   # Install dependencies
npm run build # Build the site for production
This will help you catch any issues before deploying


Edit this page
Previous
💡 Tips & Tricks
Next
🔎 Open WebUI RAG Tutorial
Steps
📝 Updating the GitHub Pages Workflow and Config File
Important

---

**Related:**

- [[category/-integrations]]
- [[category/-tips--tricks]]
- [[category/-tutorials]]
- [[category/-web-search]]
- [[category/️-maintenance]]
- [[category/️-text-to-speech]]
- [[features/document-extraction/apachetika]]
- [[features/document-extraction/docling]]
- [[features/document-extraction/mistral-ocr]]
- [[tutorials/deployment]]
- [[tutorials/docker-install]]
- [[tutorials/https-haproxy]]
- [[tutorials/https-nginx]]
- [[tutorials/images]]
- [[tutorials/integrations/amazon-bedrock]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/integrations/custom-ca]]
- [[tutorials/integrations/firefox-sidebar]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/ipex_llm]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/integrations/okta-oidc-sso]]
- [[tutorials/integrations/redis]]
- [[tutorials/jupyter]]
- [[tutorials/maintenance/backups]]
- [[tutorials/s3-storage]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]
- [[tutorials/text-to-speech/kokoro-web-integration]]
- [[tutorials/text-to-speech/openai-edge-tts-integration]]
- [[tutorials/text-to-speech/openedai-speech-integration]]
- [[tutorials/tips/rag-tutorial]]
- [[tutorials/tips/special_arguments]]
- [[tutorials/tips/sqlite-database]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/duckduckgo]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/google-pse]]
- [[tutorials/web-search/jina]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/mojeek]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serpapi]]
- [[tutorials/web-search/serper]]
- [[tutorials/web-search/serply]]
- [[tutorials/web-search/serpstack]]
- [[tutorials/web-search/tavily]]
- [[tutorials/web-search/yacy]]