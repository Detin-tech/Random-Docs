⭐ Features
🛠️ Tools & Functions
🧰 Functions
🎬 Action Function
On this page
🎬 Action Function
Action functions allow you to write custom buttons to the message toolbar for end users to interact
with. This feature enables more interactive messaging, enabling users to grant permission before a
task is performed, generate visualizations of structured data, download an audio snippet of chats,
and many other use cases.


A scaffold of Action code can be found
in the community section
.


An example of a graph visualization Action can be seen in the video below.




Action
​


Actions are used to create a button in the Message UI (the small buttons found directly underneath individual chat messages).


Actions have a single main component called an action function. This component takes an object defining the type of action and the data being processed.


Example
async

def

action
(
        self
,
        body
:

dict
,
        __user__
=
None
,
        __event_emitter__
=
None
,
        __event_call__
=
None
,

)

-
>
 Optional
[
dict
]
:

print
(
f"action:
{
__name__
}
"
)
        response
=

await
 __event_call__
(

{

"type"
:

"input"
,

"data"
:

{

"title"
:

"write a message"
,

"message"
:

"here write a message to append"
,

"placeholder"
:

"enter your message"
,

}
,

}

)

print
(
response
)
Edit this page
Previous
🪄 Filter Function
Next
⚙️ Tools
Action

---

**Related:**

- [[features/plugin/events]]
- [[features/plugin/functions]]
- [[features/plugin/functions/filter]]
- [[features/plugin/tools]]
- [[features/workspace/models]]
- [[pipelines/filters]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/tips/sqlite-database]]