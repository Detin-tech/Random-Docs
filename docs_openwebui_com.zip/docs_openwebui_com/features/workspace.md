⭐ Features
🖥️ Workspace
On this page
🖥️ Workspace
The Workspace in Open WebUI provides a comprehensive environment for managing your AI interactions and configurations. It consists of several key components:


Resources
​




🤖 Models
 - Create and manage custom models tailored to specific purposes


🧠 Knowledge
 - Manage your knowledge bases for retrieval augmented generation


📚 Prompts
 - Create and organize reusable prompts




Each section of the Workspace is designed to give you fine-grained control over your Open WebUI experience, allowing for customization and optimization of your AI interactions.


Access Control
​




‍🔑 Roles
 - The roles defined in Open WebUI


‍🔐 Groups
 - Setup groups of users to share access to resources


🔒 Permissions
 - Configure access controls and feature availability




Roles, groups and permissions are designed to work together to provide a finegrained model for controlling user access to individual resources.
Edit this page
Previous
🚚 Migrating Tools & Functions: 0.4 to 0.5
Next
🤖 Models
Resources
Access Control

---

**Related:**

- [[features]]
- [[features/chat-features]]
- [[features/chat-features/chat-params]]
- [[features/chat-features/conversation-organization]]
- [[features/plugin/functions]]
- [[features/plugin/migration]]
- [[features/plugin/tools]]
- [[features/rag]]
- [[features/webhooks]]
- [[features/workspace/groups]]
- [[features/workspace/knowledge]]
- [[features/workspace/models]]
- [[features/workspace/permissions]]
- [[features/workspace/prompts]]
- [[features/workspace/roles]]
- [[getting-started/env-configuration]]
- [[tutorials/integrations/deepseekr1-dynamic]]
- [[tutorials/tips/rag-tutorial]]