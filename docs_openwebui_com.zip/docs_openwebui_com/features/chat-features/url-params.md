⭐ Features
💬 Chat Features
🔗 URL Parameters
On this page
🔗 URL Parameters
In Open WebUI, chat sessions can be customized through various URL parameters. These parameters allow you to set specific configurations, enable features, and define model settings on a per-chat basis. This approach provides flexibility and control over individual chat sessions directly from the URL.


URL Parameter Overview
​


The following table lists the available URL parameters, their function, and example usage.


Parameter
Description
Example
models
Specifies the models to be used, as a comma-separated list.
[[../../index]]
model
Specifies a single model to be used for the chat session.
[[../../index]]
youtube
Specifies a YouTube video ID to be transcribed within the chat.
[[../../index]]
web-search
Enables web search functionality if set to
true
.
[[../../index]]
tools
 or
tool-ids
Specifies a comma-separated list of tool IDs to activate in the chat.
[[../../index]]
call
Enables a call overlay if set to
true
.
[[../../index]]
q
Sets an initial query or prompt for the chat.
[[../../index]]
temporary-chat
Marks the chat as temporary if set to
true
, for one-time sessions.
[[../../index]]


1.
Models and Model Selection
​




Description
: The
models
 and
model
 parameters allow you to specify which
language models
 should be used for a particular chat session.


How to Set
: You can use either
models
 for multiple models or
model
 for a single model.


Example
:




[[../../index]]
 – This initializes the chat with
model1
 and
model2
.


[[../../index]]
 – This sets
model1
 as the sole model for the chat.








2.
YouTube Transcription
​




Description
: The
youtube
 parameter takes a YouTube video ID, enabling the chat to transcribe the specified video.


How to Set
: Use the YouTube video ID as the value for this parameter.


Example
:
[[../../index]]


Behavior
: This triggers transcription functionality within the chat for the provided YouTube video.




3.
Web Search
​




Description
: Enabling
web-search
 allows the chat session to access
web search
 functionality.


How to Set
: Set this parameter to
true
 to enable web search.


Example
:
[[../../index]]


Behavior
: If enabled, the chat can retrieve web search results as part of its responses.




4.
Tool Selection
​




Description
: The
tools
 or
tool-ids
 parameters specify which
tools
 to activate within the chat.


How to Set
: Provide a comma-separated list of tool IDs as the parameter’s value.


Example
:
[[../../index]]
 or
[[../../index]]


Behavior
: Each tool ID is matched and activated within the session for user interaction.




5.
Call Overlay
​




Description
: The
call
 parameter enables a video or call overlay in the chat interface.


How to Set
: Set the parameter to
true
 to enable the call overlay.


Example
:
[[../../index]]


Behavior
: Activates a call interface overlay, allowing features such as live transcription and video input.




6.
Initial Query Prompt
​




Description
: The
q
 parameter allows setting an initial query or prompt for the chat.


How to Set
: Specify the query or prompt text as the parameter value.


Example
:
[[../../index]]


Behavior
: The chat starts with the specified prompt, automatically submitting it as the first message.




7.
Temporary Chat Sessions
​




Description
: The
temporary-chat
 parameter marks the chat as a temporary session. This may limit features such as saving chat history or applying persistent settings.


How to Set
: Set this parameter to
true
 for a temporary chat session.


Example
:
[[../../index]]


Behavior
: This initiates a disposable chat session without saving history or applying advanced configurations.




Example Use Case
Temporary Chat Session
Suppose a user wants to initiate a quick chat session without saving the history. They can do so by setting
temporary-chat=true
 in the URL. This provides a disposable chat environment ideal for one-time interactions.


Using Multiple Parameters Together
​


These URL parameters can be combined to create highly customized chat sessions. For example:


[[../../index]]&youtube=VIDEO_ID&web-search=true&tools=tool1,tool2&call=true&q=Hello%20there&temporary-chat=true


This URL will:




Initialize the chat with
model1
 and
model2
.


Enable YouTube transcription, web search, and specified tools.


Display a call overlay.


Set an initial prompt of "Hello there."


Mark the chat as temporary, avoiding any history saving.


Edit this page
Previous
🗂️ Organizing Conversations
Next
🐍 Code Execution
URL Parameter Overview
1.
Models and Model Selection
2.
YouTube Transcription
3.
Web Search
4.
Tool Selection
5.
Call Overlay
6.
Initial Query Prompt
7.
Temporary Chat Sessions
Using Multiple Parameters Together