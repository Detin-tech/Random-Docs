⭐ Features
💬 Chat Features
On this page
Chat Features Overview


Open WebUI provides a comprehensive set of chat features designed to enhance your interactions with AI models. This page provides an overview of the key chat capabilities, with links to dedicated pages for more detailed information.


Core Chat Features
​






🗂️ Conversation Organization
: Organize chats with folders and tags to keep your workspace tidy and structured.






🔗 URL Parameters
: Configure chat sessions through URL parameters, enabling quick setup of models, tools, and other features.






⚙️ Chat Parameters
: Control system prompts and advanced parameters at different levels (per-chat, per-account, or per-model).






🗨️ Chat Sharing
: Share conversations locally or via the Open WebUI Community platform with controllable privacy settings.




Edit this page
Previous
🔑 Roles
Next
⚙️ Chat Parameters
Core Chat Features

---

**Related:**

- [[features/chat-features/chat-params]]
- [[features/chat-features/chatshare]]
- [[features/chat-features/conversation-organization]]
- [[features/chat-features/url-params]]
- [[features/workspace/roles]]