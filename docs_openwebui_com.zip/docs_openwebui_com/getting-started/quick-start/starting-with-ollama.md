🚀 Getting Started
⏱️ Quick Start
👉 Starting With Ollama
On this page
👉 Starting With Ollama
Overview
​


Open WebUI makes it easy to connect and manage your
Ollama
 instance. This guide will walk you through setting up the connection, managing models, and getting started.




Step 1: Setting Up the Ollama Connection
​


Once Open WebUI is installed and running, it will automatically attempt to connect to your Ollama instance. If everything goes smoothly, you’ll be ready to manage and use models right away.


However, if you encounter connection issues, the most common cause is a network misconfiguration. You can refer to our
connection troubleshooting guide
 for help resolving these problems.




Step 2: Managing Your Ollama Instance
​


To manage your Ollama instance in Open WebUI, follow these steps:




Go to
Admin Settings
 in Open WebUI.


Navigate to
Connections > Ollama > Manage
 (click the wrench icon).


From here, you can download models, configure settings, and manage your connection to Ollama.




Here’s what the management screen looks like:






A Quick and Efficient Way to Download Models
​


If you’re looking for a faster option to get started, you can download models directly from the
Model Selector
. Simply type the name of the model you want, and if it’s not already available, Open WebUI will prompt you to download it from Ollama.


Here’s an example of how it works:




This method is perfect if you want to skip navigating through the Admin Settings menu and get right to using your models.




All Set!
​


That’s it! Once your connection is configured and your models are downloaded, you’re ready to start using Ollama with Open WebUI. Whether you’re exploring new models or running your existing ones, Open WebUI makes everything simple and efficient.


If you run into any issues or need more guidance, check out our
help section
 for detailed solutions. Enjoy using Ollama! 🎉
Edit this page
Previous
⏱️ Quick Start
Next
🤖 Starting With OpenAI
Overview
Step 1: Setting Up the Ollama Connection
Step 2: Managing Your Ollama Instance
A Quick and Efficient Way to Download Models
All Set!

---

**Related:**

- [[getting-started/quick-start]]
- [[getting-started/quick-start/starting-with-openai]]