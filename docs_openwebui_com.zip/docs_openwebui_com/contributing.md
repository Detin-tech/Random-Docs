🤝 Contributing
On this page
🤝 Contributing
Sponsored by
Tailscale
Connect self-hosted AI to any device with Tailscale


🚀
Welcome, Contributors!
 🚀


Your interest in contributing to Open WebUI is greatly appreciated. This document is here to guide you through the process, ensuring your contributions enhance the project effectively. Let's make Open WebUI even better, together!


💡 Contributing
​


Looking to contribute? Great! Here's how you can help:


🌟 Code Contribution Guidelines
​


We welcome pull requests. Before submitting one, please:




Open a discussion regarding your ideas
here
.


Follow the project's coding standards and include tests for new features.


Update documentation as necessary.


Write clear, descriptive commit messages.




🛠 Code PR Best Practices:
​




Atomic PRs:
 Make sure your PRs are small, focused, and deal with a single objective or task. This helps in easier code review and limits the chances of introducing unrelated issues. If the scope of changes grows too large, consider breaking them into smaller, logically independent PRs.


Follow Existing Code Convention:
 Ensure your code aligns with the existing coding standards and practices of the project.


Avoid Additional External Dependencies:
 Do not include additional external dependencies without prior discussion.


Framework Agnostic Approach:
 We aim to stay framework agnostic. Implement functionalities on our own whenever possible rather than relying on external frameworks or libraries. If you have doubts or suggestions regarding this approach, feel free to discuss it.




Thank you for contributing! 🚀


📚 Documentation & Tutorials
​


Help us make Open WebUI more accessible by improving documentation, writing tutorials, or creating guides on setting up and optimizing the web UI.


🌐 Translations and Internationalization
​


Help us make Open WebUI available to a wider audience. In this section, we'll guide you through the process of adding new translations to the project.


We use JSON files to store translations. You can find the existing translation files in the
src[[lib/i18n/locale]]s
 directory. Each directory corresponds to a specific language, for example,
en-US
 for English (US),
fr-FR
 for French (France) and so on. You can refer to
ISO 639 Language Codes
 to find the appropriate code for a specific language.


To add a new language:




Create a new directory in the
src[[lib/i18n/locale]]s
 path with the appropriate language code as its name. For instance, if you're adding translations for Spanish (Spain), create a new directory named
es-ES
.


Copy the American English translation file(s) (from
en-US
 directory in
src[[lib/i18n/locale]]
) to this new directory and update the string values in JSON format according to your language. Make sure to preserve the structure of the JSON object.


Add the language code and its respective title to languages file at
src[[lib/i18n/locales/languages.json]]
.




🤔 Questions & Feedback
​


Got questions or feedback? Join our
Discord community
 or open an issue. We're here to help!


🚨 Reporting Issues
​


Noticed something off? Have an idea? Check our
Issues tab
 to see if it's already been reported or suggested. If not, feel free to open a new issue. When reporting an issue, please follow our issue templates. These templates are designed to ensure that all necessary details are provided from the start, enabling us to address your concerns more efficiently.


important




Template Compliance:
 Please be aware that failure to follow the provided issue template, or not providing the requested information at all, will likely result in your issue being closed without further consideration. This approach is critical for maintaining the manageability and integrity of issue tracking.






Detail is Key:
 To ensure your issue is understood and can be effectively addressed, it's imperative to include comprehensive details. Descriptions should be clear, including steps to reproduce, expected outcomes, and actual results. Lack of sufficient detail may hinder our ability to resolve your issue.






🧭 Scope of Support
​


We've noticed an uptick in issues not directly related to Open WebUI but rather to the environment it's run in, especially Docker setups. While we strive to support Docker deployment, understanding Docker fundamentals is crucial for a smooth experience.






Docker Deployment Support
: Open WebUI supports Docker deployment. Familiarity with Docker is assumed. For Docker basics, please refer to the
official Docker documentation
.






Advanced Configurations
: Setting up reverse proxies for HTTPS and managing Docker deployments requires foundational knowledge. There are numerous online resources available to learn these skills. Ensuring you have this knowledge will greatly enhance your experience with Open WebUI and similar projects.






🙏 Thank You!
​


Your contributions, big or small, make a significant impact on Open WebUI. We're excited to see what you bring to the project!


Together, let's create an even more powerful tool for the community. 🌟
Edit this page
Previous
🛣️ Roadmap
Next
🌐 Sponsorships
💡 Contributing
🌟 Code Contribution Guidelines
🛠 Code PR Best Practices:
📚 Documentation & Tutorials
🌐 Translations and Internationalization
🤔 Questions & Feedback
🚨 Reporting Issues
🧭 Scope of Support
🙏 Thank You!

---

**Related:**

- [[category/-integrations]]
- [[category/-tips--tricks]]
- [[category/-tutorials]]
- [[category/-web-search]]
- [[category/️-maintenance]]
- [[category/️-text-to-speech]]
- [[features/document-extraction/apachetika]]
- [[features/document-extraction/docling]]
- [[features/document-extraction/mistral-ocr]]
- [[features/evaluation]]
- [[getting-started/advanced-topics/development]]
- [[license]]
- [[roadmap]]
- [[sponsorships]]
- [[tutorials/deployment]]
- [[tutorials/docker-install]]
- [[tutorials/https-haproxy]]
- [[tutorials/https-nginx]]
- [[tutorials/images]]
- [[tutorials/integrations/amazon-bedrock]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/integrations/custom-ca]]
- [[tutorials/integrations/firefox-sidebar]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/ipex_llm]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/integrations/okta-oidc-sso]]
- [[tutorials/integrations/redis]]
- [[tutorials/jupyter]]
- [[tutorials/maintenance/backups]]
- [[tutorials/s3-storage]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]
- [[tutorials/text-to-speech/kokoro-web-integration]]
- [[tutorials/text-to-speech/openai-edge-tts-integration]]
- [[tutorials/text-to-speech/openedai-speech-integration]]
- [[tutorials/tips/contributing-tutorial]]
- [[tutorials/tips/rag-tutorial]]
- [[tutorials/tips/special_arguments]]
- [[tutorials/tips/sqlite-database]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/duckduckgo]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/google-pse]]
- [[tutorials/web-search/jina]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/mojeek]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serpapi]]
- [[tutorials/web-search/serper]]
- [[tutorials/web-search/serply]]
- [[tutorials/web-search/serpstack]]
- [[tutorials/web-search/tavily]]
- [[tutorials/web-search/yacy]]