🔨 OpenAPI Tool Servers
🔗 Open WebUI Integration
On this page
🔗 Open WebUI Integration
Overview
​


Open WebUI v0.6+ supports seamless integration with external tools via the OpenAPI servers — meaning you can easily extend your LLM workflows using custom or community-powered tool servers 🧰.


In this guide, you'll learn how to launch an OpenAPI-compatible tool server and connect it to Open WebUI through the intuitive user interface. Let’s get started! 🚀




Step 1: Launch an OpenAPI Tool Server
​


To begin, you'll need to start one of the reference tool servers available in the
openapi-servers repo
. For quick testing, we’ll use the time tool server as an example.


🛠️ Example: Starting the
time
 server locally


git clone [[open-webui[[../open]]api-servers]]
cd openapi-servers
# Navigate to the time server
cd servers[[../time]]
# Install required dependencies
pip install -r requirements.txt
# Start the server
uvicorn main:app --host 0.0.0.0 --reload


Once running, this will host a local OpenAPI server at
http:[[../../index]]:8000
, which you can point Open WebUI to.






Step 2: Connect Tool Server in Open WebUI
​


Next, connect your running tool server to Open WebUI:




Open WebUI in your browser.


Open ⚙️
Settings
.


Click on ➕
Tools
 to add a new tool server.


Enter the URL where your OpenAPI tool server is running (e.g.,
http:[[../../index]]:8000
).


Click "Save".






🧑‍💻 User Tool Servers vs. 🛠️ Global Tool Servers
​


There are two ways to register tool servers in Open WebUI:


1. User Tool Servers (added via regular Settings)
​




Only accessible to the user who registered the tool server.


The connection is made directly from the browser (client-side) by the user.


Perfect for personal workflows or when testing custom[[../local]] tools.




2. Global Tool Servers (added via Admin Settings)
​


Admins can manage shared tool servers available to all or selected users across the entire deployment:




Go to 🛠️
Admin Settings > Tools
.


Add the tool server URL just as you would in user settings.


These tools are treated similarly to Open WebUI’s built-in tools.




Main Difference: Where Are Requests Made From?
​


The primary distinction between
User Tool Servers
 and
Global Tool Servers
 is where the API connection and requests are actually made:






User Tool Servers




Requests to the tool server are performed
directly from your browser
 (the client).


This means you can safely connect to localhost URLs (like
http:[[../../index]]:8000
)—even exposing private or development-only endpoints such as your local filesystem or dev tools—without risking exposure to the wider internet or other users.


Your connection is isolated; only your browser can access that tool server.








Global Tool Servers




Requests are sent
from the Open WebUI backend[[../../s]]erver
 (not your browser).


The backend must be able to reach the tool server URL you specify—so
localhost
 means the backend server's localhost,
not
 your computer's.


Use this for sharing tools with other users across the deployment, but be mindful: since the backend makes the requests, you cannot access your personal local resources (like your own filesystem) through this method.


Think security! Only expose remote[[../global]] endpoints that are safe and meant to be accessed by multiple users.








Summary Table:


Tool Server Type
Request Origin
Use Localhost?
Use Case Example
User Tool Server
User's Browser (Client-side)
Yes (private to you)
Personal tools, local dev[[../testing]]
Global Tool Server
Open WebUI Backend (Server-side)
No (unless running on the backend itself)
Team[[../../s]]hared tools, enterprise integrations


tip
User Tool Servers are best for personal or experimental tools, especially those running on your own machine, while Global Tool Servers are ideal for production or shared environments where everyone needs access to the same tools.


👉 Optional: Using a Config File with mcpo
​


If you're running multiple tools through mcpo using a config file, take note:


🧩 Each tool is mounted under its own unique path!


For example, if you’re using memory and time tools simultaneously through mcpo, they’ll each be available at a distinct route:




http:[[../../index]]:8000[[../time]]


http:[[../../index]]:8000/memory




This means:




When connecting a tool in Open WebUI, you must enter the full route to that specific tool — do NOT enter just the root URL (
http:[[../../index]]:8000
).


Add each tool individually in Open WebUI Settings using their respective subpath URLs.






✅ Good:


http:[[../../index]]:8000[[../time]]


http:[[../../index]]:8000/memory


🚫 Not valid:


http:[[../../index]]:8000


This ensures Open WebUI recognizes and communicates with each tool server correctly.




Step 3: Confirm Your Tool Server Is Connected ✅
​


Once your tool server is successfully connected, Open WebUI will display a 👇 tool server indicator directly in the message input area:


📍 You'll now see this icon below the input box:




Clicking this icon opens a popup where you can:




View connected tool server information


See which tools are available and which server they're provided by


Debug or disconnect any tool if needed




🔍 Here’s what the tool information modal looks like:




🛠️ Global Tool Servers Look Different — And Are Hidden by Default!
​


If you've connected a Global Tool Server (i.e., one that’s admin-configured), it will not appear automatically in the input area like user tool servers do.


Instead:




Global tools are hidden by default and must be explicitly activated per user.


To enable them, you'll need to click on the ➕ button in the message input area (bottom left of the chat box), and manually toggle on the specific global tool(s) you want to use.




Here’s what that looks like:




⚠️ Important Notes for Global Tool Servers:




They will not show up in the tool indicator popup until enabled from the ➕ menu.


Each global tool must be individually toggled on to become active inside your current chat.


Once toggled on, they function the same way as user tools.


Admins can control access to global tools via role-based permissions.




This is ideal for team setups or shared environments, where commonly-used tools (e.g. document search, memory, or web lookup) should be centrally accessible by multiple users.




(Optional) Step 4: Use "Native" Function Calling (ReACT-style) Tool Use 🧠
​


info
For this to work effectively,
your selected model must support native tool calling
. Some local models claim support but often produce poor results. We strongly recommend using GPT-4o or another OpenAI model that supports function calling natively for the best experience.


Want to enable ReACT-style (Reasoning + Acting) native function calls directly inside your conversations? You can switch Open WebUI to use native function calling.


✳️ How to enable native function calling:




Open the chat window.


Go to ⚙️
Chat Controls > Advanced Params
.


Change the
Function Calling
 parameter from
Default
 to
Native
.








Need More Tools? Explore & Expand! 🧱
​


The
openapi-servers repo
 includes a variety of useful reference servers:




📂 Filesystem access


🧠 Memory & knowledge graphs


🗃️ Git repo browsing


🌎 Web search (WIP)


🛢️ Database querying (WIP)




You can run any of these in the same way and connect them to Open WebUI by repeating the steps above.




Troubleshooting & Tips 🧩
​




❌ Not connecting? Make sure the URL is correct and accessible from the browser used to run Open WebUI.


🔒 If you're using remote servers, check firewalls and HTTPS configs!


📝 To make servers persist, consider deploying them in Docker or with system services.




Need help? Visit the 👉
Discussions page
 or
open an issue
.
Edit this page
Previous
🔨 OpenAPI Tool Servers
Next
🛰️ MCP Support
Overview
Step 1: Launch an OpenAPI Tool Server
Step 2: Connect Tool Server in Open WebUI
🧑‍💻 User Tool Servers vs. 🛠️ Global Tool Servers
👉 Optional: Using a Config File with mcpo
Step 3: Confirm Your Tool Server Is Connected ✅
🛠️ Global Tool Servers Look Different — And Are Hidden by Default!
(Optional) Step 4: Use "Native" Function Calling (ReACT-style) Tool Use 🧠
Need More Tools? Explore & Expand! 🧱
Troubleshooting & Tips 🧩

---

**Related:**

- [[category/-integrations]]
- [[category/-speech-to-text]]
- [[category/-tips--tricks]]
- [[category/-tutorials]]
- [[category/-web-search]]
- [[category/️-maintenance]]
- [[category/️-text-to-speech]]
- [[contributing]]
- [[enterprise]]
- [[faq]]
- [[features]]
- [[features/banners]]
- [[features/chat-features]]
- [[features/chat-features/chat-params]]
- [[features/chat-features/chatshare]]
- [[features/chat-features/conversation-organization]]
- [[features/chat-features/url-params]]
- [[features/code-execution]]
- [[features/code-execution/artifacts]]
- [[features/code-execution/mermaid]]
- [[features/code-execution/python]]
- [[features/document-extraction]]
- [[features/document-extraction/apachetika]]
- [[features/document-extraction/docling]]
- [[features/document-extraction/mistral-ocr]]
- [[features/evaluation]]
- [[features/plugin]]
- [[features/plugin/events]]
- [[features/plugin/functions]]
- [[features/plugin/functions/filter]]
- [[features/plugin/functions/pipe]]
- [[features/plugin/migration]]
- [[features/plugin/tools]]
- [[features/plugin/tools/development]]
- [[features/rag]]
- [[features/sso]]
- [[features/webhooks]]
- [[features/workspace]]
- [[features/workspace/groups]]
- [[features/workspace/knowledge]]
- [[features/workspace/models]]
- [[features/workspace/permissions]]
- [[features/workspace/prompts]]
- [[features/workspace/roles]]
- [[getting-started]]
- [[getting-started/advanced-topics]]
- [[getting-started/advanced-topics/development]]
- [[getting-started/advanced-topics/https-encryption]]
- [[getting-started/advanced-topics/logging]]
- [[getting-started/advanced-topics/monitoring]]
- [[getting-started/advanced-topics/network-diagrams]]
- [[getting-started/api-endpoints]]
- [[getting-started/env-configuration]]
- [[getting-started/quick-start]]
- [[getting-started/quick-start/starting-with-llama-cpp]]
- [[getting-started/quick-start/starting-with-ollama]]
- [[getting-started/quick-start/starting-with-openai]]
- [[getting-started/quick-start/starting-with-openai-compatible]]
- [[getting-started/updating]]
- [[index]]
- [[license]]
- [[mission]]
- [[openapi-servers]]
- [[openapi-servers/faq]]
- [[openapi-servers/mcp]]
- [[pipelines]]
- [[pipelines/faq]]
- [[pipelines/tutorials]]
- [[roadmap]]
- [[sponsorships]]
- [[team]]
- [[troubleshooting/compatibility]]
- [[troubleshooting/connection-error]]
- [[troubleshooting/password-reset]]
- [[troubleshooting/rag]]
- [[tutorials/database]]
- [[tutorials/deployment]]
- [[tutorials/docker-install]]
- [[tutorials/https-haproxy]]
- [[tutorials/https-nginx]]
- [[tutorials/images]]
- [[tutorials/integrations/amazon-bedrock]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/integrations/custom-ca]]
- [[tutorials/integrations/deepseekr1-dynamic]]
- [[tutorials/integrations/firefox-sidebar]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/ipex_llm]]
- [[tutorials/integrations/langfuse]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/integrations/okta-oidc-sso]]
- [[tutorials/integrations/redis]]
- [[tutorials/jupyter]]
- [[tutorials/maintenance/backups]]
- [[tutorials/s3-storage]]
- [[tutorials/speech-to-text/env-variables]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]
- [[tutorials/text-to-speech/kokoro-web-integration]]
- [[tutorials/text-to-speech/openai-edge-tts-integration]]
- [[tutorials/text-to-speech/openedai-speech-integration]]
- [[tutorials/tips/contributing-tutorial]]
- [[tutorials/tips/rag-tutorial]]
- [[tutorials/tips/reduce-ram-usage]]
- [[tutorials/tips/special_arguments]]
- [[tutorials/tips/sqlite-database]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/duckduckgo]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/google-pse]]
- [[tutorials/web-search/jina]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/mojeek]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serpapi]]
- [[tutorials/web-search/serper]]
- [[tutorials/web-search/serply]]
- [[tutorials/web-search/serpstack]]
- [[tutorials/web-search/tavily]]
- [[tutorials/web-search/yacy]]