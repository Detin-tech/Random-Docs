🛠️ Troubleshooting
🌐 Browser Compatibility
On this page
🌐 Browser Compatibility
Open WebUI is designed for and tested on modern browsers. To ensure the best experience, we recommend using the following browser versions or later:


🚀 Supported Browsers
​


Open WebUI's core functionality specifically depends on these browser versions:




Chrome 111
 🟢
(Released March 2023)


Safari 16.4
 🍏
(Released March 2023)


Firefox 128
 🔥
(Released July 2024)




💡 If you experience any issues, ensure your browser is up to date or try an alternative supported browser.
Edit this page
Previous
🛠️ Troubleshooting
Next
🚧 Server Connectivity Issues
🚀 Supported Browsers

---

**Related:**

- [[faq]]
- [[features]]
- [[features/plugin/migration]]
- [[features/plugin/tools]]
- [[getting-started/advanced-topics/development]]
- [[getting-started/advanced-topics/https-encryption]]
- [[openapi-servers/faq]]
- [[roadmap]]
- [[troubleshooting]]
- [[troubleshooting/connection-error]]
- [[tutorials/database]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]