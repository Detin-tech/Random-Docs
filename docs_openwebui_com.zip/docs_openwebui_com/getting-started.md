🚀 Getting Started
On this page
🚀 Getting Started
Sponsored by
Tailscale
Connect self-hosted AI to any device with Tailscale


Welcome to the
Open WebUI Documentation Hub!
 Below is a list of essential guides and resources to help you get started, manage, and develop with Open WebUI.




⏱️ Quick Start
​


Get up and running quickly with our
Quick Start Guide
.




🛠️ Advanced Topics
​


Take a deeper dive into configurations and development tips in our
Advanced Topics Guide
.




🔄 Updating Open WebUI
​


Stay current with the latest features and security patches with our
Updating Open WebUI
 guide.




Happy exploring! 🎉 If you have questions, join our
community
 or raise an issue on
GitHub
.
Edit this page
Previous
🏡 Home
Next
⏱️ Quick Start
⏱️ Quick Start
🛠️ Advanced Topics
🔄 Updating Open WebUI

---

**Related:**

- [[features/plugin]]
- [[getting-started/advanced-topics]]
- [[getting-started/advanced-topics/development]]
- [[getting-started/advanced-topics/https-encryption]]
- [[getting-started/advanced-topics/logging]]
- [[getting-started/advanced-topics/monitoring]]
- [[getting-started/advanced-topics/network-diagrams]]
- [[getting-started/api-endpoints]]
- [[getting-started/env-configuration]]
- [[getting-started/quick-start]]
- [[getting-started/quick-start/starting-with-llama-cpp]]
- [[getting-started/quick-start/starting-with-ollama]]
- [[getting-started/quick-start/starting-with-openai]]
- [[getting-started/quick-start/starting-with-openai-compatible]]
- [[getting-started/updating]]
- [[index]]
- [[tutorials/database]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/web-search/tavily]]