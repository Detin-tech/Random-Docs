⚡ Pipelines
📖 Tutorials
On this page
Tutorials


Tutorials Welcome
​


Are you a content creator with a blog post or YouTube video about your pipeline setup? Get in touch
with us, as we'd love to feature it here!


Featured Tutorials
​


Monitoring Open WebUI with Filters
 (Medium article by @0xthresh)




A detailed guide to monitoring the Open WebUI using DataDog LLM observability.




Building Customized Text-To-SQL Pipelines
 (YouTube video by Jordan Nanos)




Learn how to develop tailored text-to-sql pipelines, unlocking the power of data analysis and extraction.




Demo and Code Review for Text-To-SQL with Open-WebUI
 (YouTube video by Jordan Nanos)




A hands-on demonstration and code review on utilizing text-to-sql tools powered by the Open WebUI.




Deploying custom Document RAG pipeline with Open-WebUI
 (GitHub guide by Sebulba46)




Step by step guide to deploy Open-WebUI and pipelines containers and creating your own document RAG with local LLM API.


Edit this page
Previous
❓ FAQ
Next
📋 FAQ
Tutorials Welcome
Featured Tutorials

---

**Related:**

- [[category/-integrations]]
- [[category/-speech-to-text]]
- [[category/-tips--tricks]]
- [[category/-tutorials]]
- [[category/-web-search]]
- [[category/️-maintenance]]
- [[category/️-text-to-speech]]
- [[contributing]]
- [[faq]]
- [[getting-started/advanced-topics/https-encryption]]
- [[getting-started/quick-start]]
- [[pipelines/faq]]
- [[troubleshooting/rag]]
- [[tutorials/database]]
- [[tutorials/deployment]]
- [[tutorials/docker-install]]
- [[tutorials/https-haproxy]]
- [[tutorials/https-nginx]]
- [[tutorials/images]]
- [[tutorials/integrations/amazon-bedrock]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/integrations/custom-ca]]
- [[tutorials/integrations/deepseekr1-dynamic]]
- [[tutorials/integrations/firefox-sidebar]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/ipex_llm]]
- [[tutorials/integrations/langfuse]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/integrations/okta-oidc-sso]]
- [[tutorials/integrations/redis]]
- [[tutorials/jupyter]]
- [[tutorials/maintenance/backups]]
- [[tutorials/s3-storage]]
- [[tutorials/speech-to-text/env-variables]]
- [[tutorials/speech-to-text/stt-config]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]
- [[tutorials/text-to-speech/kokoro-web-integration]]
- [[tutorials/text-to-speech/openai-edge-tts-integration]]
- [[tutorials/text-to-speech/openedai-speech-integration]]
- [[tutorials/tips/contributing-tutorial]]
- [[tutorials/tips/improve-performance-local]]
- [[tutorials/tips/rag-tutorial]]
- [[tutorials/tips/reduce-ram-usage]]
- [[tutorials/tips/special_arguments]]
- [[tutorials/tips/sqlite-database]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/duckduckgo]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/google-pse]]
- [[tutorials/web-search/jina]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/mojeek]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serpapi]]
- [[tutorials/web-search/serper]]
- [[tutorials/web-search/serply]]
- [[tutorials/web-search/serpstack]]
- [[tutorials/web-search/tavily]]
- [[tutorials/web-search/yacy]]