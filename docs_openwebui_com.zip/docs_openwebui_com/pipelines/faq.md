⚡ Pipelines
❓ FAQ
FAQ


What's the difference between Functions and Pipelines?


The main difference between Functions and Pipelines is that Functions are executed directly on the Open WebUI server, while Pipelines are executed on a separate server, potentially reducing the load on your Open WebUI instance.
Edit this page
Previous
⚙️ Valves
Next
📖 Tutorials

---

**Related:**

- [[faq]]
- [[features/banners]]
- [[features/plugin/events]]
- [[features/plugin/functions/filter]]
- [[features/workspace/models]]
- [[license]]
- [[openapi-servers/faq]]
- [[openapi-servers/mcp]]
- [[pipelines]]
- [[pipelines/tutorials]]
- [[pipelines/valves]]
- [[roadmap]]
- [[tutorials/text-to-speech/openedai-speech-integration]]