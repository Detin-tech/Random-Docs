👥 Our Team
On this page
👥 Our Team
Sponsored by
Warp
The intelligent terminal for developers


🌟 Meet Our Development Team!
​


Our team is led by the dedicated creator and founder,
Tim J. Baek
. Although Tim is currently the only official full-time member of the development team, we are incredibly fortunate to have a community of
amazing contributors
 who find this project valuable and actively participate in its continued success.


💓 Our Contributors
​




🏛️ Governance
​


Open WebUI is centrally managed and operated by Open WebUI, Inc. Our governance model is straightforward and intentional—we do not operate on
a committee-based governance system or a community-driven voting process
. Strategic and operational decisions are led openly and transparently by our founder, Tim J. Baek, ensuring a clear, unified, long-term vision.


Our project is specifically designed and structured to remain sustainable and independent for
decades
 to come—thanks largely to an intentional focus on remaining extremely lean, strategic, and capital-efficient. We aren't pursuing short-term milestones or temporary trends; we're carefully building something lasting and meaningful.


Beyond our contributors, Open WebUI, Inc. has an incredible global team working behind the scenes across multiple domains, including technology, operations, strategy, finance, legal, marketing, communications, partnerships, and community management. While Tim leads the vision, execution is supported by a growing network of talented individuals helping to ensure the long-term success of the project. Our team spans various expertise areas, ensuring that Open WebUI, Inc. thrives not just in software development but also in operational excellence, financial sustainability, legal compliance, brand awareness, and effective collaboration with partners.


We greatly appreciate enthusiasm and thoughtful suggestions from our community. At the same time,
we're not looking for unsolicited governance recommendations or guidance on how to operate
—we know exactly how we want to run our project (just as, for example, you wouldn't tell OpenAI how to run theirs). Open WebUI maintains strong, opinionated leadership because that's precisely what we believe is necessary to build something truly great, fast-moving, and purposeful.


If our leadership and governance style align with your views, we're thrilled to have your continued support and contributions. However, if you fundamentally disagree with our direction,
one of the key benefits of our open-source license is the freedom to fork the project and implement your preferred approach.


Thank you for respecting our perspective and for your continued support and contributions. We're excited to keep building with the community around the vision we've established together!
Edit this page
Previous
🎯 Our Mission
🌟 Meet Our Development Team!
💓 Our Contributors
🏛️ Governance

---

**Related:**

- [[category/-integrations]]
- [[category/-tips--tricks]]
- [[category/-tutorials]]
- [[category/-web-search]]
- [[category/️-maintenance]]
- [[category/️-text-to-speech]]
- [[enterprise]]
- [[faq]]
- [[features/document-extraction/apachetika]]
- [[features/document-extraction/docling]]
- [[features/document-extraction/mistral-ocr]]
- [[features/evaluation]]
- [[index]]
- [[license]]
- [[mission]]
- [[openapi-servers/open-webui]]
- [[tutorials/deployment]]
- [[tutorials/docker-install]]
- [[tutorials/https-haproxy]]
- [[tutorials/https-nginx]]
- [[tutorials/images]]
- [[tutorials/integrations/amazon-bedrock]]
- [[tutorials/integrations/browser-search-engine]]
- [[tutorials/integrations/continue-dev]]
- [[tutorials/integrations/custom-ca]]
- [[tutorials/integrations/firefox-sidebar]]
- [[tutorials/integrations/helicone]]
- [[tutorials/integrations/ipex_llm]]
- [[tutorials/integrations/libre-translate]]
- [[tutorials/integrations/okta-oidc-sso]]
- [[tutorials/integrations/redis]]
- [[tutorials/jupyter]]
- [[tutorials/maintenance/backups]]
- [[tutorials/s3-storage]]
- [[tutorials/text-to-speech/Kokoro-FastAPI-integration]]
- [[tutorials/text-to-speech/kokoro-web-integration]]
- [[tutorials/text-to-speech/openai-edge-tts-integration]]
- [[tutorials/text-to-speech/openedai-speech-integration]]
- [[tutorials/tips/contributing-tutorial]]
- [[tutorials/tips/rag-tutorial]]
- [[tutorials/tips/special_arguments]]
- [[tutorials/tips/sqlite-database]]
- [[tutorials/web-search/bing]]
- [[tutorials/web-search/brave]]
- [[tutorials/web-search/duckduckgo]]
- [[tutorials/web-search/exa]]
- [[tutorials/web-search/external]]
- [[tutorials/web-search/google-pse]]
- [[tutorials/web-search/jina]]
- [[tutorials/web-search/kagi]]
- [[tutorials/web-search/mojeek]]
- [[tutorials/web-search/searchapi]]
- [[tutorials/web-search/searxng]]
- [[tutorials/web-search/serpapi]]
- [[tutorials/web-search/serper]]
- [[tutorials/web-search/serply]]
- [[tutorials/web-search/serpstack]]
- [[tutorials/web-search/tavily]]
- [[tutorials/web-search/yacy]]