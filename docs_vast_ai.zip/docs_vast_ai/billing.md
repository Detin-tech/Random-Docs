Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Billing
20
min
 overview vast requires pre payment of credits for gpu rentals once credits are purchased, they appear in your account balance we accept credit card payments through stripe and crypto payments through crypto com and coinbase use the add credit button to purchase credits one time use the auto debt feature to have the system automatically top up your account using a saved credit card when it runs low negative balances vast does not automatically destroy your instance(s) and data once your balance reaches zero whenever your balance reaches zero or below, your instances will be stopped automatically but not destroyed that way the data is still available for you to copy off the instance since the data is still stored on the instance, you are still billed for storage on stopped instances even when your balance is negative your credit card will be automatically charged periodically to pay off any outstanding negative balance instances appearing in your account are never free auto debit (credit card only) you can set a balance threshold to configure auto debits, which will attempt to maintain your balance above the threshold by charging your card periodically we recommend setting a threshold around your daily or weekly spend, and then setting an balance email notification threshold around 75% of that value, so that you get notified if the auto billing fails but long before your balance depletes to zero there is also an optional debit mode feature which can be enabled by request for older accounts when debit mode is enabled, your account balance is allowed to go negative (without immediately stopping your instances) ⚠️ warning your card is charged automatically regardless of whether or not you have debit mode enabled instances are never free even stopped instances have storage charges make sure you delete instances when you are done with them otherwise, your card will continue to be periodically charged indefinitely update frequency balances are updated about once every few seconds credit card security vast ai does not see, store or process your credit card numbers, they are passed directly to stripe (which you can verify in the javascript) refunds after spending credits, there are absolutely no refunds for unspent credits, contact us on the website chat to request a refund in most cases we can refund unspent credits unfortunately coinbase commerce does not support refunds, so there are no refunds possible for credits purchased via coinbase commerce pricing there are separate prices and charges for active rental (gpu) (in $/hr) storage costs (in $/gb/month or total $/hr) bandwidth costs (in $/tb) you are charged the base active rental cost for every second your instance is in the active/connected state you are charged the storage cost (which depends on the size of your storage allocation) for every single second your instance exists and is online (for all states other than offline) stopping an instance does not avoid storage costs you are charged bandwidth prices for every byte sent or received to or from the instance, regardless of what state it is in the prices for base rental, storage, and bandwidth vary considerably from machine to machine, so make sure to check them you are not charged active rental or storage costs for instances that are currently offline to see a pricing breakdown on your current instances within your instance page in the console or from offers on the search page you can hover over the price to see pricing details price details payment integrations we currently support major credit cards through stripe and crypto payments through coinbase and crypto com page walkthrough in this section we will walk through the billing page you can find within the console when logged into your vast account credit balance here you can see the current amount of vast credits you have this section also shows your current credit spend given your current instances you can also view your transactions and generate invoices here credit balance payment sources in this section you can add payment methods and add credit to your account payment sources transfer credits from this section, you can fransfer your personal credits to a different account or team click the transfer credits button to open a pop up there, you can select the destination account or team to send the credit to to transfer credit to another user , you will need their email address ⚠️ this action is irreversible, so please double check the email before proceeding to transfer creadit to a team , you should be a part of the team to transfer credit from a team back to a personal account, you must be the team owner you will need to switch to your team context and open billing page form there to see following pop up invoice info here you can add the information to be shown on invoices you generate invoice filled here's an example that shows where and how the invoice info appears on generated invoices invoice with fill circle if you leave your invoice info blank it will default to your vast account's email address for the "bill to " information common questions if i rent a server and delete if after 10 minutes will i pay for 1 hour of usage or 10 minutes? you will only be charged for the 10 minutes of usage can i get a refund? if you pay with credit card you can get a refund on unspent vast credits we do not refund vast credits bought with crypto why has the prices changed? pricing is fixed by the host, and is specific to each machine and contract you can refine your search and look for a machine that suits your needs here https //cloud vast ai/create/ why am i getting the error "no such payment method id none " when i try to add credit? before buying credit with stripe you must add a card! am i charged for "loading" instances? no, you are not charged when it says "loading" if my account is negative a few $, what will happen? what happens if my vast balance is negative? it says in the billing page "you have a negative credit balance your instances are stopped and can resume once you pay the balance owed" why am i getting charge more per hour than expected? you may be see your vast credit decline at a greater rate than expected due to upload and downloads costs, which is not shown in your $ cost/hr or $cost/day pricing breakdowns as it is charged on a usage basis and not a constant rate you can find these rates for bandwidth usage in the internet section of the pricing details, which you can see when you hover over the price in the bottom right hand corner of instance cards within the instance console page you can also see pricing detail before instance creation from hovering over the prices on the search page you can also get a detailed document of your billing history by "generate billing history" within the billing page of the console why are my gpus not showing up in the list? there are over 10,000+ listings on vast, and search only displays a small subset you will usually not be able to find any one specific machine through most normal searches to test that your machine is listed correctly, you can use the cli vastai search offers 'machine id=12345 verified=any' replace 12345 with your actual machine id if your machine is verified, you should still be able to find it without the verified=any overview docid\ krijo5twhycpyhxixrhnf 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Volumes
NEXT
Earning
Docs powered by
 
Archbee
Docs powered by
 
Archbee