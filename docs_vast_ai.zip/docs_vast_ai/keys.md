Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Keys
5
min
 the keys page helps you manage secure access to your vast ai account here, you’ll find different types of keys used for authentication and connection session keys a session key is a temporary key that allows access to your vast ai account these keys are automatically created when you log in and will expire in one week however, for security reasons, it's important to review your session keys regularly you can view a list of all active session keys and see which devices are currently logged into your account if you notice any session keys that you don’t recognize, or if a device is no longer in use, you can delete those keys to immediately remove access this helps keep your account secure and ensures only your devices remain connected ssh keys you can add, edit, or remove your ssh keys in the ssh keys section of the keys page of your console add a new ssh key by clicking on the +new button copy and paste your key into the input in order for it to be attached to your account you can use this ssh key to log into instances remotely more here once the ssh key is saved, it will appear in the ssh keys section and will be automatically added to your future instances you can edit an existing ssh key by clicking on the edit button and changing the text delete an existing ssh key by selecting the delete button these ssh keys will be used primarily when accessing an instance you must switch out your ssh keys on this page if you wish to connect easily via multiple machines api keys you can view, copy, edit, and update your api keys in the keys section of the console you will need an api key to access the command line interface and the rest api to create an api key click on the +new button it will trigger api key creation pop up here, you can selet specific permissions and assign a name to the key (by default, all you account permissions are selected) you can reset an api key by clicking the reset button a new key will be automatically generated to remove a key, simply click the delete button 
Updated
 
21 Apr 2025
Did this page help you?
PREVIOUS
Settings
NEXT
CLI
Docs powered by
 
Archbee
Docs powered by
 
Archbee