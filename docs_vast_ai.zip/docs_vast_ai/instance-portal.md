Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Templates
Instance Portal
12
min
 what is the instance portal? the instance portal is the first application you will see after clicking the 'open' button to access an instance that has been loaded with a vast ai docker image many of our recommended templates include the instance portal instance card interface shows the open button loading process upon opening the instance portal you will see a loading indicator for a short time during this loading phase, a secure cloudflare tunnel will be created for each of your instance's open ports and the browser will test whether these tunnel links are accessible the secure tunnel link will be formatted like this https //four randomly selected words trycloudflare com when the secure tunnel for port 1111 becomes accessible, the instance portal will redirect to this link before revealing the full interface if it is taking too long for the tunnels to be ready, you will see the instance portal interface revealed at http //ip address\ port 1111 if you would like the default application urls to be https // rather than http // you can add the following environment variable to your account level environment variables account settings interface if you set this variable, it is important to add the vast ai jupyter certificate to your local system to avoid browser warnings see this page for more information about installing the certificate landing page the instance portal has a simple interface to help you access other web applications that may be running in the instance see the configuration section of this document for further details on application startup instance portal landing page the large blue 'launch application' buttons will open your running applications in a new browser tab if a secure tunnel is available, the button will open the 'trycloudflare com' link if a tunnel is not yet available then the button will open the direct ip address link in both cases, a secure token is appended to the link to prevent unauthorised access to your applications you can also click the 'advanced connection options' link to see all available connection methods tunnels page use this page to manage existing secure tunnels and add new tunnels to get access to ports that have not directly been opened in the instance instance portal tunnels interface use this interface to create links to applications you have started after configuring your instance for example if you started an instance but later decide that you want to install some new software that listens on port 7860 , it will not be available directly if you did not configure the port when creating or editing the template simply enter http //localhost 7860 in the top input box and click the blue 'create new tunnel' button a tunnel will be created for this port it may take a moment to be available after creation you can use the 'manage' buttons to stop existing tunnels or to refresh them if you want a new url if you would like to link your own domain name to the instance then please see 'named tunnels' in the configuration section of this document instance logs page the logs page will show a live stream of entries added to any log files in the /var/log/portal/ directory use the 'copy logs' button to copy the currently displayed logging output to your clipboard you can also use the 'download logs' button to download a zip file containing all files and directories in the /var/log/ directory of your instance instance portal logs interface tools & help page this page links to useful pages in the vast ai documentation to help you get the most from your instance instance portal tools and help page configuration initial configuration of the instance portal is via the portal config enviroment variable the default value looks like this localhost 1111 11111 /\ instance portal|localhost 8080 18080 /\ jupyter|localhost 8080 8080 /terminals/1\ jupyter terminal|localhost 8384 18384 /\ syncthing|localhost 6006 16006 /\ tensorboard each application is separated by a pipe ( | ) character, and each application option is separated by a colon ( ) for each application, we provide the following configuration options interface to bind the application (currently always localhost ) external port to proxy the application this must have been added to the template eg p 1111 1111 ) internal port where the running application will be bound url path for links to open (often / ) application name where the external port and internal port are not equal , a reverse proxy (caddy) will make your application available on the external port where the external port and internal port are equal the application will not be proxied to the external port but secure tunnel application links will be created in place configuration on first boot the configuration variable will be processed and is used to create the configuration file /etc/portal yaml you can edit this file in a running instance to add or remove applications from the interface any applications you have added after the instance has started will not initially be reachable so you will need to reboot the instance disable default applictions the startup scripts we use for the default applications we provide will read this configuration and will not start if they are not specified in the configuration file named tunnels while the default behavior of the instance portal is to create 'quick' tunnels with a randomly assigned subdomain of 'trycloudflare com', it is also possible to assign a pre configured subdomain of your own domain name to do this you will need a free cloudflare zero trust account and a domain name linked to that account here's an example of how your tunnel configuration might look in the cloudflare dashboard once you have created your named tunnel, you can link it to your instance by providing the token associated with your tunnel as the value of environment variable cf tunnel token you can save this in the 'environment variables' section in your account settings or directly in the template if you are saving it privately if the instance is already running you can provide then token in the /etc/environment file and reboot the instance named tunnels are generally more reliable than quick tunnels and will provide consistent urls you can use to access applications running in an instance when named tunnels are configured, the 'launch application' button will direct to the named tunnel rather than the quick tunnel important using the same tunnel token for multiple running instances is not possible and will cause broken links if you need several instances then you will need a separate tunnel token for each of them 
Updated
 
21 Mar 2025
Did this page help you?
PREVIOUS
Templates
NEXT
Volumes
Docs powered by
 
Archbee
Docs powered by
 
Archbee