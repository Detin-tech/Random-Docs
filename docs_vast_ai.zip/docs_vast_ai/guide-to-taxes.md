Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Hosting
Guide to Taxes
12
min
 disclaimer as an independent contractor, you are responsible for keeping track of your earnings and accurately reporting them in tax filings if you have any questions about what to report on your taxes, you should consult with a tax professional vast ai cannot provide you with tax advice nor can we verify the accuracy of any publicly available tax guidance online keep in mind vast ai does not automatically withhold taxes we calculate the subtotal of your earnings based on the date the earnings were deposited international hosts vast ai does not provide any tax documents or tax advice to hosts that reside and have their machines located outside the united states united states if you earned $600 or more in 2023 on the vast ai platform as a host, vast ai will send a 1099 misc or 1099 k form to you either through our partner stripe connect, paypal or another method if you have a question or issue, email us at contact\@vast ai mailto\ contact\@vast ai wise if you use wise to receive payments from vast ai, we will need your tax information in order to send a 1099 form here is the portal to submit your w9 tax information https //vastai app box com/f/bff8fca18a3145beb34e8075ffa5dec3 https //vastai app box com/f/bff8fca18a3145beb34e8075ffa5dec3 we will be sending emails to anyone who has not submitted tax information non compliance could result it suspending payouts once the w9 form is submitted and received, we will send out the 1099 form to the email that received payments on wise paypal paypal will issue 1099 k tax forms to all income paid through their platform for more information, see https //www paypal com/us/cshelp/article/help1131 https //www paypal com/us/cshelp/article/help1131 https //www paypal com/us/cshelp/article/help970 https //www paypal com/us/cshelp/article/help970 stripe connect for hosts paid via stripe connect, stripe will send email to collect tax information including ssn/ein and then issue a 1099 misc form by january 31st see details in the below faq the machine rental earnings will be reported as box 1 rents on the 1099 misc form stripe connect faq what is stripe express, and how do i access it? stripe express allows you to update your tax information, manage tax forms, and track your earnings if you’re working with vast ai and earned $600 or more (within the calendar year in the us), stripe will send an email inviting you to create an account and log in to stripe express which email address does stripe use to send stripe express invitations? stripe uses the email information associated with your vast ai account to send you an invitation to sign up for stripe express if you’re unable to find that email, head to this support site page where you can request a new link to be sent to your email if you still are not able to locate your invite email, please reach out to vast ai support for help updating your email address and getting a new invite email when will i receive my 1099? your 1099 tax form will be sent to you by january 31st, 2024 (note paper forms delivered by postal delivery might take up to 10 additional business days) starting november 1st, 2023 stripe will email you instructions on how to set up e delivery and create a stripe express account if you haven’t already, you’ll need to complete these steps to access your 1099 tax form electronically before mid january confirm your tax information (e g , name, address, and ssn or ein) is correct via stripe express by january 31st, 2024 your 1099 tax form will be available to download through stripe express your 1099 tax form will be mailed to you if you don’t receive an email from stripe or don’t consent to e delivery please allow up to 10 business days for postal delivery vast ai will file your 1099 tax form with the irs and relevant state tax authorities april 15, 2024 irs deadline to file taxes you’ll need your 1099 tax form to file your taxes in january, we strongly suggest that you make sure all of your tax filing details and delivery preferences are up to date in stripe express your name, address, and taxpayer identification number (social security number /employer identification number) are of primary importance i earned enough to need a 1099 form in 2023 why haven’t i received an email from stripe? if you earned enough to need a 1099 form in 2023, you should have received an email from stripe by mid january 2024 emails for pre filing confirmation will be sent out starting nov 1, 2023 this is separate from the email you’ll receive when your form is filed by the platform in january if you can’t find an email from stripe, it’s possible that the email may be in your spam/junk mail folder please search your inbox for an email titled “get your vast ai 2023 tax forms faster by enabling e delivery” vast ai does not have your most current email address on file please check any other email addresses you may have used to sign up for vast ai, or reach out to vast ai to update your email and have an invite email sent to you the email address associated with your vast ai account is incorrect, missing, or unable to receive mail you may not have received an invitation for other reasons, such as you earned less than the threshold for your form type your email address on file is incorrect, missing, or unable to receive email your specific account is unsupported on stripe express (in uncommon situations where multiple users are sharing the same account, or the same email address is being used on more than 20 accounts) will i receive a 1099 form? if you earned less than $600 over the course of the year, you may not receive a 1099 form and one won’t be generated for you unless you meet a threshold in your state if your state has a filing threshold lower than $600, you might receive a 1099 form you can check your state’s requirements here view 1099 state requirements https //stripe com/docs/connect/tax forms state requirements#check 1099 form requirements by state common questions is vat deducted for european businesses? vast is located in california we do not do anything with/about vat currently is vat specified on the invoice? vast is located in california we do not do anything with/about vat currently 
Updated
 
15 Jan 2025
Did this page help you?
PREVIOUS
Overview
NEXT
Datacenter Status
Docs powered by
 
Archbee
Docs powered by
 
Archbee