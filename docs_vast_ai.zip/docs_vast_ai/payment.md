Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Hosting
Payment
3
min
 common questions when will i get paid? it takes 2 weeks to get your first payout the pay period ends and goes pending, then you are paid for that pay period the following friday why does it show paid on my invoice when i don't see the payment in my account yet? the paid status on invoices is marked as such when we send the payment list out to paypal, wise, stripe, etc this does not accurately represent the payment's status within paypal, wise, stripe, etc , bu rather shows the status of the payment solely within our system can i generate an invoice? you can create an invoice by going to the "billing" page, and then click the box for "include charges" under "generate billing history" how much can i make hosting on vast? to get an understanding of prices, the best place is 500farms which is a third party website that monitors vast listings the link is here https //500 farm/vastai/charts/d/a6rgl05nk/vast ai stats 
Updated
 
13 Jan 2025
Did this page help you?
PREVIOUS
Datacenter Status
NEXT
Verification Stages
Docs powered by
 
Archbee
Docs powered by
 
Archbee