Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
Introduction
4
min
 vast ai vast ai is a market based cloud computing platform focused on reducing the costs and friction of compute intensive workloads, enabling anyone to easily leverage large scale gpu liquidity our software allows all compute providers large and small to easily monetize their spare capacity our search engine allows users to quickly find the best options and deals for compute services according to their specific requirements key features spin up container instances with affordable, powerful gpu in seconds easily find the best offers matching specific compute requirements tap our global liquidity to quickly scale horizontally to thousands of gpus preconfigured and custom shareable templates for one click launches auto ssh and jupyter setup for most existing images out of the box persistent storage direct data copy and cloud sync on demand and interruptible rental options (bid auction) access with our intuitive gui, python cli or direct https rest apis pick your security/trust tier both secure datacenter and community servers the best gpu instance pricing in the world how it works vast ai is a global market for cloud computing services our providers range from individual hobbyists up to tier 4 datacenters with thousands of gpus our software helps streamline and automate the hosting process while allowing providers full control over pricing and rental contract details our interface allows searching for machines based on all relevant details including gpu type, gpu ram, cpu, system ram, connectivity, etc mission vast ai's mission is to align and democratize ai machine learning is progressing towards powerful ai systems with the potential to radically reshape our future we believe it is imperative that this awesome power be distributed widely; that its benefits accrue to the many rather than the few; that its secrets are unlocked for the good of all humanity towards these ends we work to ensure that the compute powering ai is supplied by the people and for the people talk to us you can talk to our team on our support chat or via email contact\@vast ai mailto\ contact\@vast ai we staff the support chat 24/7 which is available in the bottom right corner here and on our console https //cloud vast ai/ 
Updated
 
29 May 2025
Did this page help you?
NEXT
QuickStart
Docs powered by
 
Archbee
Docs powered by
 
Archbee