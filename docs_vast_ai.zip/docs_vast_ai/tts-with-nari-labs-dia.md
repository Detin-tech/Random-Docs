Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
AI Audio Generation
TTS with Nari Labs Dia
3
min
 below is a step by step guide on how to configure and run nari labs dia 1 6b model for text to speech our template will automatically setup an easy to access web based interface to help you get started find and rent your gpu setup your vast account and add credit review the quickstart guide to get familar with the service if you do not have an account with credits loaded select the dia tts template click on temp lates and select the recomended tts template dia 1 6b tts click on the play icon to select the template you will then go to the search menu to find a gpu click on the readme link at any time for a detailed guide on how to use the template vram requirements check that your gpu vram is sufficient for the model you will need approximately 8gb vram steps to open the tts interface after the instance loads, click the "open" button this will initiate the instance portal with links to all the services running on the instance check the installation progress the tts application and model will be installed on first launch from the instance portal you can view the progress by clicking the 'instance logs' tab launch the application when the installation is complete, you can click the "dia tts interface" launch button to start the interface generate some audio once the interface has loaded, you can begin generating speech simply modify the input text, ensuring that each line is prefixed with the speaker id and then click the 'generate audio' button it will take a few seconds to generate, but once it has finished you can click the play button in the upper right to hear the results gradio application for speech generation with dia tts model if you prefer to use the cli, you can find all of the files you need in the /workspace/dia directory which you can access either via ssh or in a jupyter terminal full instructions for nari labs dia can be found in their github repository 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Linux Virtual Machines
NEXT
Ollama + Webui
Docs powered by
 
Archbee
Docs powered by
 
Archbee