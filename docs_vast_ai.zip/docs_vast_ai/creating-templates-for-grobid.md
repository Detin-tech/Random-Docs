Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
Creating a Custom Template
Creating Templates for GROBID
12
min
 introduction this guide will give an example as to how you can find and configure a template for grobid this is an extension of our create templates with custom templates we will be using the image from grobid on dockerhub find the image and tag you want to use step 1 find a suitable image there are multiple grobid images in dockerhub, but for this guide we will be using the official grobid image grobid overview step 2 selecting the version tag if you don't already have a version you intend to use, we recommend selecting the latest stable version stable tag at the time of writing, the current stable version is 0 8 0, so that is the version we'll be using here configuring the template step 1 setting your chosen image and tag in your vast ai template in the docker repository and environment section, you will enter your image path and tag imageandtag step 2 map ports and specify your image and tag combination the overview page for this image at dockerhub has a link to their guide to using grobid with containers , which you can read to get their recommendations for containerizing grobid as we follow their guide to containerizing grobid, we'll need to make sure the container's port 8070 is set to the host machine's port 8070 we will do that in the vast ai template we use p 8070 8070 as one of the docker run options run cmd note vast only allows e and p docker run options to set environment variables and expose ports grobidport step 3 select the launch mode here we will select the ssh launch mode sshdirect step 4 look for cmd or entrypoint command found tag to find this for the template we are creating, we searched the image's page in dockerhub https //hub docker com/r/grobid/grobid and found the cmd command in the tags tab under the link "0 8 0" highlighted in blue found cmd step 5 fill out on start script section using the cmd command we just found next, we add that contents of the cmd command to the end of the bash commands section of the on start script fields also, appended environment variables to /etc/environment file in our on start section this makes environment variables available to all users and processes and ensures they are persistant even if our instance/docker container is rebooted we suggest doing the same for your templates step 6 name and save the template grobidexample when you are finished setting up your template, if you haven't already done so, specify the template name and description finally, click create & use to save the template and navigate to the gpu offers search page you'll notice that your template is selected and ready to be used rent an instance using your template and open grobid web app once you have selected an instance offer, you'll click on the instances link in the left menu and see your rented gpu instance that has your template applied when the instance is done loading and the > connect state on the blue button appears, you should be able to see the ip range button at the top of the instance card if you click the ip range button you will see a new modal has the ip and port information for your instance you'll see the port 8070 that we set listed in open ports you can copy the machine ip and port and load the address (in this example 195 0 159 206 55734) in a new browser tab or window this address will load the grobid web app additional resources grobid documentation 
Updated
 
21 Feb 2025
Did this page help you?
PREVIOUS
Creating a Custom Template
NEXT
PyTorch
Docs powered by
 
Archbee
Docs powered by
 
Archbee