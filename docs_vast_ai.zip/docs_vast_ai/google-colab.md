Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
Development Tools
Google Colab
8
min
 google colab is a flavor of jupyter notebook the service is not meant to be run on cloud based gpus this guide provides a "hack" that uses ssh port forwarding so that colab detects the vast gpu instance as a local gpu and connects to the remote instance for simple notebooks, we recommend downloading the notebook from goolge colab as a ipynb file, running a vast jupyter instance with the recommended pytorch template https //cloud vast ai/?ref id=43484\&template id=f5540ef1a1398b8499546edb53dae704 and then uploading the notebook into jupyter directly jupyter by itself is much more reliable than google colab, doesn't require setting up ssh keys (you can open a terminal inside the browser), and has none of the limitations run any google colab notebook on vast colab supports a 'local runtime' option to allow people to run colab connecting to their local machine, using their own gpus this feature is intentionally restricted to allow only a localhost connection getting around that restriction requires using ssh forwarding to make a remote jupyter instance appear local known issues and limitations colab is connecting to a remote jupyter instance using ssh forwarding if you close your browser, you might not be able to re open the session to fix that you will need to stop and then restart jupyter through the ssh connection, get a new token, and then use that to reconnect to the local runtime in colab another small limitation is that there is no way (unless you get colabs pro) to open a terminal from within colab a simple jupyter vast instance doesn't have that limitation and you can always open a terminal right in the browser step 1 create a pytorch ssh instance use this colab template https //cloud vast ai/?ref id=43484\&template id=8d383ad48fff4012d42806e4781020ef that uses the common pytorch image with a direct ssh launch mode after clicking on that link, your instance configuration will be set setup an account, purchase credits and then select an appropriate gpu by clicking the "rent" button step 2 ssh into the instance our default ssh command for linux/macos already forwards port 8080 the default ssh command can be found by clicking on the connect button from a rented instance run that command you will then have an active ssh connection to the gpu instance step 2 5 windows only on windows, colab is more complicated the reason is that windows has no simple ssh client built in, unlike linux/macos one solution is to install wsl https //learn microsoft com/en us/windows/wsl/about and then use the ssh command provided on the vast instance or you can follow our windows ssh guide https //docs vast ai/windows ssh guide and use putty tools to generate your ssh keys and ssh into the instance there is one additional windows step if you use putty tools after making sure you can ssh into the instance, close the ssh connection and then modify your putty configuration to forward port 8080 to local host go to connection >ssh >tunnels in the "source port" add 8080 then in "destination" add localhost 8080 then click back to "session" and save your configuration you can then click the open button to start the windows ssh session with port 8080 forwarded to localhost step 3 run jupyter run jupyter with options like these (adjust the port 8080 to match whatever port you forwarded over ssh) jupyter notebook notebookapp allow origin=' ' port=8080 notebookapp port retries=0 allow root notebookapp allow remote access=true that will output a couple of http addresses you want to use the localhost address with the access token make sure to copy the entire string so you can paste it into your colab session step 4 connect to local runtime open google colab and hit the connect button and select the option to "connect to local runtime" paste in the localhost url from your ssh session into the box and hit connect colab will then initialize and make the connection if ssh connection drops if your ssh connection disconnects due to a network error or other reason, the google colab instance will throw an error and give you the option to reconnect the first thing to do is to reconnect via ssh to the vast instance once that is established, you can try to "reconnect" to the google colab instance, but that typically does not work the only way to re establish a connection is to stop the jupyter running on the vast instance and then restart it then you can take the new url + token and reconnect on google colab this can cause other problems to the running notebook you may or may not need to then re run all the cells of your notebook all your data will still be on the vast instance and available to be copied, even if colab cannot connect to your instance 
Updated
 
05 Mar 2025
Did this page help you?
PREVIOUS
Mining on Bittensor
NEXT
Whisper ASR Guide
Docs powered by
 
Archbee
Docs powered by
 
Archbee