Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
CLI
2
min
 this page contains some of the more commonly used cli commands for your convenience to reference for the entire list of vast cli commands visit our cli docs https //docs vast ai/api/overview and quickstart page walkthrough common questions what can i do with vast cli? just about everything! vast's cli repository is open source and we are constantly improving our cli functions! for more information about our cli visit our cli documentation https //cloud vast ai/cli/ for the comprehensive list of the current commands 
Updated
 
25 Apr 2025
Did this page help you?
PREVIOUS
Keys
NEXT
Templates
Docs powered by
 
Archbee
Docs powered by
 
Archbee