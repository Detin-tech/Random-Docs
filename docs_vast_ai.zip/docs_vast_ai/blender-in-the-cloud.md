Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
3D Rendering
Blender in the Cloud
11
min
 blender is a free, open source 3d creation suite it can be used to create animated films, visual effects, art, 3d printed models, motion graphics, interactive 3d applications, virtual reality, and video games it supports the entirety of the 3d pipeline—modeling, rigging, animation, simulation, rendering, compositing and motion tracking, even video editing and game creation you can find more information about blender at blender org https //www blender org/ animators, game developers, 3d modelers, visual effects artists, architects, and product designers are some people who use blender gpus can speed up rendering in blender step 1 open blender in the cloud template click on this link blender in the cloud template https //cloud vast ai?ref id=142678\&template id=5846e4535b1ff5db56024c1c0711a0ce to select the kasmweb/blender in the cloud template step 2 \[optional] check the secure cloud box you can narrow your search results to only data center machines if you want insured security standards from our trusted datacenters highlighted secure cloud step 3 filter for a gpu that you feel best suits your needs if you have questions about which gpu to choose, there is some data around nvidia geforce rtx 4090 giving the best render speed with blender you can find other gpus that work well with blender here blender gpu benchmarks https //opendata blender org/benchmarks/query/?group by=device name\&blender version=3 6 0 you can also find other options by searching on google or asking chatgpt the version of blender running within vast while using the template linked above at the time of this writing is 3 6 2 go to the gpus filter and check the box for rtx 4090 or another gpu instance for example, highlighted rtx 4090 filter pic step 4 choose a gpu by clicking "rent" choose a gpu that meets your budget, desired reliability %, and other constraints by clicking "rent" gpus are sorted by a complex proprietary algorithm that aims to give users the best machines for their value by default you can filter gpus further per your requirements if desired highlighted rent step 5 use jupyter direct https launch mode follow the instructions related to adding a certificate to your browser if you need to when it asks you to "setup jupyter direct https" and click "continue" here's more information on the jupyter direct https launch mode and installing the tls certificate jupyter docid 7fwrvlw rwpm3h7mmvkup updated jupyter direct https continue step 6 open blender go to the instances tab to see your instance being created with it "creating" when the message on the blue button changes to "open", click on open to open blender original open jupyter notebook here's more info about instances at vast if you need to reference it instances guide docid\ v5zbddmwmtwvghat6wnu if you see an error that says something like "'clipboard read' is not a valid value for enumeration permissionname", please close that window you should now see blender! blender in the cloud step 7 upload blend file(s) through jupyter notebook click the jupyter notebook button to open jupyter notebook jupyter notebook button go to your jupyter notebook, click the upload button on the top right, and upload one of your blend files from your local computer to a directory in the jupyter notebook in this case, i'm uploading basic particle simulation blend to the desktop directory original upload blend file to jupyter highlighted upload step 8 open blend file in blender go back to the tab where blender is running, click on file, click on open, find your file, and open it in this case, my basic particle simulation blend is in the desktop directory since that's where i uploaded it in jupyter notebook open file step 9 work on your blend file in blender! there you go! you should now able to see your blend file in blender in the cloud using vast particle simulation blend step 10 download files as needed from jupyter notebook you can save files in blender and download them by selecting the file(s) and clicking the download button in jupyter notebook highlighted file to download 
Updated
 
21 Jan 2025
Did this page help you?
PREVIOUS
Infinity Embeddings
NEXT
Blender Batch Rendering
Docs powered by
 
Archbee
Docs powered by
 
Archbee