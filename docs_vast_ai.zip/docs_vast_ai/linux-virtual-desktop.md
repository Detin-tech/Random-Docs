Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
Virtual Computing
Linux Virtual Desktop
22
min
 guide linux virtual desktop on vast ai this guide will help you set up and use a linux virtual desktop environment on vast ai using the ubuntu desktop (vm) template prerequisites a vast ai account (optional) install tls certificate for jupyter (optional) ssh client installed on your local machine and ssh public key added the keys section at cloud vast ai initial setup creating your instance navigate to the templates tab in the search bar at the top, type "ubuntu desktop (vm)" to find the template make sure you're searching across all templates and not only recommended templates select the template by clicking the play button choose your preferred gpu from the search results try to find a gpu close to you if possible click "rent" to create your instance go to instances tab and wait for the blue button on the instance card to say "open" it can take a good amount of time to load if the docker image isn't cached on the machine accessing your instance after launching your instance, you have several ways to connect browser access (recommended) click the 'open' button on your instance card to launch the instance portal choose between two browser based viewers selkies webrtc more responsive, better performance novnc alternative option if webrtc isn't working well vnc client connect using any vnc client address instance ip 5900 password your open button token ssh access connect via ssh using the command provided in the vast ai console for non root access ssh p mapped port user\@instance ip first time setup change the default password by executing the following command in linux terminal and go along with rest of the prompts \#default username user \#default password password passwd configure tls (optional) install the 'jupyter' certificate following the instance setup guide this eliminates certificate warnings in your browser features and capabilities pre installed software the environment comes with several applications ready to use web browsers firefox chrome development tools docker (pre configured for non root use) terminal emulator common development utilities creative software blender (3d creation suite) wine (windows application compatibility layer) gaming support steam (with proton compatibility for windows games) sunshine streaming server remote desktop options selkies webrtc (recommended) access via port 6100 best performance for most users hardware accelerated graphics audio support novnc access via port 6200 backup option if webrtc isn't working more compatible with different browsers vnc client traditional vnc connection use your preferred vnc client port 5900 advanced features tailscale integration install tailscale on your local device password is "password" if you haven't changed it on the instance, run sudo tailscale up follow rest of the prompts to connect to your tailnet game streaming with moonlight set up tailscale (required) configure the pre installed sunshine server connect using the moonlight client on your local device cloudflare tunnels create secure tunnels without exposing ports and having to create a new instance manage via the instance portal perfect for temporary application sharing security considerations port management the following ports are exposed by default 22 ssh 1111 instance portal 3478 turn server 5900 vnc server 6100 selkies webrtc 6200 novnc 741641 tailscale consider using tailscale for secure access creating cloudflare tunnels for http access closing unnecessary ports authentication instance portal username vastai password your open button token change the default user password immediately use ssh keys for remote access troubleshooting connection issues try different connection methods (webrtc, novnc, vnc) check if ports are accessible verify your authentication credentials performance problems ensure you're using hardware acceleration try webrtc for better performance check your internet connection quality application problems check system logs /var/log/portal/ restart caddy if needed systemctl restart caddy verify application configurations in /etc/portal yaml best practices security change default passwords immediately use tailscale or cloudflare tunnels when possible keep unnecessary ports closed performance use webrtc for best desktop performance enable hardware acceleration when available close unused applications data management keep important data backed up use version control for development monitor instance storage usage additional resources vast ai documentation tailscale documentation cloudflare tunnels 
Updated
 
05 Mar 2025
Did this page help you?
PREVIOUS
CUDA
NEXT
Linux Virtual Machines
Docs powered by
 
Archbee
Docs powered by
 
Archbee