Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Templates
16
min
 what are templates? templates help you easily set up instances, and can define the docker image, environment settings, and launch mode for your new instance for comprehensive information for how our templates work on vast, visit our template docs https //docs vast ai/instances/templates this page will not go as deep into the system but serves as a walkthrough of the gui within the console recommended as the name indicates, we recommend you select from our recommended templates when choosing a template these are vast approved and more reliable page walkthrough selecting a template if you click on the "play" button on a given template, it will set the given template as your current template and will take you to the console's search page https //docs vast ai/search editing a template if you click on the "edit" button, the template editor https //docs vast ai/instances/templates will open for the given template there you can edit settings and customize the template template editor the template editor is a convenient gui for controlling all your template's settings docker repository and environment this section of a template allows you to set the docker image, tag of the image, and the docker options repoandenv you can currently set 3 types of docker create/run options in the gui and cli environment variables " e jupyter dir=/ e test=ok" hostname " h billybob" ports " p 8081 8081 p 8082 8082/udp p 70000 70000" for more information, visit our docker execution environment docs https //docs vast ai/instances/docker execution environment launch mode the launch mode allows you to define how you are going to connect to your instance for our comprehensive documentation on launch mode options you can visit our launch mode docs https //docs vast ai/instances/launch modes launchmode jupyter for this launch option we setup a jupyter using a proxy and or direct connections where appropriate (mapping to port 8080 internal) for jupyter direct https to work, you must ensure you have loaded our tls certificate for more information on how to set this up, check out our jupyter docs https //docs vast ai/instances/jupyter ssh (both direct and proxy) for this launch option we setup an ssh connection using proxy and or direct connections where appropriate (mapping to port 22 internal) if the machine supports open ports our system will try to setup both a direct ssh connection and a backup proxy connection for more information on ssh/scp, visit our docs https //docs vast ai/instances/sshscp on it docker entrypoint this allows you to configure a docker run command with a normal entrypoint process, instead of setting up ssh and remote access unless you know you intend to use a docker entrypoint, you probably want the ssh launch type with an onstart script for windows users, read our windows guide https //docs vast ai/windows ssh guide on how to use putty tools to ssh into a vast instance on start script for both jupyter and ssh launch modes, you can paste in a script that will run bash commands after the machine starts add a semicolon ; at the end of each command onstart extra filters here you can set specific filters that will be applied on the search page https //docs vast ai/search results extrafilters docker repository authentication dockerrepo identification and disk space id with the slider you can set the disk space for your instance it is important to estimate how much disk you will need and then to move the slider to the desired disk size the default disk size for an instance is 10gb when the instance is created, the disk size is set and cannot be modified providers charge for disk allocation even when the instance is stopped accessibility and cli command cli accessibility this portion of the template editor is for you to include information and also set the template to be public if you'd like you can earn referral credits with your public templates via the referral program https //docs vast ai/referral program cli command within the template editor, at the bottom it displays the equivalent cli command for the given template with it's current state although within our gui, when selecting your template everything will be taken care of for you, this can give you visibility if you want to know how to create an instance in cli in the future or if you would like to run the equivalent command in cli vm templates templates using docker image tags from the docker io/vastai/kvm repository automatically launch vms on machines that support vms add vms enabled=true to the extra filters field of the template to filter for machines that support vms vm images must be specified using the fully qualified server/organization/repo name currently available vm images are (a recommended template is provided for each image) image (recommended template link) available launch modes description provides use cases notes docker io/vastai/kvm\ ubuntu terminal ( link https //cloud vast ai/?template id=e2f271ce754aeef772181fbf9c82a354 ) direct ssh a ubuntu 22 04 server vm cuda, docker serving docker compose applications; cuda performance profiling will refuse to start without ssh pubkeys set; ssh pubkeys will not be able to be changed while instance is running env variables will be written to /etc/environment and may need to be sourced by onstart onstart script will need interpreter specified via shebangs the table below lists some of the differences between vm and docker based instances feature docker vm systemd/docker/snap not supported supported ptrace not supported supported disk usage/performance smaller initial disk footprint larger initial disk footprint common questions can i change my template on an existing instance? you can't change existing instances templates are recipes for new instances, so any changes to a template only effect new instances can i increase/decrease my disk space on my instance? no, you can't change existing instances disk space 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
CLI
NEXT
Instance Portal
Docs powered by
 
Archbee
Docs powered by
 
Archbee