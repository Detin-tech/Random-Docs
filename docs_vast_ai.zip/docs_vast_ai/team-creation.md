Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Team Creation
4
min
 a note on legacy team creation originally, the process of creating a team involved converting a user's personal account into a special team account this has now been updated so that, users can create teams within the vast ai platform that are completely separate from their personal account this document explains the key aspects of the new process and its implications for team management and access implications of team account creation switching between context users can switch between their personal and team accounts via the context switcher, making it easier to manage multiple environments dedicated team credit and balance team accounts now have their own separate credit and balance, distinct from personal accounts this ensures that billing and resource allocation are independent between personal and team activities role based access for team members when new members are added to the team, they are granted access to the shared team account based on the role assigned to them the roles themselves determine their level of access/control over the team's resources actions made in the team context are applied to the team as whole considerations clear communication with team members ensure that all team members are aware of the nature of the team account and their respective roles and permissions no ownership transfer mechanism currently, there is no feature to change the ownership of the team the original creator of the team will remain the owner for the duration of the team account's existence until this functionality is added plan for team management since team ownership cannot yet be transferred, please plan accordingly for long term management and control of the team account by introducing separate team accounts, vast ai is providing users with greater flexibility in managing both personal and team based projects, ensuring a clearer distinction between individual and shared resources reminders for legacy team accounts irreversible process once a user account has been converted into a team account, the change is permanent and cannot be reversed inheritance of account attributes the converted team account inherits all aspects of your existing personal account, including billing information, cloud services, and any other account settings 
Updated
 
28 Apr 2025
Did this page help you?
PREVIOUS
Edit team
NEXT
Teams Invitations
Docs powered by
 
Archbee
Docs powered by
 
Archbee