Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Introduction
5
min
 what is the console? the vast console is our web application that is a user interface for using vast on it you can search avaliable machines, manage your instances, browse templates, view and edit your account information, purchase credit for using vast, and much more many of this functionality within the console can also be performed with our cli commands https //docs vast ai/api/overview and quickstart page walkthrough getting to the console from our website from our website you can click on the 'console' or 'get started' button to access our console intro 1 from here, you can view some of our features such as the search and templates pages, but some of our console pages you will need to be signed into an account to access creating an account creating a vast account is super easy, and you have a couple different sign in options available currently we support email/password, google account sign on, and github account sign on methods common questions do i need to use the console? no, you should be able to use vast via the cli if you prefer you refer to our cli commands https //docs vast ai/api/overview and quickstart for more on this the console is for your convenience as a vast user what is this section of the docs for? this section is for walking through the console pages and answering many common questions users ask about the different aspects of your vast account 
Updated
 
21 Apr 2025
Did this page help you?
PREVIOUS
Create Your Own Multi-Node Cluster
NEXT
Settings
Docs powered by
 
Archbee
Docs powered by
 
Archbee