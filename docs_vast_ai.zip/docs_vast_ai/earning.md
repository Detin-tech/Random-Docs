Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Earning
4
min
 overview this page in the console allows customers to deal with their earnings from referrals you can find more information about vast's referral program here https //docs vast ai/referral program pages walkthrough the earnings page gives you a transparent view of your referral program performance and accumulated rewards here’s what each section means current balance this is the amount you’ve earned so far from your referred users but haven’t been paid out yet it keeps growing as your referrals continue to use the platform total earnings this shows your lifetime earnings the total amount you’ve earned from all your referrals since you joined the earnings program or started hosting it includes both paid and unpaid amounts total referral count this number represents the total users you’ve referred who have successfully created accounts through your referral link it’s a great way to track how your outreach is growing! total rental earnings (host only) this shows the total lifetime amount you’ve earned from your machine being rented out on the platform total referral earnings (host only) this shows the total lifetime amout you've earned from all your referrals additionally, there is the earning chart section that provides a clear visual overview of your earning history the template performance chart displays the earnings hystory from templates payouts you can view your payout history for a selected date range here you can generate and download invoices for your earning payouts in the payout account section, you can set up a payout account common questions how can i have earnings as a vast user? you can generate earnings by gaining vast credit through template creaton via our referral program you can find more information about vast's referral program here https //docs vast ai/referral program 
Updated
 
22 Apr 2025
Did this page help you?
PREVIOUS
Billing
NEXT
Instances Guide
Docs powered by
 
Archbee
Docs powered by
 
Archbee