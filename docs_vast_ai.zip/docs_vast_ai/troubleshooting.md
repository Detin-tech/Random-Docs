Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
FAQ
Troubleshooting
6
min
 i stopped my instance, and now when i try to restart it the status is stuck on "scheduling" what is wrong? when you stop an instance, the gpu(s) it was using may get reassigned when you later then try to restart the instance, it tries to get those gpu(s) back that is the "scheduling" phase if another high priority job is currently using any of the same gpu(s), your instance will be stuck in "scheduling" phase until the conflicting jobs are done we know this is not ideal, and we are working on ways to migrate containers across gpus and machines, but until then we recommend not stopping an instance unless you are ok with the risk of waiting a while to restart it " all my instances keep stopping, switching to inactive status, even though i didn't press the stop button what's going on? check your credit balance if it hits zero or below, your instances will be stopped automatically i keep getting this error spend rate limit what's going on? there is a spend rate limit for new accounts the limit is extremely small for unverified accounts, so make sure to verify your email the limit increases over time, so try a cheaper instance type or wait a few hours if you are still having trouble, use the online support chat in the lower right i tried to connect with ssh and it asked for a password what is the password? there is no ssh password, we use ssh key authentication if ssh asks for a password, typically this means there is something wrong with the ssh key that you entered or your ssh client is misconfigured on ubuntu or mac, first you need to generate an rsa ssh public/private keypair using the command ssh keygen t rsa next you may need to force the daemon to load the new private key, and confirm it's loaded ssh add; ssh add l then get the contents of the public key with cat / ssh/id rsa pub copy the entire output to your clipboard, then paste that into a new ssh key in your keys section the key text includes the opening "ssh rsa" part and the ending "user\@something" part if you don't copy the entire thing, it won't work example ssh key text ssh rsa aaaab3nzac1yc2eaaaadaqabaaabaqddxwwxwn5lz7ubkmrxm5fchhvzonzult5fhi7j8zfxcjhfr96w+ccbobo2rtbbttrdlnjjisklgbcc3+jgyzhpunmfrvij7meqdehghfvuuv/ubkb7rjbyyfcb4bcsyngguzkmnnongea3aqtbszt47bnugqqszs9bfdcapftr9wo0b8p4iyil/gfoybkusvwkqrbcwrg53/+t2rak/02mwnhxybktjau1q7qtwcyo68jtdd0sa+4apsu+csjmbjs3fcddral3bcpikwrbckq+n6sol4xdv3zqrebuc98cjph04gnc41w02lmdqgl2xg5u/rv8/jm7cawkiiz3dbkv bob\@velocity 
Updated
 
05 Mar 2025
Did this page help you?
PREVIOUS
Networking
NEXT
Data Movement
Docs powered by
 
Archbee
Docs powered by
 
Archbee