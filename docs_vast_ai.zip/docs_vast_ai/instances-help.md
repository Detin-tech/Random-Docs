Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
FAQ
Instances Help
9
min
 how can i restart my programs once the instance restarts? if you use the "custom command" option, then your command will run automatically when the instance starts up however, if you are using an ssh instance, there is no default startup command you can put startup commands in "/root/onstart sh" this startup script will be found and run automatically on container startup i see my instance has a lifetime what does that mean? every instance offer on the create page has a max duration when you accept an offer and create an instance, this max duration becomes the instance lifetime and begins ticking down when the lifetime expires, the instance is automatically stopped the host can extend the contract, which will add more lifetime to your instance, or they may not it's up to them assume your instance will be lost once the lifetime expires; copy out any important data before then how can i set environment variables? use the e docker syntax in the docker create/run options for example, to set the env variables tzc to utc and taskid to "test" e tz=utc e taskid="test" any environment variables you set will be visible only to your onstart script (or your entrypoint for entrypoint launch mode) when using the ssh or jupyter launch modes, your env variables will not be visible inside your ssh/tmux/jupyter session by default to make custom environment variables visible to the shell, you need to export them to /etc/environment add something like the following to the end of your onstart to export any env variables containing an underscore ' ' env | grep >> /etc/environment; or to export all env variables env >> /etc/environment; environment variables can also be set in the user account settings page, in which case the env variables will be injected into every container onstart how can i get the instance id from within the container? the environment variable vast containerlabel is defined in the container ex root\@c 38250 $ echo $vast containerlabel c 38250 how can i stop the instance from within the instance? a special instance api key should already be installed in your container you can just install the vastai cli and use the stop command root\@c 38250 $ pip install vastai; then test it by starting the instance (which is a no op as the instance is already running) vastai start instance $container id; if that works then you can stop the instance as well vastai stop instance $container id; if $container id is not defined check your environment variables using the 'env' command if you are missing the predefined env variables from an ssh session you may need to add a command to export them to /etc/environment (see above) if you don't have the instance api key for whatever reason, you can also generate it first run the following from inside the instance to create a special per instance api key and save it in the appropriate location cat / ssh/authorized keys | md5sum | awk '{print $1}' > ssh key hv; echo n $vast containerlabel | md5sum | awk '{print $1}' > instance id hv; head c 1 q ssh key hv instance id hv > / vast api key; then install the cli with pip or download latest from github apt get install y wget; wget https //raw\ githubusercontent com/vast ai/vast python/master/vast py o vast; chmod +x vast; how can i launch another docker container from within the instance? vast currently does not currently support docker within docker due to security constraints you will need to launch each docker container on a separate instance 
Updated
 
05 Mar 2025
Did this page help you?
PREVIOUS
FAQ
NEXT
Billing Help
Docs powered by
 
Archbee
Docs powered by
 
Archbee