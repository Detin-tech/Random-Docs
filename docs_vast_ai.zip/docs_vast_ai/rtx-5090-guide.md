Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Specific GPUs
RTX 5 Series
4
min
 renting rtx 5 series gpus (5090/5080/5070) our recomended templates don't require cuda 12 8 we therefore have created some custom templates that ensure cuda compatability for these cards rtx 5 series template links base cuda image cuda 12 8 base image pytorch image pytorch for 5 series open webui cuda 12 8 + pytorch 2 7 0 comfyui cuda 12 8 + pytorch 2 7 0 nvidia rapids 25 04a + cuda 12 8 pytorch ngc 25 02 + cuda 12 8 tensorflow ngc 25 02 tf2 + cuda 12 8 steps to rent an rtx 5090 on vast ai create / log in to your vast ai account go to cloud v ast ai https //vast ai and either create a new account or log in select the one of the templates linked above the template will automatically filter out machines that don't support cuda 12 8 select the 5 series gpu in the gpu drop down menu select the specific 5 series card you want to rent or select the whole category review and customize set your storage and further refine your search filters (e g , secure cloud, location, system ram, cpu, etc ) but do not change the docker image because you need to maintain cuda 12 8 and the dev version of pytorch if you switch to an incompatible docker image, you may lose 5 series compatibility select and rent click “rent” next to your preferred server you can now launch jupyter notebooks, ssh into the instance, or start your own training jobs using the pre installed cuda 12 8 / pytorch dev environment tips and troubleshooting check cuda version if you manually change the docker image, ensure it’s compiled for cuda 12 8 or else you may lose compatibility with these gpus stay up to date new pytorch releases (especially nightlies / dev builds) often update their cuda support if you need a stable release, confirm that the docker image tags match a stable version with cuda 12 8 use custom docker if you have your own docker image, you must ensure it is built with cuda 12 8 (and ideally tested on a gpu supporting that version) 
Updated
 
14 Mar 2025
Did this page help you?
PREVIOUS
Members
Docs powered by
 
Archbee
Docs powered by
 
Archbee