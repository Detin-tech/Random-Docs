Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
AI Image Generation
Stable Diffusion
9
min
 stable diffusion is a deep learning, text to image model that has been publicly released it uses a variant of the diffusion model called latent diffusion there are a few popular open source repos that create an easy to use web interface for typing in the prompts, managing the settings and seeing the images this guide will use the webui github repo maintained by automatic111 here https //github com/automatic1111/stable diffusion webui the docker image used comes pre loaded with stable diffusion v2 1, and it is possible to upload other models once you have the instance up and running the recommend template will also setup jupyter so you can use a web browser to download and upload files to the instance for all questions or issues with the web gui, the project has a readme https //github com/automatic1111/stable diffusion webui with links 1\) setup your vast account the first thing to do if you are new to vast is to create an account then head to the billing tab and add credits this is pretty self explanatory vast uses stripe to processes credit card payments and also accepts major cryptocurrencies through crypto com $20 should be enough to start you pre buy credits on vast and then spend them down 2\) pick the webui template click on the change template button from the create page then click on the edit button on the stable diffusion template we will need to set a username and password, so it is very important that we edit our template to set a username and password first stablediffusionedit 3\) set your username and password if you do not set up a username and password it will default the login to username user & password password to set your username and password, go to the beginning of the docker options and add the arguments e web user=your username e web password=your password as shown below stablediffusionoptions you can also add the variables one by one in the env input stablediffusionenv 4\) pick a gpu offer stable diffusion can only run on a 1x gpu so select 1x from the filter menu on the top nav this will then update the interface to show 1x gpu offers note that some stable diffusion models require large amounts of gpu vram for max settings, you want more gpu ram use the gpu ram slider in the interface to find offers with over 20gb we recommend an a6000, a40 or a100 if you want to max the stable diffusion settings spaces mgwtdaam0bo2skpvyo6q uploads pyphz4oz3m2fz8kwl7wo stable diffusion gpu selection if available, it is also best to pick a host with the datacenter label, as those machines are more reliable click the blue rent button to spin up the instance you can then watch progress from the instance tab 5\) connect and start making art the instance can take 3 5 minutes to start once it is ready a blue connect button will appear click on that to open the web gui ⚠️ warning the web gui can take an additional 1 2 minutes to load if you click on the connect button and get a blank page or error, simply wait 1 2 minutes and reload the page and there you go! please read the automatic111 documentation https //github com/automatic1111/stable diffusion webui for how the web gui works there are buttons to save and download the artwork, and also to zip it up spaces mgwtdaam0bo2skpvyo6q uploads klcmg0mgpmu9bmipwvsv stable diffusion working 6\) upload other model checkpoints the recommended template has both ssh and jupyter https launch modes enabled to upload a model checkpoint, the simplest way is to click on the jupyter button on the instances card to open jupyter and then to upload the ckpt file to the /workspace/stable diffusion webui/models/stable diffusion directory the jupyter https launch mode will require you to install a certificate on your local machine on macos, this is not optional windows and linux will show an error if the cert is not installed but there is a way to click through the error to install the jupyter certificate for vast, follow the instructions here https //docs vast ai/instances/jupyter to use ssh, you will need to create an ssh key and upload the public portion to vast learn more here https //docs vast ai/instances/sshscp for linux/macos users, scp will also work 7\) done? destroy the instance after you generate your artwork and are done with the instance, you have a few options if you stop the instance using the stop button, you will no longer pay the hourly gpu charges however you will still incur storage charges because the data is still stored on the host machine when you hit the start button to restart the instance, you are also not guaranteed that you can rent the gpu as someone else might have rented it while it was stopped we don't recommend that you stop an instance once done to incur no other charges you have to destroy the instance using the trash can icon we recommend you destroy instances so as not to incur storage charges while you are not using the system have fun! 
Updated
 
21 Jan 2025
Did this page help you?
PREVIOUS
Image Generation
NEXT
Disco Diffusion
Docs powered by
 
Archbee
Docs powered by
 
Archbee