Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Hosting
Verification Stages
5
min
 verification follows a transition flow like this unverified > verified > deverified > unverified > verification is mostly for higher end machines, mining rigs may never be verified right now the only machines which can expect fast verification are $10k+ h100 or a100 80gb if you have a higher end machine that is not tested quickly in a day or so let us know 8x4090, 4xa6000 should be tested in less than a week, especially if you have a number of them for machines that are not high end machines or machines from datacenters, verification is relatively random even if your unverified machine is meeting these requirements we run more random auto verification roughly about once a week the only manual verification tests are for datacenters and high end machines for datacenter partner inquiries email us at contact\@vast ai mailto\ contact\@vast ai directly you can use the vast cli "self test machine" command to see if a machine meets all of the requirements, resolve any issues, and have a better chance of getting verified unverified these are typically new machines that have not been tested by vast's team/software in order for your unverified machine to be verified, it must follow these minimum guidelines ubuntu 18 04 or newer (required) dedicated machines only the machine shouldn't be doing other stuff while rented fast, reliable internet at least 10mbps per machine 10 series nvidia gpu or mi25 or newer radeon instinct series gpu or radeon vii or radeon pro vii or radeon rx 7900 (gre/xt/xtx); or radeon pro w7900/w7800 other 6000 series or newer radeon rx/pro w series gpus may be supported; but may not be searchable using standard filters for amd rocm at least 1 physical cpu core (2 hyperthreads) per gpu your cpu must support avx instruction set (not all lower end cpus support this) at least 4gbm of system ram per gpu fast ssd storage with at least 128gb per gpu at least 1x pcie for every 2 5 tflops of gpu performance all gpus on the machine must be of the same type an open port range mapped to each machine the ideal machine will exceed these minimum guidelines, as some workloads require even more cpu, ram, disk, and pcie performance also keep in mind that everything scales with gpu power, so a 3090 will need more ram, a better cpu, etc, than a 3060 note that changing components that degrade machine performance (e g, decreasing the number of gpus, ram capacity, etc) is not supported after the machine is created, and will result in the machine being deverified upgrading the machine is ok (e g, increasing the number of gpus, ram capacity, etc), but it will take some time before the change is reflected in search in order for your unverified machine to be verified, it must also meet the following minimum requirements cuda version greater than or equal to 12 0 reliability of 90% at least 3 open ports per gpu (100 recommended) internet download speed of 500 mb/s internet upload speed of 500 mb/s gpu ram of 7 gb verified if you've been verified by meeting those minimum requirements and having your machine being randomly selected or having higher end machine(s) or datacenter(s), continue to meet these requirements and try to prevent the issues listed in the deverified section of this guide deverified your machine could go from verified > deverified if an error in your machine is autodetected if you see a red error on your machine card, you should try to investigate and resolve that because it could get you deverified some issues that could get your machine deverified are issues with a container starting in your machine, nvidia smi related errors, nvml errors, nvidia container cli device errors, or issues with verifying the bandwidth of your machine if the issue is resolved, then your machine will go from deverified > unverified 
Updated
 
18 Feb 2025
Did this page help you?
PREVIOUS
Payment
NEXT
VMs
Docs powered by
 
Archbee
Docs powered by
 
Archbee