Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Volumes
10
min
 vast ai offers docker volumes for use with docker instances what is a volume? a volume is a contract between a client and a host for a set amount of space on a machine it can be attached to one or more instances on that machine, and updates to the volume are available on all instances the volume is attached to if an instance is destroyed, the volume persists with all data, and can be attached to new instances this makes it easier to download large models or datasets and recreate instances quickly, without the need to redownload all the data again how can i create a volume? to create a volume, you can use the vast cli see our cli documentation for set up and usage of the cli you can search for volume offers using the command vastai search volumes there is a modified list of search params available, for more information, you can add the help option to the search this will bring up a list of available volume offers you will be able to see the maximum capacity for the volume (in gigabytes) just like creating an instance, you can copy the offer id and create a volume with the command vastai create volume \<offer id> s \<volume size> n \<name> this will send a command to the host machine to allocate the given space to your volume you can optionally specify a name with n, it can be alphanumeric with underscores, with a max length of 64 if all goes well, you should be able to see your volume as created when you run the command vastai show volumes how can i use a volume? now that your volume is created, you can use it by creating an instance on the machine with the volume, and passing the volume in the env argument the format is v \<volume name> \<mount point>, for example vastai create instance 874 image pytorch/pytorch env ' v v 881 /mnt' disk 30 ssh direct that command mounts your volume at the directory /mnt the directory does not need to exist in order to be mounted can i use my volume on a different machine? you can't directly use the same volume on a different machine, but you can clone the volume to a machine that has an available volume contract the clone command will create a new volume contract on the new machine, provision the volume, and copy all existing data from the existing volume to the new volume to clone a volume, you can use the command vastai clone volume \<existing volume id> \<dest contract id> where \<dest contract id> is a volume offer of at least the size of your existing volume the volumes are independent and do not sync data after the clone is completed any changes that occur (on either) volume after the volume is successfully cloned will not be reflected on the other volume how can i delete my volume? when you're done using it, you can delete your volume using the command vastai delete volume \<volume id> this will only work if all instances using the volume have been destroyed how can i see what instances are using my volume? the command vastai show volumes will display a list of volumes you own, as well as what instances exist that are using that volume a machine with my volume went offline! am i still being charged? just like with normal instances, you are never charged when a machine is offline this is usually a temporary issue, and when the machine comes back online, volume charges will resume as normal if you wish to delete the volume in the meantime, you can do so, and you will not be charged when the machine comes back online if the machine is offline for an extended period of time, please reach out to vast support can i use my volume with a vm instance? at this time, volumes are only supported for docker instances, and cannot be used with vm instances 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Instance Portal
NEXT
Billing
Docs powered by
 
Archbee
Docs powered by
 
Archbee