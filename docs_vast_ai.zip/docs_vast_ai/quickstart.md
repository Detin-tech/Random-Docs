Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
QuickStart
7
min
 1\) create account & add credit before you can rent a machine on vast ai, you will need to setup an account and add a method of funding go to the billing page of the console and click on the create account link to setup a username and password you will need to add credits to your account before you can rent an instance click on the add credit button to see the billing options adding a credit card is the simplest method crypto payments through crypto com and coinbase are also supported you can select an initial deposit amount (minimum $5) and follow the selected payment flow once that completes the amount of credit purchased will be added to the account and appear in the upper right status bar once you spend your balance down your instances will be stopped until you add additional credits to prevent that from happening, you can set an auto billing threshold on the billing page to have your card auto charged when your credit balance goes below the threshold you set we recommend setting an auto charge threshold greater than your daily spend rate, and a low balance email threshold a bit lower so that you get an email if the auto charge billing attempt fails for whatever reason 2\) set up your device for connecting to instances based on how you plan to connect to your vast instances, you should have your account and device set up accordingly you can learn more about our launch modes here https //docs vast ai/instances/launch modes if you are interested in ssh, you will need to create an ssh key and upload to your account, or if you want to use jupyter you may need to install the jupyter docid 7fwrvlw rwpm3h7mmvkup for vast to make sure these modes of connecting to your instances are set up properly, we recommend you follow our set up documentation step by step, as we find some users have trouble with this portion of set up 3\) select and customize a template a template consists of a linux docker image along with its associated settings and launch modes for connecting to a machine most templates support built in jupyter and ssh as connection options click on the templates tab in the sidebar to open the templates page up top, you’ll see the recommended templates section—it’s full of curated picks that are great for getting started if you decide to create your own template, it will be saved under the my templates section read the template descriptions and pick one that suits your use case by clicking the select button any template that uses the jupyter https launch mode will require you to first install a certificate on your local machine on macos, this is required windows and linux will show a bypassable warning if the cert is not installed to install the jupyter certificate for vast, follow the instructions here to use ssh, you will need to create an ssh key and upload the public portion to vast 4\) filter machines use the filters to specify the gpu number, type and other factors such as port ranges, number of cpus, amount of gpu ram and more each filter will narrow the offers displayed if you see few or zero search results, reset your filters 5\) select storage make sure to use the storage slider on the left of the create page to choose your storage allocation size you can't change this after instance creation, so make sure to size correctly at start! 6\) rent hitting the blue rent button will accept the offer and create an instance with the specified docker image and launch mode once rented, the instance will appear in the instances tab 7\) enjoy if the docker image is cached your instance should load in a minute or less depending if the image is not cached, it will go through stages of downloading which can take 10 minutes to an hour depending on internet speeds after loading the instance will startup if your image uses the open button this will transition from connecting to open once an application starts responding on the port if your image uses ssh or jupyter, you can access those through their own buttons on the instance control panel 8\) destroy make sure to destroy instances after you are done with them stopping the instance will prevent gpu charges but you will still accrue charges for the instance storage allocation stopped instances can be restarted if/when the gpu is available 
Updated
 
21 May 2025
Did this page help you?
PREVIOUS
Introduction
NEXT
FAQ
Docs powered by
 
Archbee
Docs powered by
 
Archbee