Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
FAQ
Networking
4
min
 how can i open custom ports? add p arguments in the docker create/run options box in the template configuration or image config editor pop up menu to open ports 8081 and 8082, use something like this p 8081 8081 p 8082 8082 this will result in additional arguments to docker create/run to expose those internal ports, which will be mapped to random external ports any ports exposed in these docker options are in addition to ports exposed through expose commands in the docker image, and the ports 22 or 8080 which may be opened automatically for ssh or jupyter after the instance has loaded, you can find the corresponding external public ip by opening the ip port info pop up (button on top of the instance) and then looking for something like 65 130 162 74 33526 > 8081/tcp in this case, the public ip 65 130 162 74 33526 can be used to access anything you run on port 8081 inside the instance as a simple test case, you can run a simple minimal web browser inside the instance with the following command python m http server 8081 which you would then access in this example by loading 65 130 162 74 33526 in your web browser how can i open an identity port map like 32001 32001 where external are the same? just use an out of range port above 70000 p 70000 70000 p 70001 70001 
Updated
 
12 Feb 2025
Did this page help you?
PREVIOUS
Billing Help
NEXT
Troubleshooting
Docs powered by
 
Archbee
Docs powered by
 
Archbee