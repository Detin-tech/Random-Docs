Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Hosting
Datacenter Status
4
min
 equipment that is in a certified datacenter on vast ai is eligible to be included in the "secure cloud" offering and recieve other benefits, such as the blue datacenter label individual certifications will eventually be highlighted so users can understand if a given host is compliant with hipaa, gdpr, tier 2/3 or iso 27001 users typically are willing to pay more for the security and reliability that comes with equipment that is in a proper facility read through this documentation to understand the minimum requirements for becoming a datacenter partner and the specific verification steps that we will take to ensure compliance benefits blue datacenter label on all gpu offers in the web interface for equipment that is in the datacenter offers are included in the "secure cloud" searches in the cli and in the web interface incresed reliabilty scoring as a result of a few factors, generally higher search rankings in the marketplace direct discord or slack channel to vast ai for support requirements one of the following third party certificates must be active iso/iec 27001 tier 2+ rating from the uptime institute hipaa compliance fisma compliance the equipment must be owned by a business the business must be registered and up to date on all filings the owners of the business must be listed on the registration or otherwise verifiable the company must sign the datacenter hosting agreement the owner must undergo identity verification the host must have at least 5 gpu servers listed on vast ai or otherwise show they have a significant (5+ servers) amount of equipment to list application process in order to apply, you will need to first gather the required documentation government issued ids such as a passport for the business owner(s) business information such as a certificate of good standing or other recent record the name and address of the datacenter where the equipment is located along with the relevant certificates a contract or invoice from the datacenter linking the business other due dilligence documentation as required once you have the requiremed documentation, email us at contact\@vast ai mailto\ contact\@vast ai and we can send a link for secure file transfer conversly, you could zip up the required documents and upload them to this secure box folder https //vastai app box com/f/a3ea1cbd88c34662ac9eb6d959eb1942 as a single file using your vast ai associated email address 
Updated
 
27 Mar 2025
Did this page help you?
PREVIOUS
Guide to Taxes
NEXT
Payment
Docs powered by
 
Archbee
Docs powered by
 
Archbee