Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
Cryptocurrency
Mining on Bittensor
18
min
 vast internal guide to test subnets inside the opentensor image this tutorial shows how to use the bittensor testnet to create a subnet and run your incentive mechanism on it 1\ install bittensor subnet template cd into your project directory and clone the bittensor subnet template repo git clone https //github com/opentensor/bittensor subnet template git next, cd into bittensor subnet template repo directory cd bittensor subnet template # enter the install the bittensor subnet template package python m pip install e 2\ create wallets create wallets for subnet owner, subnet validator and for subnet miner follow all of these steps btcli wallet new coldkey wallet name owner create a coldkey and hotkey for your miner wallet btcli wallet new coldkey wallet name miner and btcli wallet new hotkey wallet name miner wallet hotkey default create a coldkey and hotkey for your validator wallet btcli wallet new coldkey wallet name validator and btcli wallet new hotkey wallet name validator wallet hotkey default 3\ get the price of subnet creation creating subnets on the testnet is competitive the cost is determined by the rate at which new subnets are being registered onto the chain btcli subnet lock cost subtensor network test the above command will show \>> subnet lock cost τ100 000000000 4 go to the bittensor discord channel and ask them for test taos here is the link https //discord com/channels/799672011265015819/830068283314929684 to the discord channel for bittensor 4 5 transfer test taos to your miner wallet use the following command to list all your wallets btcli w list you will get an output like this wallets ├── │ owner (5fyrdpzdden7kglhn6s6ia1up7dzbtxiz5trc2hmm9an9pj4) ├── │ miner (5gcahkvacwrhzvgrbfsmnt11ghnwwzhkapquzpewr7je1a8w) │ └── default (5cugzbi3gqpjdhe1ehdpjfzbb6pywvnkuswj6sbhepsby1xp) └── validator (5fzslazsifazzhcl2oxmessrqqhmwhsgppfnjmumirubpygb) └── default (5eqafbjhduqchrbg5592qvcbpnkvaxslclkrnolavln76g55) then transfer 0 001 taos to your miner and validator wallet transfer to miner wallet btcli wallet transfer dest 5gcahkvacwrhzvgrbfsmnt11ghnwwzhkapquzpewr7je1a8w wallet name owner amount 0 001 subtensor network test make sure the dest key is the same as your wallet key that you get from the btcli w list command transfer to validator wallet repeat this step for the validator wallet as well btcli wallet transfer dest 5fzslazsifazzhcl2oxmessrqqhmwhsgppfnjmumirubpygb wallet name owner amount 0 001 subtensor network test 6\ register keys this step registers your subnet validator and subnet miner keys to the subnet, giving them the first two slots on the subnet register your miner key to the subnet btcli subnet register netuid 15 subtensor network test wallet name miner wallet hotkey default follow the below prompts \>> enter netuid \[1] (1) # enter netuid 1 to specify the subnet you just created \>> continue registration? hotkey coldkey network finney \[y/n] # select yes (y) \>> ✅ registered next, register your validator key to the subnet btcli subnet recycle register netuid 15 subtensor network test wallet name validator wallet hotkey default follow the prompts \>> enter netuid \[1] (1) # enter netuid 1 to specify the subnet you just created \>> continue registration? hotkey coldkey network finney \[y/n] # select yes (y) \>> ✅ registered 7\ check that your keys have been registered this step returns information about your registered keys check that your miner has been registered btcli wallet overview wallet name miner subtensor network test the above command will display the below subnet 1 coldkey hotkey uid active stake(τ) rank trust consensus incentive dividends emission(ρ) vtrust vpermit updated axon hotkey ss58 miner default 1 true 0 00000 0 00000 0 00000 0 00000 0 00000 0 00000 0 0 00000 14 none 5gtfrseqfvtsh3wjievfekzftc2xcf… 1 1 2 τ0 00000 0 00000 0 00000 0 00000 0 00000 0 00000 ρ0 0 00000 wallet balance τ0 0 8\ run subnet miner and subnet validator run the subnet miner python neurons/miner py netuid 15 subtensor network test wallet name miner wallet hotkey default logging debug you will see the below terminal output 2024 01 22 17 34 42 694 | info | miner running 1705944882 6945262 2024 01 22 17 34 47 700 | info | miner running 1705944887 7002594 2024 01 22 17 34 52 706 | info | miner running 1705944892 7061048 2024 01 22 17 34 57 712 | info | miner running 1705944897 7120056 
Updated
 
21 Jan 2025
Did this page help you?
PREVIOUS
Blender Batch Rendering
NEXT
Google Colab
Docs powered by
 
Archbee
Docs powered by
 
Archbee