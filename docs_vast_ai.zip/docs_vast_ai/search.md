Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Search
9
min
 the search page is the main portal for finding good machines and creating instances on them page walkthrough layout you will find various search options on the top and left control bars that allow you to filter for various criteria (location, gpu type and count, various hardware specs, rental params, etc) offer card the offer card contains detailed information about the offer available for rent once rented, the offer then becomes a contract between you and the host the offer card details the terms of the contract along with the specs of the available instance most of the items on the offer card can be filtered using the search filters some of the important parts are the price and the maximum length of the rental (max duration) hovering over the price details the different prices for gpu rental, storage and bandwidth machine tiers one important concept is the category of machine which is displayed on the offer card unverified these are typically new machines that have not been tested by vast's team and are filtered out of results by default verified these machines have passed our internal tests datacenter these machines are verified and confirmed to be in a certified datacenter that meets our datacenter criteria vast verifies that these machines are in a datacenter with a tier 2/3 rating or iso 27001 these offer cards have a blue label and are recommended for production card details offer card all stats shown are the portion of the total machine rented location and host id the general region and id of the host datacenter machines are labeled in blue gpu model the gpu type and number performance the total tflops of the gpu(s) gpu memory the gpu ram per card and gpu memory bandwidth in gb/s motherboard the name of the motherboard manufacturer and type motherboard details pcie version and number of lanes along with maximum theoretical pcie bandwidth in gb/s cpu the cpu type cpu cores the number of cores allocated for this offer divided total system ram system ram allocated for this offer divided by the total network bandwidth given in mbps for upload/download network ports number of potential ports available storage the type of disk disk speed the speed of the local storage on the machine in mb/s total available disk the maximum amount of disk space available dlperf score a custom deep learning performance score price the gpu rental price plus the hourly cost of the storage allocated hover over the price for a breakdown and for the price of bandwidth max duration the duration of the contract reliability a score of how reliable the machine has been all machines start at 60% reliability rental option rent button instance disk size the storage slider is both a search filter and a parameter input which determines the storage allocation size it's important to size this correctly before creating any instance when the instance is created, the disk size is set and cannot be modified it is important to estimate how much disk you will need and then to move the slider to the desired disk size the default disk size for an instance is 10gb use the slider to allocate more or less, taking into consideration that providers charge for disk allocation even when the instance is stopped diskspace instance configuration vast ai provides out linux docker instances one key step during setup is specifying what linux docker image to load you can also specify docker run commands, an on start script that executes bash commands on instance start and a launch mode to connect to the instance the instance configuration menu is accessible in the upper left of the create instance interface the current template is always displayed in the upper left click on the "change template" button to bring up the template config menu that allows selecting and editing templates for a complete explanation of configuration options, see docker execution environment https //docs vast ai/instances/docker execution environment edit common questions i can't search for instances i am getting the error "error invalid request 0 is not a valid search op" reset your filters there is probably an invalid entry in your extra filters section on the template you are currently using i can't find the machine type i am looking for? please search to see what is available, using our search page or vastai search offers please keep in mind that we are only a marketplace we do not manage or provide the hardware if there is nothing available there is little we can do when i try to rent an instance i get "error server error something went wrong on the server" although this error can be due to a variety of things, we recommend checking to make sure you have a version tag on your docker image in your template it should look like your docker image path for example "pytorch/pytorch " selecting "latest" in the version tag dropdown menu in the template editor should fix this for you if you have a null tag or no tag selected 
Updated
 
15 Jan 2025
Did this page help you?
PREVIOUS
Instances Guide
NEXT
Referral Program
Docs powered by
 
Archbee
Docs powered by
 
Archbee