Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Transfer Team Ownership
1
min
 the transfer team onwership feature allows an owner to seamlessly reassign the team to another member within it to do so, navigate to the members page and click three dot menu in the upper right corner from there, you can click transfer team ownership and open a pop up, select a new owner (who must already be a member of the team), and confirm the transfer once confirmed, ownership will be reassigned, and your role will be changed to a manager 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Teams Roles
NEXT
Overview
Docs powered by
 
Archbee
Docs powered by
 
Archbee