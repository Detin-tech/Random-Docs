Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Teams Overview
5
min
 introduction vast ai's teams feature extends our powerful gpu compute services to collaborative environments it allows multiple users to work together seamlessly in a shared space, managing serverless workers for ai inference and gpu computing tasks collectively key features collaborative environment enable teams to work together in a shared space, managing resources and tasks collectively resource allocation & management team managers can manage access among team members, ensuring efficient use of gpu workers (in the future, resource allocation will also be in play) consolidated billing simplifies the financial management by consolidating usage and billing across the team performance metrics & access controls each team member can access shared metrics and logs, with custom access controls set by team owners getting started with teams creating a team to create a new team, navigate to the members section in your dashboard follow the on screen instructions to set up your team inviting members once your team is created, you can invite other users to join invitations will be sent via email managing resources after forming your team, you can start setting up shared permissions and rights team owners/managers have full control over these settings collaborating on projects with your team and resources in place, you can begin collaborative projects, leveraging the power of shared gpu computing monitoring and adjusting utilize the platform's monitoring tools to track team performance and resource usage adjust allocations and settings as needed to optimize your team's workflow creating multiple teams teams are created as separate accounts, allowing multiple teams to be created by a single user note this feature is unavailble for legacy teams (accounts that were converted into teams directly) each team operates independently, with its own members, roles, and permissions users can seamlessly switch between their personal and team accounts using the context switcher independent team management each team has its own and members and roles shared resources each team shares resources such as instances, templates, machines, and certain settings with all team members separate billing & credits teams maintain their own separate balance/credit, billing information, and payment history, separate from personal accounts easy switching users can navigate between personal and team accounts without affecting their workflow conclusion the teams feature at vast ai is designed to bring a new level of collaboration and efficiency to your gpu computing tasks additionally, by bringing together the power of our autoscaling system with these collaborative tools, your team will be well equipped to tackle all kinds of complex, dynamic workloads effectively 
Updated
 
04 Apr 2025
Did this page help you?
PREVIOUS
Whisper ASR Guide
NEXT
Teams Quickstart
Docs powered by
 
Archbee
Docs powered by
 
Archbee