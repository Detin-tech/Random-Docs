Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Overview
FAQ
Billing Help
6
min
 how does billing work? once you enter a credit card and an email address and both are verified you can then increase your credit balance using one time payments with the add credit button whenever your credit balance hits zero or below, your instances will be stopped automatically, but not destroyed you are still charged storage costs for stopped instances, so it is important to destroy instances when you are done using them your credit card will be automatically charged periodically to pay off any outstanding negative balance can you bill my card automatically so i don't have to add credit in advance? you can set a balance threshold to configure auto billing, which will attempt to maintain your balance above the threshold we recommend setting a threshold around your daily or weekly spend, and then setting an balance email notification threshold around 75% of that value, so that you get notified if the auto billing fails but long before your balance depletes to zero there is also an optional debit mode feature which can be enabled by request for older accounts when debit mode is enabled, your account balance is allowed to go negative (without immediately stopping your instances) i didn't enable debit mode what are these automatic charges to my card? your card is charged automatically regardless of whether or not you have debit mode enabled instances are never free even stopped instances have storage charges make sure you delete instances when you are done with them otherwise, your card will continue to be periodically charged indefinitely how does pricing work? there are separate prices and charges for active rental (gpu) costs storage costs bandwidth costs you are charged the base active rental cost for every second your instance is in the active/connected state you are charged the storage cost (which depends on the size of your storage allocation) for every second your instance exists and is online, regardless of what state it is in active, inactive, loading, etc stopping an instance does not avoid storage costs you are charged bandwidth prices for every byte sent or received to or from the instance, regardless of what state it is in the prices for base rental, storage, and bandwidth vary considerably from machine to machine, so make sure to check them you are not charged active rental or storage costs for instances that are currently offline what is the billing frequency? balances are updated about once every few seconds why should i trust vast ai with my credit card info? you don't need to vast ai does not see, store or process your credit card numbers, they are passed directly to stripe (which you can verify in the javascript) do you support paypal? what about cryptocurrency? we currently support major credit cards through stripe and crypto payments through coinbase and crypto com 
Updated
 
20 Feb 2025
Did this page help you?
PREVIOUS
Instances Help
NEXT
Networking
Docs powered by
 
Archbee
Docs powered by
 
Archbee