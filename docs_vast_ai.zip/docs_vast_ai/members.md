Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Members
3
min
 this page allows to view and manage team members and their roles more on that here to create a team, follow this guide page walkthrough here's an example of what a members page would look like in the console y ou can change a role by clicking on directional arrow and selecting a new role you can also remove a teammate by clicking on 'delete', which will trigger a pop up as you can see from the images, this members console page easily allows you to view and manage the current state of your team common questions how do i turn my user account into a team account? you can read more on that process here https //docs vast ai/team creation 
Updated
 
01 May 2025
Did this page help you?
PREVIOUS
Referral Program
NEXT
RTX 5 Series
Docs powered by
 
Archbee
Docs powered by
 
Archbee