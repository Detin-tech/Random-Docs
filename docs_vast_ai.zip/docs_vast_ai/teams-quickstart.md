Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Teams Quickstart
7
min
 introduction this quickstart guide will walk you through how to create a team, invite new team members and assign them to different roles creating the team there are two ways to create a team click on your profile name (or email address) in the context switcher and then click the create team button or you can navigate to the members section in the sidebar and click create team create team once there, you can create your team name and transfer some credit to your team during creation you can also skip the credit transfer step and do it later from the billing page to add credit during team creation, select transfer my personal credits checkbox, enter an amount, and then click create after successfully creating the team you should see your team name and role in the context switcher in the upper left corner and the team dashboard on the members page the members section is the main way that team owners and managers can interact with the teams ecosystem from here you can invite team members, create/manage team roles, remove team members, etc managing team roles every team comes with two default roles manager and member managers have full access to team resources, while members have limited read access to most resources while still being able to rent instances learn more to create a new role with your desired permissions, navigate to the roles tab of the members page then you can name the role and choose the permission groups that the new role will have access to once you are satisfied, click generate to create the new role for more information on permission groups and what they allow access to, click here inviting team members to invite a team member, go to the members page and click on the invite button this will bring up a quick popup where you can enter the email and team role for the person you want to invite once complete, click invite to send the invitation email once you send the invitation, the user should get an email asking them to join your team upon clicking the link in the email they will be added as a member of your team note if the recipient of the invitation does not have a vast account, they will need to create one before being added to your team once the invitee has joined your team, you should see them listed in the members section conclusion you have now successfully created a team! from this point, you can add any billing information the same way as a regular account and invite as many of your teammates as you like so you can collaborate together with ease 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Teams Overview
NEXT
Edit team
Docs powered by
 
Archbee
Docs powered by
 
Archbee