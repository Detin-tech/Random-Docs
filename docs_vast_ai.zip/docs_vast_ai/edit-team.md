Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Teams Quickstart
Edit team
3
min
 this guide will walk you through the steps to change your team name or delete your team change team name you must be a team owner or team manager to update the team name here is how to do it switch to team context click your profile in the top left corner select the team you want to manage open the members page click three dot menu and select 'edit team name' the 'edit team name' option opens a pop up that allows you to enter and save a new team name delete a team only the team owner can delete a team to delete a team, open the same three dot menu on the members page and select 'delete team' make sure you have deleted all instances from the instances page, or all machines from the machines page (if you are a host), before proceeding ⚠ warning this action is permanent and cannot be undone all team members will be removed and any remaining credits will be return to your personal account 
Updated
 
13 May 2025
Did this page help you?
PREVIOUS
Teams Quickstart
NEXT
Team Creation
Docs powered by
 
Archbee
Docs powered by
 
Archbee