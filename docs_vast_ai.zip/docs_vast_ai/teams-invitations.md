Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Teams Invitations
3
min
 sending team invitations accessing invitation feature team managers and owners can send invitations from the team members page on the vast ai platform or by using the vast cli tool entering email addresses to invite a new member in the ui, enter their email address in the invitation section then, select the role you want them to join as sending the invitation once the email address is entered and the role is set, click invite an email with a unique invitation link will be sent to the invitee anyone with the proper permissions (currently team write ) can send invitations to invite team members at any role level accepting team invitations receiving the invitation email invitees will receive an email containing a unique team invitation link completing the joining process clicking the link will initiate a set of operations to add the invitee to the team this may involve signing into the vast ai platform or creating an account if necessary confirmation of membership once the process is complete, the new member will be officially added to the team and will have access based on their role best practices ensure accurate email address double check the email address before sending invitations to avoid any miscommunication communicate with invitees inform potential team members that they will be receiving an invitation and what steps they need to follow follow up on pending invitations keep track of sent invitations and follow up with invitees who haven't joined yet note team inivitations will expire after 4 hours 
Updated
 
04 Apr 2025
Did this page help you?
PREVIOUS
Team Creation
NEXT
Teams Roles
Docs powered by
 
Archbee
Docs powered by
 
Archbee