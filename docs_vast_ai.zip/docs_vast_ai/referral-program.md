Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Referral Program
7
min
 vast has a referral reward program you can drive traffic to your referral link or a public template referral link if someone registers a new client account and purchases credits, you will receive 3% of the credits spent as a reward into your account furthermore, you can turn 75% of those referral credits into cash and withdraw it via stripe connect, paypal or wise a referred account will give you 3% rewards for the lifetime of the account! we suggest using a separate account for referrals it is also possible to create a vast template for referrals that will autoload a docker image and settings for a certain use case read below for details setup a dedicated account for referrals in order to receive payouts for referrals you must create a new account you are unlikely to be able to receive payouts to any bank account outside vast if the account you are using for referrals has ever rented instances or hosted machines if your goal is to receive payouts to an entity outside of vast, you will need to create an account on vast dedicated for referrals if your goal is to receive credits on to your credit balance, you can use your current client account the default payout method for referral credits is to your credit balance on vast which you use to rent instances if you choose to use an already existing client account with an instance rental history, you will not be able to receive payouts until your referral earnings surpass your instance spend creating a new account will also allow you to more properly track your referral earnings since they will be harder to track if your referral earnings and being directly sent to your vast credit balance for those that are curious how to receive a payout when you have a client account with a rental history ⚠️ warning a user has purchased $700 in credits, received $300 in referral credits, and accumulated $855 in lifetime charges this user has a payable balance of $300 $855, which is less than 0 the user would be unable to receive payouts to an entity outside vast due to their lifetime spend being greater than their referral earnings in order to receive a payout to outside vast the amount you've earned in referrals must be greater than the amount you've ever been charged in your accounts lifetime get your link navigate to your settings page and find the referral link section the hyperlink has your referral link it should look like this https //cloud vast ai/?ref=xxxxx when a new user clicks on that link, creates an account and purchases credits, you receive 3% of the purchased credits as a reward those credits will appear as a positive balance in the account note that you cannot refer yourself or refer new accounts associated with yourself those accounts are not eligible for rewards use a template for referrals templates https //docs vast ai/instances/templates combine a docker image, launch mode(s), an onstart script and other settings into a single configuration they are very useful for a specific use case for example, the stable diffusion template loads a stable diffusion docker image, opens the port for the automatic1111 webui, starts jupyter for file transfer and then sets appropriate environment variables you could make your own docker image and vast template for a new use case and then set the template to public and refer people using that template link that way the user will have the correct vast settings pre loaded when they come to the vast website and will find it much easier to follow your instructions we have seen this system used well in github repos and linked from videos or blogs you can write software or develop content for a particular use case and then earn referral credits as your audience uses the vast service you’ll find the template link right on the template card just click the three dot menu and select “copy referral link” to share it the link will have this format https //cloud vast ai/?ref id=xxxxx\&template id=26cfc61ec39932c5fb38c3d15291e780 larger referral opportunities feel free to contact us at support\@vast ai mailto\ support\@vast ai for larger referral or marketing opportunities 
Updated
 
25 Apr 2025
Did this page help you?
PREVIOUS
Search
NEXT
Members
Docs powered by
 
Archbee
Docs powered by
 
Archbee