Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Teams
Teams Roles
7
min
 what are team roles? team roles in vast ai's platform are designed to streamline collaboration and enhance security by assigning specific permissions and access levels to different members of a team these roles determine what actions a team member can perform and what data they can access within the team's shared workspace/context types of team roles default roles these are the standard roles with preset permissions, suitable for common team structures owner full access to all team resources, settings, and member management manager all permissions of team owner apart from team deletion member has ability to view, create, and interact with instances, but no access to billing info, team management, autoscaler, machines, etc custom roles custom roles allow team managers to create roles with custom, tailored permissions via permission groups this feature is particularly useful for teams with unique workflow requirements or specific security protocols for more information on permission groups and what they allow access to, click here creating custom roles accessing role management custom roles can be created and managed through the roles tab of the members page on the vast ai platform defining permissions when creating a custom role, you can select from a wide range of read/write permissions, such as instance creation, billing access, etc this allows for precise control over what each role can and cannot do assigning custom roles once a custom role is created, it can be assigned to team members through the team management interface you can create roles either in the vast cli or on your team dashbaord if you have permission to create roles within your team (team write) you can easily edit any roles on your team using the team dashboard when editing a role you should see the same series of checkboxes and categories as before role syntax all team roles are created through the team dashboard using the role editor you can also create roles through the vast cli by passing in a permissions json object that delegates what group of endpoints can be accessed currently, the system only supports groups of endpoint categories, but soon it will be extended for further granularity the current activated scopes are as follows misc supports uncategorized operations like search offers, getting logs from various sources, etc user read allows the usage of obtaining basic user data like email, credits, etc essential for web usage user write allows the ability to change account settings such as email, password, 2fa, etc instance read grants ability to view instances, and certain read only instance operations instance write grants access to instances and all relevant operations such as starting/stopping instances, cloud copy, reserving credits, etc billing read ability to view billing page and get billing information billing write ability to change billing page information machine read read access to machines owned by the team machine write ability to add/remove machines, and also edit machine settings an example of a permissions json would look like this { "api" { "misc" {}, "user read" {}, "instance read" {}, "instance write" {}, "team read" { "api team members" {} } } } in order to create a granular team roles you must either use the cli or the api in the above example, the only api under team read that the user would have access to would be viewing the list of team members for more information on permissions click here best practices for using team roles clear role definitions clearly define the responsibilities and permissions for each role to avoid confusion and ensure effective collaboration use custom roles judiciously create custom roles when predefined roles do not meet your specific needs be mindful of the permissions assigned to ensure team security and efficiency conclusion team roles are a fundamental aspect of managing a secure environment for collaboration on the vast ai platform by effectively utilizing predefined and custom roles, teams can ensure that each member has the appropriate level of access and control, fostering a productive and secure working environment 
Updated
 
04 Apr 2025
Did this page help you?
PREVIOUS
Teams Invitations
NEXT
Transfer Team Ownership
Docs powered by
 
Archbee
Docs powered by
 
Archbee