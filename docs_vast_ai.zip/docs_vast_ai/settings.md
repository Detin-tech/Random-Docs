Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Console
Settings
15
min
 on this page you can view and edit important information about your customer account page walkthrough enable dark mode turning the switch on and off will enable and disable dark mode enable dark mode section you can also toggle this setting in the navigation bar with the moon and sun icons account security in the account security section, you can set up two factor authetication, resend a verification email, change your email, or reset your password account security section two factor authentication you can set up two factor authentication (2fa) for your vast account this can be used to help protect your account from unauthorized access you’ll be required to enter a security code each time you sign in two factor authentication resend verification email select the "resend" button to receive a new verification email in your inbox resend verification email change email you can view the current email connected to your account and change your email at any time by pressing the 'change' button change email when you change your email using this feature you will not be required to re verify your email address all emails that would normally be sent to the old e mail will be now be directed towards your new email reset password you can change your password by selecting the "reset" button, and you will get a link to reset your password via email reset password referral link you can access your referral link in the referral link section of the settings page referral link section when users create an account through your referral link and use vast services, you'll earn credits and receive payouts for your referrals referral link fields environment variables you can add, edit, and delete the environment variables stored on your account in the environment variables section env section when adding individually, input the env key into the key field and value into the value field, then select the "+" button to save your environment variable env fields to add multiple at once, select the "batch paste" option and paste your environment variables into that input, according to the format below env batch paste within the batch paste mode, you can save your changes by selecting the "save" button or erase them with the "cancel" button when you are finished editing your environment variables, make sure you select the "save edits" button to save all of your changes notification settings you can subscribe or unsubscribe from our email newsletter by selecting or unselecting this checkbox in the notification settings section cloud connection in this section, you can integrate and connect with cloud providers such as amazon s3, backblaze, and dropbox cloud connection section this integration process is very straightforward if you need assistance in setting up these integrations you can read our guides here https //docs vast ai/instances/cloud sync one of the benefits of these integrations is the ability to sync data even while instances are inactive cloud connection fields you can access this feature via the 'cloud copy' button on the instances page invoice information in the invoice information section, you can set personal information for your invoices invoice information section click into any input field to edit it, and select the "save" button to save your changes invoice information fields common questions can i delete my account? we aren't able to delete accounts at the moment, but an effective equivalent is to change all identifying information like your email, invoice address, and password, as well as remove any ssh keys, reset api keys, and remove your credit card is there a spend rate limit on my account? there is a spend rate limit for new users make sure you have verified your email; otherwise, your limit is near zero once you have verified your email, your spend rate limit increases automatically over time if you are an enterprise user, email us at contact\@vast ai mailto\ contact\@vast ai to request a larger rate limit increase users paying with crypto are also eligible for rate increases 
Updated
 
22 Apr 2025
Did this page help you?
PREVIOUS
Introduction
NEXT
Keys
Docs powered by
 
Archbee
Docs powered by
 
Archbee