Console
Discord
Guides
Instances
Serverless
API
Navigate through spaces
⌘
K
Overview
Introduction
QuickStart
FAQ
Use Cases
Teams
Hosting
Distributed Computing
Console
Specific GPUs
RTX 5 Series
Docs powered by
 
Archbee
Use Cases
3D Rendering
Blender Batch Rendering
11
min
 blender is a free, open source 3d creation suite it can be used to create animated films, visual effects, art, 3d printed models, motion graphics, interactive 3d applications, virtual reality, and video games it supports the entirety of the 3d pipeline—modeling, rigging, animation, simulation, rendering, compositing and motion tracking, even video editing and game creation you can find more information about blender at blender org https //www blender org/ animators, game developers, 3d modelers, visual effects artists, architects, and product designers are some people who use blender gpus can speed up rendering in blender you can save time by automating away the rendering of animations for batch of blend files step 1 open vast's blender batch renderer template click on this link blender batch renderer template https //cloud vast ai/?ref id=142678\&template id=7b570ea8454e5f2b4b026139709fa0e8 to select the vast/blender batch renderer template step 2 check the secure cloud box if you want a secure machine from trusted datacenters (optional) you can narrow your search results to only data center machines if you want insured security standards from our trusted datacenters highlighted secure cloud step 3 filter for a gpu that you feel best suits your needs if you have questions about which gpu to choose, there is some data around nvidia geforce rtx 4090 giving the best render speed with blender you can find other gpus that work well with blender here blender gpu benchmarks https //opendata blender org/benchmarks/query/?group by=device name\&blender version=3 6 0 you can also find other options by searching on google or asking chatgpt the version of blender running within vast while using the template linked above at the time of this writing is 3 6 2 go to the gpus filter and check the box for rtx 4090 or another gpu instance for example, highlighted rtx 4090 filter pic step 4 choose a gpu by clicking "rent" choose a gpu that meets your budget, desired reliability %, and other constraints by clicking "rent" gpus are sorted by a complex proprietary algorithm that aims to give users the best machines for their value by default you can filter gpus further per your requirements if desired highlighted rent step 5 use jupyter direct https launch mode follow the instructions related to adding a certificate to your browser if you need to when it asks you to "setup jupyter direct https" and click "continue" here's more information on the jupyter direct https launch mode and installing the tls certificate https //docs vast ai/instances/jupyter https //docs vast ai/instances/jupyter updated jupyter direct https continue step 6 click the open button or jupyter notebook button to open jupyter notebook jupyter notebook button step 7 to render animation for each blend file in batch of blend files if you want to render a respective animation for each blend file in a batch of blend files, follow the following steps go to /desktop/render animation for each blend file in batch of blend files/ folder in jupyter notebook go render animation for batch folder upload blend files to /desktop/render animation for each blend file in batch of blend files/ folder upload 100 color vortex upload render animation batch highlighted open render animation for each blend file in batch of blend files ipynb open render animation for batch folder notebook click the run tab and click run all cells show rendering animations click run all cells highlighted now a corresponding animation will be rendered for each blend file you have uploaded to this folder you can also close out your jupyter notebook tab in your browser and this notebook will keep running as long as your instance in vast is running step 8 to render animation for xth frame of each blend file in batch of blend files if you want to render a respective animation for the xth frame of each blend file in a batch of blend files, follow the following steps go to /desktop/render xth frame of batch of blend files/ folder in jupyter notebook go to render xth frame for batch folder upload blend files to /desktop/render xth frame of batch of blend files/ folder upload blend files for xth frame upload xth frame highlighted open render xth frame of batch of blend files ipynb open render animation for each blend file in batch of blend files ipynb set frame number equal to a particular frame number for ex frame number=2 set frame number 2 click the run tab and click run all cells xth frames rendering run all cells xth frame highlighted now a corresponding animation will be rendered for each xth frame of each blend file you have uploaded to this folder you can also close out your jupyter notebook tab in your browser and this notebook will keep running as long as your instance in vast is running 
Updated
 
21 Jan 2025
Did this page help you?
PREVIOUS
Blender in the Cloud
NEXT
Mining on Bittensor
Docs powered by
 
Archbee
Docs powered by
 
Archbee