Audit Logs
Supported services
Viewing events
Event structure and fields
Use cases
Audit Logs
With the Audit Logs in Nebius AI Cloud, you can see who did what and when  with your resources, to ensure security, compliance and accountability.
To access the service, you should be in your tenant's
admins

group
.
The service is
in preview
, and available in all
regions
:
eu-north1
,
eu-west1
 and
us-central1
.
Supported services
See the list of Nebius AI Cloud services and resources from which you can get events  in Audit Logs
Viewing events
Learn how to view, search and filter events
Event structure and fields
See what events look like and what information they contain
Use cases
Learn how Audit Logs can help you investigate key events in your tenant, from security issues to resource changes

---

**Related:**

- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[audit-logs/services]]
- [[audit-logs/use-cases]]
- [[index]]
- [[legal/archive/specific-terms/index-20250410]]
- [[legal/specific-terms]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[overview/services]]