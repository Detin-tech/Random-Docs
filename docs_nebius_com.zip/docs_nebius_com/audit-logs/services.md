Audit Logs
Supported services
Viewing events
Event structure and fields
Use cases
Nebius AI Cloud services supported by Audit Logs
Audit Logs creates events for the following
Nebius AI Cloud services and technical resources
 (corresponding values of the
.service.name
 field in
event JSONs
 are given in parentheses):




Compute
 (
COMPUTE
)


Container Registry
 (
REGISTRY
)


Managed Service for MLflow
 (
MSP_MLFLOW
)


Managed Service for PostgreSQL®
 (
MSP_POSTGRESQL
)


Object Storage
 (
STORAGE
)


Virtual Private Cloud
 (
VPC
)


Identity and access management resources
 (
IAM
)






Postgres, PostgreSQL and the Slonik Logo are trademarks or registered trademarks of the PostgreSQL Community Association of Canada, and used with their permission.


Next
Viewing events

---

**Related:**

- [[applications]]
- [[audit-logs]]
- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[audit-logs/use-cases]]
- [[cli/configure]]
- [[compute/storage/types]]
- [[compute/virtual-machines/cuda-init-error]]
- [[iam/authorization/access-tokens]]
- [[iam/overview]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authentication]]
- [[index]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/pricing]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal]]
- [[legal/agreement]]
- [[legal/archive/agreement-20240917]]
- [[legal/archive/aup-20240830]]
- [[legal/archive/cookie-policy-20240830]]
- [[legal/archive/cookies-list-20240930]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/archive/privacy-20240828]]
- [[legal/archive/service-terms-20240830]]
- [[legal/archive/service-terms-20241125]]
- [[legal/archive/sla-20241125]]
- [[legal/archive/sla-levels/index-20240925]]
- [[legal/archive/sla-levels/index-20250219]]
- [[legal/archive/sla-levels/index-20250304]]
- [[legal/archive/sla-levels/index-20250313]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/specific-terms/container-registry-20240925]]
- [[legal/archive/specific-terms/index-20240830]]
- [[legal/archive/specific-terms/index-20240925]]
- [[legal/archive/specific-terms/index-20241023]]
- [[legal/archive/specific-terms/index-20250313]]
- [[legal/archive/specific-terms/index-20250410]]
- [[legal/archive/specific-terms/managed-mlflow-20240830]]
- [[legal/archive/specific-terms/managed-postgresql-20240925]]
- [[legal/archive/specific-terms/managed-spark-20240925]]
- [[legal/archive/terms-of-use-20240828]]
- [[legal/aup]]
- [[legal/cookie-policy]]
- [[legal/cookies-list]]
- [[legal/dpa]]
- [[legal/hr-privacy-policy]]
- [[legal/pentest]]
- [[legal/privacy]]
- [[legal/service-terms]]
- [[legal/sla]]
- [[legal/sla-levels]]
- [[legal/sla-levels/applications/standalone]]
- [[legal/sla-levels/compute]]
- [[legal/sla-levels/managed-kubernetes]]
- [[legal/sla-levels/managed-mlflow]]
- [[legal/sla-levels/managed-postgresql]]
- [[legal/sla-levels/storage]]
- [[legal/sla-levels/vpc]]
- [[legal/specific-terms]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[legal/studio/archive/dpa-20241220]]
- [[legal/studio/archive/privacy-20240828]]
- [[legal/studio/archive/terms-of-use-20240828]]
- [[legal/studio/archive/terms-of-use-20241220]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/dpa]]
- [[legal/studio/privacy]]
- [[legal/studio/terms-of-use]]
- [[legal/sub-processors]]
- [[legal/terms-of-use]]
- [[legal/tsr]]
- [[object-storage/overview]]
- [[observability]]
- [[observability/alerts]]
- [[observability/dashboards]]
- [[observability/logging]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/logs/query-language]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[observability/monitoring]]
- [[observability/resources/pricing]]
- [[observability/resources/quotas-limits]]
- [[observability/services]]
- [[overview]]
- [[overview/data-deletion]]
- [[overview/quotas]]
- [[overview/regions]]
- [[overview/services]]
- [[overview/subscriptions]]
- [[overview/subscriptions/manage-subscriptions]]
- [[overview/support]]
- [[signup-billing/billing-models/committed-usage]]
- [[signup-billing/billing-models/payg]]
- [[signup-billing/payments/bank-transfers]]
- [[signup-billing/payments/card]]
- [[signup-billing/payments/invoices]]
- [[signup-billing/payments/threshold]]
- [[signup-billing/sign-up]]
- [[slurm-soperator/jobs/containers]]
- [[studio]]
- [[studio/inference]]