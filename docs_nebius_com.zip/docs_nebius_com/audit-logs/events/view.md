Audit Logs
Supported services
Viewing events
Event structure and fields
Use cases
Viewing events in Audit Logs
How to view events
How to filter events
An
audit event
 is a data record that captures something that happened in Nebius AI Cloud, along with metadata that provides additional context. The metadata shows how events relate to resources or to each other. Each event in Audit Logs has a JSON representation that conforms to the
CloudEvents specification
.


You can use the Nebius AI Cloud web console or CLI to view and filter audit events for your
tenant
.


How to view events
How to view events






Web console


CLI






In the sidebar, go to
Audit Logs
. To work with the events on this page, you can do the following:




View event JSONs. To do this, click
 in an event's row.


Search event JSONs by using the search bar.


Filter events by period or
by using filters
.












To copy the ID of the required tenant, view your list of tenants:




nebius iam tenant list



























View all events for the tenant for a specific period. To configure the period, use start and end dates in the
ISO 8601
 format.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> \
    --end <time_in_ISO_8601>























For example, to check all the events that happened in March 2025, run the following command:




nebius audit v2 audit-event list --parent-id <tenant_ID> \
  --start 2025-03-01T00:00:00Z \
  --end 2025-04-01T00:00:00Z































How to filter events
How to filter events






Web console


CLI






To narrow down the events, you can use the following filters:




Resource ID
: ID of the resource on which actions were performed. For example, a Compute disk (
computedisk-***
), a service account (
serviceaccount-***
), etc.


Event type
: Specify one or more of the following filters:



Service
, in lowercase.


Resource, for example,
instance
,
serviceaccount
 or
mlflow
 for a Managed MLflow cluster.


Action. Standard actions are
create
,
update
 or
delete
. Actions can differ by service. For example, for Compute resources, you can also specify
stop
 and
start
.


A combination of the two or three previous filters, in the
<service_name>.<resource_type>.<action>
 format. For example,
storage.bucket.delete
.






Subject name
,
Subject ID
: Name and ID of a user account or a service account that performed actions. The formats of user account IDs and service account IDs are
tenantuseraccount-***
 and
serviceaccount-***
.








To narrow down the events, you can use one or more of the following filters:






Resource ID or type


The type or ID of the resource on which actions were performed. ID formats include, for example, a
computeinstance-***
 for a Compute virtual machine,
computedisk-***
 for a Compute disk,
serviceaccount-***
 for a service account.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"resource.metadata.type='computeinstance'"


























nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"resource.metadata.id='computeinstance-***'"




























Resource's ancestor ID or name


The ID or name of the resource's ancestor, starting from the tenant. For example, you can check all the actions performed on virtual machines in one of your projects by specifying the project ID or name.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"resource.hierarchy.id:'<ancestor_ID>'"


























nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"resource.hierarchy.name:'<ancestor_name>'"




























Event action


Specify the action:
CREATE
,
UPDATE
 or
DELETE
. Actions can differ by service. For example, for Compute resources, you can also specify
STOP
 and
START
.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"action='DELETE'"




























Service
 in which the event occured


See the
list of services
.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"service.name='COMPUTE'"




























Event type


A string in the
ai.nebius.<service_name>.<resource_type>.<action>
 format. It includes the
ai.nebius
 prefix and refers to a Nebius AI Cloud service, type of resource in it and the action performed on this resource, for example,
ai.nebius.compute.computeinstance.delete
.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"type='ai.nebius.compute.computeinstance.delete'"




























Subject name or ID


The name or ID of a user account or a service account that performed actions. The formats of user account IDs and service account IDs are
tenantuseraccount-***
 and
serviceaccount-***
.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"authentication.subject.name='<user_email>'"


























nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"authentication.subject.tenant_user_id='tenantuseraccount-***'"


























nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"authentication.subject.service_account_id='serviceaccount-***'"




























Subject credentials


For
access tokens
, use
authentication.token_credential.masked_token
 without a signature. For AWS-compatible
access keys
, use
authentication.static_key_credential.id
.




nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"authentication.token_credential.masked_token='<token_without_signature>'"


























nebius audit v2 audit-event list --parent-id <tenant_ID> \
    --start <time_in_ISO_8601> --end <time_in_ISO_8601> \
    --filter
"authentication.static_key_credential.id='<access_key_ID>'"




























To combine the filters, use the following instruments:




AND
 logical operator.


Comparison operators:
=
 (equals),
!=
 (not equals),
:
 (contains).


Regular expressions
 (for example,
regex(resource.name, '^.*prod.*$')
 to show resources with
prod
 in their names).




For example, to view all events where the user
example@nebius.com
 deleted virtual machines between April 1 and April 5, run:




nebius audit v2 audit-event list --parent-id tenant-*** \
    --start 2025-04-01T00:00:00Z --end 2025-04-06T00:00:00Z  \
    --filter
"authentication.subject.name='example@nebius.com' \
        AND action='DELETE' \
        AND resource.metadata.type='computeinstance'"
























For more details about the fields, see
Structure and fields of events in Audit Logs
.






Previous
Supported services
Next
Event structure and fields
In this article:
How to view events
How to filter events

---

**Related:**

- [[applications]]
- [[applications/standalone]]
- [[audit-logs]]
- [[audit-logs/use-cases]]
- [[cli/configure]]
- [[compute/clusters/skypilot]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/overview]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[legal/archive/cookie-policy-20240830]]
- [[legal/cookie-policy]]
- [[legal/specific-terms/storage]]
- [[mlflow/monitoring]]
- [[object-storage/monitoring]]
- [[observability]]
- [[observability/dashboards]]
- [[observability/logging]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[overview/quotas]]
- [[overview/services]]
- [[overview/support]]
- [[postgresql/monitoring]]
- [[postgresql/replication/from-external]]
- [[signup-billing/billing-models/committed-usage]]
- [[signup-billing/billing-models/payg]]
- [[signup-billing/payments/invoices]]
- [[slurm-soperator]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/manage]]
- [[slurm-soperator/monitoring/statuses]]
- [[studio/inference/api]]
- [[studio/inference/batch]]
- [[studio/inference/playground]]
- [[studio/prompt-presets]]
- [[terraform-provider/reference]]
- [[terraform-provider/reference/data-sources/iam_v1_tenant_user_account]]
- [[terraform-provider/reference/resources/applications_v1alpha1_k8s_release]]
- [[terraform-provider/reference/resources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]
- [[vpc/networking/resources]]