Audit Logs
Supported services
Viewing events
Event structure and fields
Use cases
When to use Audit Logs
Potential security incidents
Who made changes to resources, and when?
What happened at the time of the incident?
Unexpected spending
What happened with a specific resource?
Who created a new resource?
Audit Logs allows you to view and filter events for your
tenant
. This article helps you understand which filters to set when you investigate specific situations, such as:




When you suspect a security incident
.


When resource changes lead to unexpected spending
.




Potential security incidents
Potential security incidents


If you suspect a security incident in your tenant, Audit Logs can help you track down the events that occurred at the time and investigate possible causes.


Who made changes to resources, and when?
Who made changes to resources, and when?


If you encounter a suspicious change in resources of a given type, review the events that involve resource changes:






Web console


CLI










Enter
create
,
update
 or
delete
 in the
Event type
 field, to see all resource changes.






Enter
<resource_type>.<action>
 or
<service>.<resource_type>.<action>
 in the
Event type
 field, to see the changes that concern a specific resource type.


For example, enter
computeinstance.delete
 to find out which Compute virtual machines were deleted.






See the
Subject
 column to find out who made the change.






Set the following filters:




action
 equal to
CREATE
,
UPDATE
 or
DELETE
.


resource.metadata.type
 equal to the resource type. For example,
computeinstance
 for a Compute virtual machine.




For example, to find out which Compute virtual machines were created in the period:




nebius audit v2 audit-event list \
  --parent-id <tenant_ID> \
  --start <start_date> --end <end_date> \
  --filter
"action='CREATE' AND resource.metadata.type='computeinstance'"
























See the
authentication.subject
 parameter of the response to find out who made the change.






What happened at the time of the incident?
What happened at the time of the incident?


To gain more context when investigating an incident, create granular filters to review the events:






CLI






To combine the filters, use the following instruments:




AND
 logical operator.


Comparison operators:
=
 (equals),
!=
 (not equals),
:
 (contains).


Regular expressions
 (for example,
regex(resource.name, '^.*prod.*$')
 to show resources with
prod
 in their names).


Limit the number of entries you receive, by using the
--page-size
 parameter.




For example, to view 10 events where the user
example@nebius.com
 deleted virtual machines between April 1 and April 5, run:




nebius audit v2 audit-event list --parent-id <tenant_ID> \
  --start 2025-04-01T00:00:00Z \
  --end 2025-04-06T00:00:00Z  \
  --filter
"authentication.subject.name='example@nebius.com' \
    AND action='DELETE' \
    AND resource.metadata.type='computeinstance'"
 \
  --page-size=10























If there are more than 10 events, get the
next_page_token
 value from the response and run the same command again with an additional
--page-token=<next_page_token>
 parameter to get the next batch.






Unexpected spending
Unexpected spending


If you see a sudden increase in spending, Audit Logs can help you find out more about the resources that are used in your tenant.


What happened with a specific resource?
What happened with a specific resource?


A particular resource may cause more spending than you expected. Get the events that are associated with this resource:






Web console


CLI






Enter the resource ID in the
Resource ID
 field.








If you know the resource name, filter by
resource.metadata.name
.


If you know the resource ID, filter by
resource.metadata.id
.




For example:




nebius audit v2 audit-event list \
  --parent-id <tenant_ID> \
  --start <start_date> --end <end_date> \
  --filter
"resource.metadata.name='<name>'"




























Who created a new resource?
Who created a new resource?


Unexpected spending may be caused by creating more resources than necessary. To investigate who created them, get the resource creation events:






Web console


CLI






Enter
<resource_type>.create
 or
<service>.<resource_type>.create
 in the
Event type
 field, to see the changes that concern a specific resource type.


For example, enter
compute.computeinstance.create
 in the
Event type
 field to see all events where a Compute virtual machine was created.


See the
Subject
 column to find out who made the change.






Set the following filters:




action
 equal to
CREATE
.


resource.metadata.type
 equal to the resource type. For example,
computeinstance
 for a Compute virtual machine.




For example:




nebius audit v2 audit-event list \
  --parent-id <tenant_ID> \
  --start <start_date> --end <end_date> \
  --filter
"action='CREATE' AND resource.metadata.type='computeinstance'"
























See the
authentication.subject
 parameter of the response to find out who made the change.






Previous
Event structure and fields
In this article:
Potential security incidents
Who made changes to resources, and when?
What happened at the time of the incident?
Unexpected spending
What happened with a specific resource?
Who created a new resource?

---

**Related:**

- [[audit-logs]]
- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[audit-logs/services]]
- [[compute/clusters/skypilot]]
- [[compute/storage/types]]
- [[studio/inference/models]]