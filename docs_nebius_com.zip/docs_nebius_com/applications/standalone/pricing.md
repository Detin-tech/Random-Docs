Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
Pricing
Standalone Applications pricing in Nebius AI Cloud
How charges and prices work
Prices
Computing resources
Storage
This article provides detailed pricing for the
Standalone Applications service
 in Nebius AI Cloud.


For more details about another type of application, see
Applications for Managed Service for Kubernetes® in Nebius AI Cloud
.


How charges and prices work
How charges and prices work


Each group of chargeable items in this article has two time units associated with it:




Billing unit
: The minimum unit of usage for which you can be charged.


Pricing unit
: The unit of usage for which the prices are shown.




Charges for units smaller than the pricing unit are calculated proportionally.




For example, for GPUs on running VMs, the
billing unit
 is 1 second, and the
pricing unit
 is 1 hour (3600 seconds). For 30 minutes of usage, you will be charged half the hourly price.




All prices are shown without any applicable taxes, including VAT. Due to rounding errors, usage costs shown in the web console and final charges may slightly differ from calculations based on the prices in this article.


Prices
Prices


Nebius AI Cloud charges you for the computing resources allocated to running applications and the storage size.


Public access to applications is free of charge.


Computing resources
Computing resources


You are charged for computing resources in your applications.




Billing unit
: 1 second


Pricing unit
: 1 hour (3600 seconds)




NVIDIA® H100 NVLink with Intel Sapphire Rapids
NVIDIA® H100 NVLink with Intel Sapphire Rapids








Item


Price


Per










Standalone application on NVIDIA® H100 NVLink with Intel Sapphire Rapids. GPU


$2.118


1 GPU hour






Standalone application on NVIDIA® H100 NVLink with Intel Sapphire Rapids. CPU


$0.012


1 CPU hour






Standalone application on NVIDIA® H100 NVLink with Intel Sapphire Rapids. RAM


$0.0032


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
1gpu-16vcpu-200gb
 application for 1 hour costs $2.118 + 16 × $0.012 + 200 × $0.0032 = $2.95. For 730 hours (~ 1 month), this amounts to 730 × $2.95 = $2153.50.


NVIDIA® H200 NVLink with Intel Sapphire Rapids
NVIDIA® H200 NVLink with Intel Sapphire Rapids








Item


Price


Per










Standalone application on NVIDIA® H200 NVLink with Intel Sapphire Rapids. GPU


$2.668


1 GPU hour






Standalone application on NVIDIA® H200 NVLink with Intel Sapphire Rapids. CPU


$0.012


1 CPU hour






Standalone application on NVIDIA® H200 NVLink with Intel Sapphire Rapids. RAM


$0.0032


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
1gpu-16vcpu-200gb
 application for 1 hour costs $2.668 + 16 × $0.012 + 200 × $0.0032 = $3.50. For 730 hours (~ 1 month), this amounts to 730 × $3.50 = $2555.00.


NVIDIA® L40S PCIe with Intel Ice Lake
NVIDIA® L40S PCIe with Intel Ice Lake








Item


Price


Per










Standalone application on NVIDIA® L40S PCIe with Intel Ice Lake. GPU


$1.35


1 GPU hour






Standalone application on NVIDIA® L40S PCIe with Intel Ice Lake. CPU


$0.012


1 CPU hour






Standalone application on NVIDIA® L40S PCIe with Intel Ice Lake. RAM


$0.0032


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
1gpu-16vcpu-64gb
 application for 1 hour costs $1.35 + 16 × $0.012 + 64 × $0.0032 = $1.7468. For 730 hours (~ 1 month), this amounts to 730 × $1.7468 = $1275.164.


NVIDIA® L40S PCIe with AMD Epyc Genoa
NVIDIA® L40S PCIe with AMD Epyc Genoa








Item


Price


Per










Standalone application on NVIDIA® L40S PCIe with AMD Epyc Genoa. GPU


$1.35


1 GPU hour






Standalone application on NVIDIA® L40S PCIe with AMD Epyc Genoa. CPU


$0.01


1 CPU hour






Standalone application on NVIDIA® L40S PCIe with AMD Epyc Genoa. RAM


$0.0032


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
1gpu-16vcpu-96gb
 application for 1 hour costs $1.35 + 16 × $0.01 + 96 × $0.0032 = $1.8172. For 730 hours (~ 1 month), this amounts to 730 × $1.8172 = $1326.556.


Non-GPU AMD EPYC Genoa
Non-GPU AMD EPYC Genoa








Item


Price


Per










Standalone application on Non-GPU AMD Epyc Genoa. CPU


$0.025


1 CPU hour






Standalone application on Non-GPU AMD Epyc Genoa. RAM


$0.005


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
4vcpu-16gb
 application for 1 hour costs 4 × $0.025 + 16 × $0.005 = $0.18. For 730 hours (~ 1 month), this amounts to 730 × $0.18 = $131.40.


Non-GPU Intel Ice Lake
Non-GPU Intel Ice Lake








Item


Price


Per










Standalone application on Non-GPU Intel Ice Lake. CPU


$0.025


1 CPU hour






Standalone application on Non-GPU Intel Ice Lake. RAM


$0.005


1 GiB hour








Charges are based on the resource preset that you are using. For example, using a
4vcpu-16gb
 application for 1 hour costs 4 × $0.025 + 16 × $0.005 = $0.18. For 730 hours (~ 1 month), this amounts to 730 × $0.18 = $131.40.


Storage
Storage


You are charged for the disks used by deployed applications. Charges are based on disk sizes, regardless of the amount of used space.




Billing unit
: 1 byte per 1 second


Pricing unit
: 1 GiB per 730 hours (2
30
 bytes per 2,628,000 seconds ~ 1 month)










Item


Price per 1 GiB per 730 hours










Standalone application. Network SSD disk


$0.071








Previous
Working with notebooks
Next
Quotas
In this article:
How charges and prices work
Prices
Computing resources
NVIDIA® H100 NVLink with Intel Sapphire Rapids
NVIDIA® H200 NVLink with Intel Sapphire Rapids
NVIDIA® L40S PCIe with Intel Ice Lake
NVIDIA® L40S PCIe with AMD Epyc Genoa
Non-GPU AMD EPYC Genoa
Non-GPU Intel Ice Lake
Storage

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[applications/standalone/manage]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[applications/types]]
- [[compute]]
- [[compute/clusters/gpu]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/resources/pricing]]
- [[compute/resources/quotas-limits]]
- [[compute/storage/boot-disk-images]]
- [[compute/storage/detach-volume]]
- [[compute/storage/manage]]
- [[compute/storage/types]]
- [[compute/storage/use]]
- [[compute/virtual-machines/connect]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/list-platforms]]
- [[compute/virtual-machines/maintenance]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/network]]
- [[compute/virtual-machines/not-enough-resources]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/types]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry]]
- [[container-registry/quickstart]]
- [[container-registry/registries/manage]]
- [[container-registry/resources/pricing]]
- [[container-registry/resources/quotas-limits]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/pricing]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal/agreement]]
- [[legal/archive/agreement-20240917]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/specific-terms/container-registry-20240925]]
- [[legal/archive/specific-terms/managed-mlflow-20240830]]
- [[legal/archive/specific-terms/managed-postgresql-20240925]]
- [[legal/archive/specific-terms/managed-spark-20240925]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[legal/studio/archive/terms-of-use-20240828]]
- [[legal/studio/archive/terms-of-use-20241220]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/terms-of-use]]
- [[mlflow]]
- [[mlflow/clusters/manage]]
- [[mlflow/monitoring]]
- [[mlflow/quickstart]]
- [[mlflow/resources/pricing]]
- [[mlflow/resources/quotas-limits]]
- [[object-storage]]
- [[object-storage/buckets/manage]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/monitoring]]
- [[object-storage/objects/lifecycles]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[object-storage/objects/versioning]]
- [[object-storage/overview]]
- [[object-storage/quickstart]]
- [[object-storage/resources/pricing]]
- [[object-storage/resources/quotas-limits]]
- [[observability]]
- [[observability/alerts]]
- [[observability/dashboards]]
- [[observability/logging]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/logs/query-language]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[observability/monitoring]]
- [[observability/resources/pricing]]
- [[observability/resources/quotas-limits]]
- [[observability/services]]
- [[postgresql]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/extensions]]
- [[postgresql/databases/manage]]
- [[postgresql/databases/users]]
- [[postgresql/monitoring]]
- [[postgresql/quickstart]]
- [[postgresql/replication/from-external]]
- [[postgresql/resources/pricing]]
- [[postgresql/resources/quotas-limits]]
- [[spark]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/resources/pricing]]
- [[spark/resources/quotas-limits]]
- [[spark/sessions/manage]]
- [[vpc]]
- [[vpc/addressing/available-addresses]]
- [[vpc/addressing/custom-private-addresses]]
- [[vpc/addressing/disable-public-addresses]]
- [[vpc/networking/isolation]]
- [[vpc/networking/resources]]
- [[vpc/overview]]
- [[vpc/resources/pricing]]
- [[vpc/resources/quotas-limits]]