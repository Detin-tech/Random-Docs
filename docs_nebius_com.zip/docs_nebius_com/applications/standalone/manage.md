Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
Managing applications
Deploying and deleting applications
Deploying and deleting applications in Standalone Applications in Nebius AI Cloud
Prerequisites
How to deploy an application
How to delete an application
To work with an application in the Standalone Applications service, you need to deploy it in your project in the
web console
.


Deployed applications are subject to
charges
 and
quotas
. When you are finished working with an application, you can delete it. Deleting your data is a permanent action. To keep the data and save costs, you can
stop
 the application instead.


Prerequisites
Prerequisites


For both deploying and deleting an application, make sure you are in your tenant's
editors
 group. You can check if you are in this group in the
Access
 section of the web console.


How to deploy an application
How to deploy an application


Note


You can deploy each application in a project once. To deploy an application again, you need to delete its previous deployment.




In the sidebar, go to
Applications
.


Under
Standalone applications
, find the application you want to use and click
Deploy
.


Configure the application. For more details on the settings of specific applications, see their
documentation
.


Click
Deploy application
.


Wait until the status is
Running
. For the first standalone application in the project, it takes around 40 minutes. For subsequent applications, it takes 15–20 minutes.




How to delete an application
How to delete an application


Warning


When you delete an application, all the data that you stored in it is permanently deleted. If you want to stop using the application temporarily and save costs, see
Stopping and starting applications in Standalone Applications in Nebius AI Cloud
.




In the sidebar, go to
Applications
.


Under
Standalone applications
, find the application you want to use and click
See details
.


On the
Settings
 tab, click
Delete application
.


To confirm that you want to delete the application, enter its name and click
Delete application
.




Previous
Overview
Next
Stopping and starting applications
In this article:
Prerequisites
How to deploy an application
How to delete an application

---

**Related:**

- [[applications]]
- [[applications/types]]
- [[cli/configure]]
- [[cli/reference]]
- [[cli/reference/applications/v1alpha1/k-8-s-release]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/config]]
- [[cli/reference/iam/access-key]]
- [[cli/reference/iam/access-key/operation]]
- [[cli/reference/iam/access-permit]]
- [[cli/reference/iam/access-permit/operation]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/federated-credentials]]
- [[cli/reference/iam/federated-credentials/operation]]
- [[cli/reference/iam/federation]]
- [[cli/reference/iam/federation-certificate]]
- [[cli/reference/iam/federation-certificate/operation]]
- [[cli/reference/iam/federation/operation]]
- [[cli/reference/iam/group]]
- [[cli/reference/iam/group-membership]]
- [[cli/reference/iam/group-membership/operation]]
- [[cli/reference/iam/group/operation]]
- [[cli/reference/iam/invitation]]
- [[cli/reference/iam/invitation/operation]]
- [[cli/reference/iam/project]]
- [[cli/reference/iam/project/operation]]
- [[cli/reference/iam/service-account]]
- [[cli/reference/iam/service-account/operation]]
- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/tenant-user-account]]
- [[cli/reference/iam/tenant-user-account/operation]]
- [[cli/reference/iam/v2/access-key]]
- [[cli/reference/iam/v2/access-key/operation]]
- [[cli/reference/mk8s/cluster]]
- [[cli/reference/mk8s/cluster/operation]]
- [[cli/reference/mk8s/node-group]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/cluster]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/cluster]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation]]
- [[cli/reference/msp/spark/v1alpha1/job]]
- [[cli/reference/msp/spark/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/session]]
- [[cli/reference/msp/spark/v1alpha1/session/operation]]
- [[cli/reference/profile]]
- [[cli/reference/registry]]
- [[cli/reference/registry/image]]
- [[cli/reference/registry/image/operation]]
- [[cli/reference/registry/operation]]
- [[cli/reference/storage/bucket]]
- [[cli/reference/storage/bucket/operation]]
- [[cli/reference/storage/v1alpha1/transfer]]
- [[cli/reference/storage/v1alpha1/transfer/operation]]
- [[cli/reference/vpc/allocation]]
- [[cli/reference/vpc/allocation/operation]]
- [[cli/reference/vpc/network]]
- [[cli/reference/vpc/network/operation]]
- [[cli/reference/vpc/pool]]
- [[cli/reference/vpc/pool/operation]]
- [[cli/reference/vpc/subnet]]
- [[cli/reference/vpc/subnet/operation]]
- [[cli/reference/vpc/v1alpha1/allocation]]
- [[cli/reference/vpc/v1alpha1/allocation/operation]]
- [[compute]]
- [[compute/clusters/skypilot]]
- [[compute/monitoring/virtual-machines]]
- [[compute/resources/quotas-limits]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/stop-start]]
- [[container-registry]]
- [[container-registry/quickstart]]
- [[container-registry/registries/manage]]
- [[container-registry/resources/quotas-limits]]
- [[iam]]
- [[iam/authorization/add-users]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/federations/configure-sso]]
- [[iam/overview]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[iam/service-accounts/manage]]
- [[kubernetes]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal/agreement]]
- [[legal/archive/agreement-20240917]]
- [[legal/archive/cookie-policy-20240830]]
- [[legal/archive/cookies-list-20240930]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/specific-terms/container-registry-20240925]]
- [[legal/archive/specific-terms/managed-mlflow-20240830]]
- [[legal/archive/specific-terms/managed-postgresql-20240925]]
- [[legal/cookie-policy]]
- [[legal/cookies-list]]
- [[legal/hr-privacy-policy]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[legal/studio/archive/terms-of-use-20240828]]
- [[legal/studio/archive/terms-of-use-20241220]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/terms-of-use]]
- [[legal/terms-of-use]]
- [[mlflow/quickstart]]
- [[mlflow/resources/quotas-limits]]
- [[object-storage]]
- [[object-storage/buckets/manage]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[object-storage/quickstart]]
- [[object-storage/resources/quotas-limits]]
- [[observability/logs/grafana]]
- [[observability/metrics/grafana]]
- [[observability/metrics/prometheus]]
- [[overview/services]]
- [[overview/subscriptions]]
- [[overview/subscriptions/manage-subscriptions]]
- [[postgresql]]
- [[postgresql/clusters/manage]]
- [[postgresql/databases/extensions]]
- [[postgresql/databases/users]]
- [[postgresql/quickstart]]
- [[postgresql/resources/quotas-limits]]
- [[signup-billing/payments/invoices]]
- [[slurm-soperator]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/manage]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/users/manage]]
- [[spark]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/resources/quotas-limits]]
- [[spark/sessions/manage]]
- [[studio/prompt-presets]]
- [[terraform-provider]]
- [[terraform-provider/authentication]]
- [[terraform-provider/quickstart]]
- [[terraform-provider/reference]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/resources/compute_v1_instance]]
- [[vpc/overview]]
- [[vpc/resources/quotas-limits]]