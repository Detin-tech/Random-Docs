Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
JupyterLab®
Connecting to application
Connecting to the JupyterLab® application in Nebius AI Cloud
Prerequisites
How to connect
What's next
After
deploying the JupyterLab application
, you can connect to it in the
web console
.


Prerequisites
Prerequisites




Make sure you are in your tenant's
editors
 group. You can check if you are in this group in the
Access
 section of the web console.


Download the
Nebius AI Cloud certificate
 and install it according to your operating system instructions.




How to connect
How to connect




In the sidebar, go to
Applications
.


Under
Standalone applications
, find your application and click
See details
.


Under
Artifacts
, copy the URL from
Public endpoint
.


Go to the URL in your web browser.


Log in to the JupyterLab UI by using the username and password that you specified when deploying the application.




What's next
What's next


After connecting to the application, you can
work with notebooks
.




"Jupyter" and the Jupyter logos are trademarks or registered trademarks of LF Charities, used by Nebius B.V. with permission.


Previous
Deploying application
Next
Working with notebooks
In this article:
Prerequisites
How to connect
What's next

---

**Related:**

- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/deploy]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[compute]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/storage/use]]
- [[compute/virtual-machines/connect]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/wireguard]]
- [[iam/federations/configure-sso]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/quickstart]]
- [[kubernetes/storage/disk-over-csi]]
- [[mlflow/quickstart]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/quickstart]]
- [[observability/dashboards]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[overview/services]]
- [[postgresql]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/manage]]
- [[postgresql/databases/users]]
- [[postgresql/quickstart]]
- [[postgresql/replication/from-external]]
- [[slurm-soperator]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/containers/apptainer]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/jobs/manage]]
- [[slurm-soperator/monitoring/statuses]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/storage/download-data]]
- [[slurm-soperator/users/manage]]
- [[spark/quickstart]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[terraform-provider/reference/data-sources/compute_v1_gpu_cluster]]
- [[terraform-provider/reference/data-sources/msp_spark_v1alpha1_session]]
- [[terraform-provider/reference/resources/compute_v1_gpu_cluster]]
- [[terraform-provider/reference/resources/msp_spark_v1alpha1_session]]
- [[vpc/addressing/disable-public-addresses]]
- [[vpc/networking/isolation]]