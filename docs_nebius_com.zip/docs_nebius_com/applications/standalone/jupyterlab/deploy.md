Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
JupyterLab®
Deploying application
Deploying the JupyterLab® application in Nebius AI Cloud
Prerequisites
How to deploy
What's next
To work with JupyterLab notebooks in Nebius AI Cloud, you can deploy the JupyterLab application in the
web console
.


Prerequisites
Prerequisites


Make sure you are in your tenant's
editors
 group. You can check if you are in this group in the
Access
 section of the web console.


How to deploy
How to deploy






In the sidebar, go to
Applications
.






Under
Standalone applications
, find JupyterLab and click
Deploy
.






Configure the application:






Enter the application name.






Select the network where the application should be located. This network will allocate private and public IP addresses to the application. The
Network
 field is only shown if your project has more than one network.






Configure the credentials that you will use to log in to JupyterLab:




Enter the username. It must be between 1 and 63 characters long, and consist of Latin letters, digits, hyphens and underscores. It cannot start with a hyphen.


Copy the generated password, save it securely and confirm that you saved it. To get another password, click
Generate
.








Under
Resources
, configure the application's computing and storage resources:




Select
With GPU
 or
Without GPU
.


Select a platform and preset. For available platforms and presets, see
Types of virtual machines and GPUs in Nebius AI Cloud
 and
How to find out platforms and presets available in a project
.


Specify the disk size.




Computing resources of an application determine how much you pay for using it and are subject to quotas. For more details, see
Standalone Applications pricing in Nebius AI Cloud
 and
Standalone Applications quotas in Nebius AI Cloud
.










Click
Deploy application
.






Wait until the status is
Running
. For the first application from the Standalone Applications service in the project, it takes around 40 minutes. For subsequent applications, it takes 15–20 minutes.






What's next
What's next


When the application is running, you can
connect to it
.




"Jupyter" and the Jupyter logos are trademarks or registered trademarks of LF Charities, used by Nebius B.V. with permission.


Previous
What is JupyterLab?
Next
Connecting to application
In this article:
Prerequisites
How to deploy
What's next

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/manage]]
- [[applications/types]]
- [[compute/quickstart-host-model]]
- [[compute/virtual-machines/wireguard]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[legal/specific-terms/applications/standalone]]
- [[mlflow]]
- [[mlflow/quickstart]]
- [[overview/services]]
- [[spark/quickstart]]
- [[studio]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/fine-tuning/models]]
- [[studio/inference/models]]
- [[terraform-provider/quickstart]]