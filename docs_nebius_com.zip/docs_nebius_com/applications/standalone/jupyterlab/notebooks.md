Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
JupyterLab®
Working with notebooks
Working with notebooks in the JupyterLab® application in Nebius AI Cloud
Python dependencies
Working with files
After
deploying the JupyterLab application
 in Nebius AI Cloud and
connecting to it
, you can work with JupyterLab notebooks. For more details, see the
JupyterLab documentation
.


Python dependencies
Python dependencies


Notebooks in the JupyterLab application include
PyTorch
 by default.


To install more Python dependencies in a notebook, run
!pip install <package_name> ...
 in a notebook cell:




!pip install pandas numpy























Working with files
Working with files


To open the JupyterLab's file browser, click
 in the left sidebar. You can upload files by dragging and dropping them onto the file browser or by clicking
 Upload
. To download a file, right-click it in the file browser and click
 Download
.


For more details, see the
JupyterLab documentation
.




"Jupyter" and the Jupyter logos are trademarks or registered trademarks of LF Charities, used by Nebius B.V. with permission.


Previous
Connecting to application
Next
Pricing
In this article:
Python dependencies
Working with files

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/manage]]
- [[applications/standalone/pricing]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[applications/types]]