Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
JupyterLab®
What is JupyterLab?
JupyterLab® in Nebius AI Cloud
About the application
Getting started
Nebius AI Cloud offers JupyterLab in Standalone Applications.


About the application
About the application


JupyterLab
 is a next-generation web interface for
Project Jupyter
. The application provides a flexible and powerful environment for data science, machine learning and scientific computing. It includes
PyTorch
, a popular deep learning framework, and
CUDA®
 support for GPU acceleration.


For more details, see the
application page
 in the web console.


JupyterLab is an open-source product, its use in source and binary forms is governed by its
license
.


Getting started
Getting started


To use the JupyterLab application,
deploy it
 and
connect to it
.




"Jupyter" and the Jupyter logos are trademarks or registered trademarks of LF Charities, used by Nebius B.V. with permission.


Previous
Stopping and starting applications
Next
Deploying application
In this article:
About the application
Getting started

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[applications/standalone/manage]]
- [[applications/standalone/pricing]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[applications/types]]