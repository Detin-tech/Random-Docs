Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
Managing applications
Stopping and starting applications
Stopping and starting applications in Standalone Applications in Nebius AI Cloud
Prerequisites
How to stop and start an application
If you are not using the application that you have deployed, you can stop it in the
web console
 to save costs. While the application is stopped, you are
charged
 for its storage but not for its computing resources (GPUs, vCPUs and RAM). When you need the application again, you can restart it.


The application keeps the data that you saved in it, although you can only access it after you restart the application.


The restart takes around 15 minutes.


Computing and storage resources of a stopped application count towards
Standalone Applications quotas
, just like a running application.


Prerequisites
Prerequisites


Make sure you are in your tenant's
editors
 group. You can check if you are in this group in the
Access
 section of the web console.


How to stop and start an application
How to stop and start an application




In the sidebar, go to
Applications
.


Under
Standalone applications
, find your application, and click
Stop
 or
Start
.




Previous
Deploying and deleting applications
Next
What is JupyterLab?
In this article:
Prerequisites
How to stop and start an application