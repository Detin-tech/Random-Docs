Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Standalone Applications
Overview
Standalone Applications in Nebius AI Cloud
Applications in the Standalone Applications service in Nebius AI Cloud deploy their own infrastructure.


Standalone Applications are only available in the
eu-north1

region
.


Available applications
Available applications


Nebius AI Cloud offers JupyterLab® in Standalone Applications. It is a web-based IDE for notebooks, code and data science tasks.


View in web console
 |
Documentation




"Jupyter" and the Jupyter logos are trademarks or registered trademarks of LF Charities, used by Nebius B.V. with permission.


Previous
Types and stages
Next
Deploying and deleting applications

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[applications/standalone/manage]]
- [[applications/standalone/pricing]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[applications/types]]
- [[index]]
- [[legal/archive/sla-levels/index-20250313]]
- [[legal/archive/specific-terms/index-20250313]]
- [[legal/archive/specific-terms/index-20250410]]
- [[legal/sla-levels]]
- [[legal/sla-levels/applications/standalone]]
- [[legal/sla-levels/compute]]
- [[legal/sla-levels/managed-kubernetes]]
- [[legal/sla-levels/managed-mlflow]]
- [[legal/sla-levels/managed-postgresql]]
- [[legal/sla-levels/storage]]
- [[legal/sla-levels/vpc]]
- [[legal/specific-terms]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[legal/studio/archive/terms-of-use-20240828]]
- [[legal/studio/archive/terms-of-use-20241220]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/terms-of-use]]
- [[overview/quotas]]
- [[overview/services]]
- [[signup-billing/billing-models/payg]]