Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Types and stages of applications in Nebius AI Cloud
Application types
Stages
Each application in Nebius AI Cloud has a type, and goes through some of the application stages.


Application types
Application types


Nebius AI Cloud offers two types of applications:




The
Standalone Applications service
 offers applications that deploy and manage their own infrastructure.


Applications for Managed Service for Kubernetes®
 require a
Managed Kubernetes cluster
 with at least one
node group
.




Stages
Stages


Each application is either
in preview
 (for testing and feedback, free of charge) or
generally available
 (for production environments, usually paid). For more information, see
Service and application stages
 in the Nebius AI Cloud overview.


If an application stage is not explicitly marked as in preview, the application is generally available.


Next
Overview
In this article:
Application types
Stages

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[applications/standalone/manage]]
- [[applications/standalone/pricing]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[audit-logs/events/reference]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/filesystem/create]]
- [[compute]]
- [[compute/clusters/gpu]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/resources/pricing]]
- [[compute/resources/quotas-limits]]
- [[compute/storage/boot-disk-images]]
- [[compute/storage/detach-volume]]
- [[compute/storage/manage]]
- [[compute/storage/types]]
- [[compute/storage/use]]
- [[compute/virtual-machines/connect]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/list-platforms]]
- [[compute/virtual-machines/maintenance]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/network]]
- [[compute/virtual-machines/not-enough-resources]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/types]]
- [[compute/virtual-machines/wireguard]]
- [[iam/overview]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[legal/archive/cookie-policy-20240830]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/cookie-policy]]
- [[legal/hr-privacy-policy]]
- [[legal/tsr]]
- [[object-storage/monitoring]]
- [[observability/dashboards]]
- [[observability/metrics/ingest]]
- [[overview/support]]
- [[postgresql/databases/extensions]]
- [[signup-billing]]
- [[signup-billing/billing-models/committed-usage]]
- [[signup-billing/billing-models/overview]]
- [[signup-billing/billing-models/payg]]
- [[signup-billing/payments/bank-transfers]]
- [[signup-billing/payments/card]]
- [[signup-billing/payments/invoices]]
- [[signup-billing/payments/payers]]
- [[signup-billing/payments/promo-codes]]
- [[signup-billing/payments/taxes]]
- [[signup-billing/payments/threshold]]
- [[signup-billing/sign-up]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/storage/download-data]]
- [[spark/jobs/run]]
- [[spark/sessions/manage]]
- [[studio/billing]]
- [[studio/fine-tuning/datasets]]
- [[studio/inference/integrations]]
- [[studio/inference/integrations/llamaindex]]
- [[studio/inference/models]]
- [[studio/prompt-presets]]
- [[terraform-provider/authentication]]
- [[terraform-provider/reference]]
- [[terraform-provider/reference/data-sources/compute_v1_disk]]
- [[terraform-provider/reference/data-sources/compute_v1_filesystem]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_disk]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_filesystem]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/compute_v1_disk]]
- [[terraform-provider/reference/resources/compute_v1_filesystem]]
- [[terraform-provider/reference/resources/compute_v1_instance]]
- [[terraform-provider/reference/resources/compute_v1alpha1_disk]]
- [[terraform-provider/reference/resources/compute_v1alpha1_filesystem]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]