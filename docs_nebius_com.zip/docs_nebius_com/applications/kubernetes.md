Applications in Nebius AI Cloud
Types and stages
Standalone Applications
Overview
Managing applications
Deploying and deleting applications
Stopping and starting applications
JupyterLab®
What is JupyterLab?
Deploying application
Connecting to application
Working with notebooks
Pricing
Quotas
Applications for Managed Kubernetes®
Overview
Deploying and deleting applications
Applications for Managed Kubernetes®
Overview
Applications for Managed Service for Kubernetes® in Nebius AI Cloud
Applications for Managed Service for Kubernetes
 are applications that you can deploy on
Managed Kubernetes
 clusters in Nebius AI Cloud.


To get started with applications for Managed Kubernetes, in the web console's sidebar, go to
Applications
. There, you can find the available applications and deploy them. For more details, see
Finding, deploying and deleting applications for Managed Service for Kubernetes® in Nebius AI Cloud
.


Each application requires a Managed Kubernetes cluster with at least one node group. If you do not have them, you can set them up when you deploy the application. Also, you can create them manually beforehand. For more details, see
How to create and modify Managed Service for Kubernetes® clusters
 and
Creating and modifying Managed Service for Kubernetes® node groups
.


Applications for Managed Kubernetes are not subject to their own quotas and charges. Only Managed Kubernetes
quotas
 and
charges
 apply to clusters and nodes that host the applications.


Previous
Quotas
Next
Deploying and deleting applications

---

**Related:**

- [[applications]]
- [[applications/kubernetes/manage]]
- [[applications/standalone]]
- [[applications/standalone/jupyterlab]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[applications/standalone/manage]]
- [[applications/standalone/pricing]]
- [[applications/standalone/quotas]]
- [[applications/standalone/stop-start]]
- [[applications/types]]
- [[cli/quickstart]]
- [[cli/reference/mk8s/cluster/create]]
- [[cli/reference/mk8s/cluster/update]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/node-group/upgrade]]
- [[cli/reference/mk8s/v1alpha1/cluster/create]]
- [[cli/reference/mk8s/v1alpha1/cluster/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/upgrade]]
- [[compute/clusters/gpu]]
- [[compute/clusters/mpirun]]
- [[compute/monitoring/virtual-machines]]
- [[compute/storage/types]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/maintenance]]
- [[iam/authorization/groups]]
- [[iam/overview]]
- [[index]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/pricing]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal/archive/sla-levels/index-20240925]]
- [[legal/archive/sla-levels/index-20250219]]
- [[legal/archive/sla-levels/index-20250304]]
- [[legal/archive/sla-levels/index-20250313]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/archive/specific-terms/index-20240925]]
- [[legal/archive/specific-terms/index-20241023]]
- [[legal/archive/specific-terms/index-20250313]]
- [[legal/archive/specific-terms/index-20250410]]
- [[legal/sla-levels]]
- [[legal/sla-levels/applications/standalone]]
- [[legal/sla-levels/compute]]
- [[legal/sla-levels/managed-kubernetes]]
- [[legal/sla-levels/managed-mlflow]]
- [[legal/sla-levels/managed-postgresql]]
- [[legal/sla-levels/storage]]
- [[legal/sla-levels/vpc]]
- [[legal/specific-terms]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[object-storage/buckets/manage]]
- [[observability]]
- [[observability/alerts]]
- [[observability/dashboards]]
- [[observability/logging]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/logs/query-language]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[observability/monitoring]]
- [[observability/resources/pricing]]
- [[observability/resources/quotas-limits]]
- [[observability/services]]
- [[overview/data-deletion]]
- [[overview/quotas]]
- [[overview/regions]]
- [[overview/services]]
- [[postgresql/clusters/manage]]
- [[signup-billing/billing-models/payg]]
- [[slurm-soperator]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/monitoring/statuses]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/overview/why-slurm-soperator]]
- [[terraform-provider/reference/data-sources/mk8s_v1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]
- [[vpc/networking/isolation]]
- [[vpc/overview]]