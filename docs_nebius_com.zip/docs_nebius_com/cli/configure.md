Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
How to set up the Nebius AI Cloud CLI
Authorize with a user account
Authorize with a service account
To configure the Nebius AI Cloud CLI, use one of the authorization options:




A user account
 offers personalized access and accountability. It can be used when you, as a human user, need to manage and interact with resources.


A service account
 automates the interaction of applications and services with resources.




Authorize with a user account
Authorize with a user account


To authorize quickly, follow the non-interactive flow. To control the authorization process, follow the interactive flow.






Non-interactive flow


Interactive flow










Open your terminal.






Create a name of your new profile in the Nebius AI Cloud CLI and save it to an environment variable:




export
 NB_PROFILE_NAME=<new-profile-name>



























Copy your project ID from the web console
Project settings
 and save it to an environment variable:




export
 NB_PROJECT_ID=<project_ID>



























Run the following command:




nebius profile create \
    --profile
$NB_PROFILE_NAME
 \
    --endpoint api.nebius.cloud \
    --federation-endpoint auth.eu.nebius.com \
    --parent-id
$NB_PROJECT_ID
























If you are added to someone else's
tenant
 and know the ID of its
federation
, you can specify it either in the
--federation-id
 parameter, or when logging into the Nebius AI Cloud web console after running the command.






In the browser tab that opens, log into the web console if prompted. After logging in (or if you have already been logged in), you will see the following message:




Login is successful, you may close the browser tab and go to the console



























Close the browser tab and go back to your terminal window. You will see the following message:




Profile "<profile-name>" configured and activated



























Verify that your new profile has been created and set as the default:




nebius profile list























You should see the following output:




default
<profile-name> [default]



































Open your terminal.






Run the following command:




nebius profile create



























Set up the new profile:






Using arrow keys, select
Create a new profile
 and press
Enter
.






Specify the profile name and press
Enter
.






Keep the default value for
Select api endpoint
 (
api.nebius.cloud
) and press
Enter
.






Under
Select authorization type
, keep
federation
 and press
Enter
.






Keep the default value for
Select federation endpoint
 (
auth.eu.nebius.com
) and press
Enter
.






In the browser tab that opens, log into the Nebius AI Cloud web console if prompted. After logging in (or if you have already been logged in), you will see the following message:




Login is successful, you may close the browser tab and go to the console



























Close the browser tab and go back to your terminal window. You'll see the message:




Profile "<profile-name>" configured and activated































Verify that your new profile has been created and set as the default:




nebius profile list























You should see the following output:




default
<profile-name> [default]



























Add the project ID provided to you by the Nebius team to the CLI configuration:




nebius config
set
 parent-id <project_ID>































Authorize with a service account
Authorize with a service account


Before authorization,
create a service account
. You can do it using a user account or another service account within the
admins
 group.


To authorize quickly, follow the non-interactive flow. To control the authorization process, follow the interactive flow.






Non-interactive flow


Interactive flow










Open the service account page in the web console and view the service account details. You'll need to view the service account's details from there.






Open your terminal.






Open the service account page in the web console.






Save the service account details to environment variables:




export
 SA_ID=<service-account-id>

export
 PUBLIC_KEY_ID=<...>

export
 PRIVATE_KEY_PATH=<...>



























Create a name for your profile and save it to an environment variable:




export
 SA_PROFILE_NAME=<...>























For example,
gpu-monitoring-sa
.


Use one profile per project


Create a separate Nebius AI Cloud CLI profile for each project to ensure correct
region
-specific configuration.






Copy your project ID from the web console
Project settings
 and save it to an environment variable:




export
 NB_PROJECT_ID=<project_ID>



























Run the following command:




nebius profile create \
    --endpoint api.nebius.cloud \
    --service-account-id
$SA_ID
 \
    --public-key-id
$PUBLIC_KEY_ID
 \
    --private-key-file
$PRIVATE_KEY_PATH
 \
    --profile
$SA_PROFILE_NAME
 \
    --parent-id
$NB_PROJECT_ID
























You will see the following message:




Profile "<profile-name>" configured and activated



























Check that your new profile has been created and set as the default one:




nebius profile list























You should see the following output:




default
<profile-name> [default]



































Open the service account page in the web console and view the service account details. You'll need to view the service account's details from there.






Open your terminal.






Run the following command:




nebius profile create



























Use the arrow keys to select
Create a new profile
, then click
Enter
.


Use one profile per project


Create a separate Nebius AI Cloud CLI profile for each project to ensure correct
region
-specific configuration.






Add a profile name and click
Enter
.






Keep the default value for
Select api endpoint
 (
api.nebius.cloud
) and click
Enter
.






Under
Select authorization type
, choose
service account
 and click
Enter
.






Under
Set service account ID
, paste the
Service account ID
 from the web console.






Under
Set public key ID
, paste the
Public key ID
 from the web console.






Under
Set path to PEM encoded private key
, specify the path to your private key in PEM format.


You will see the following message:




Profile "<profile-name>" configured and activated



























Check that your new profile has been created and set the default one:




nebius profile list























You should see the following output:




default
<profile-name> [default]



























Add the project ID provided to you by the Nebius team to the CLI configuration:




nebius config
set
 parent-id <project_ID>































Previous
Installing the CLI
Next
Release notes
In this article:
Authorize with a user account
Authorize with a service account

---

**Related:**

- [[applications/kubernetes/manage]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/manage]]
- [[audit-logs/events/view]]
- [[cli]]
- [[cli/quickstart]]
- [[cli/reference/registry]]
- [[cli/reference/registry/configure-helper]]
- [[cli/reference/registry/create]]
- [[cli/reference/registry/create-helper]]
- [[cli/reference/registry/delete]]
- [[cli/reference/registry/docker-credential]]
- [[cli/reference/registry/docker-credential/get]]
- [[cli/reference/registry/edit]]
- [[cli/reference/registry/get]]
- [[cli/reference/registry/image]]
- [[cli/reference/registry/image/delete]]
- [[cli/reference/registry/image/get]]
- [[cli/reference/registry/image/list]]
- [[cli/reference/registry/image/operation]]
- [[cli/reference/registry/image/operation/get]]
- [[cli/reference/registry/image/operation/list]]
- [[cli/reference/registry/image/operation/wait]]
- [[cli/reference/registry/list]]
- [[cli/reference/registry/operation]]
- [[cli/reference/registry/operation/get]]
- [[cli/reference/registry/operation/list]]
- [[cli/reference/registry/operation/wait]]
- [[cli/reference/registry/update]]
- [[compute]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[compute/quickstart-host-model]]
- [[compute/storage/use]]
- [[compute/virtual-machines/connect]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry/quickstart]]
- [[iam/authorization/add-users]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/federations/configure-sso]]
- [[iam/log-in]]
- [[iam/manage-projects]]
- [[iam/overview]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[legal/specific-terms/applications/standalone]]
- [[mlflow/clusters/manage]]
- [[mlflow/monitoring]]
- [[mlflow/quickstart]]
- [[object-storage/buckets/manage]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/monitoring]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[object-storage/quickstart]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[overview/quotas]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/monitoring]]
- [[postgresql/quickstart]]
- [[postgresql/replication/from-external]]
- [[slurm-soperator/jobs/containers/pyxis-enroot]]
- [[slurm-soperator/storage/download-data]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/sessions/manage]]
- [[studio/billing]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/portkey]]
- [[terraform-provider/authentication]]
- [[terraform-provider/quickstart]]
- [[terraform-provider/reference/provider]]
- [[vpc/overview]]