Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
How to install Nebius AI Cloud CLI
The Nebius AI Cloud CLI is available for both Ubuntu and macOS.


Note


The old installer script (
https:/[[../../s]]torage.ai.nebius.cloud/nebius/install.sh
) has been deprecated. If you got an error trying to update the Nebius AI Cloud CLI, please reinstall it using the new script:
curl -sSL [[../cli/install.sh]] | bash
.






Open your terminal.






Run the command:




curl -sSL [[../cli/install.sh]] | bash



























To complete the installation, restart your terminal or run
exec -l $SHELL
.






Make sure that the installation is successful. Run:




nebius version























In the output, you'll see the version number of your Nebius AI Cloud CLI.






Go to
How to set up the Nebius AI Cloud CLI
.






Setting up command autocompletion
Setting up command autocompletion


During setup, your shell will enable Nebius AI Cloud CLI autocompletion by default. If it doesn't happen, use one of the solutions below:






Permanent solution


Single-session solution






Run the following command:




nebius completion zsh > ~[[../../.nebius]]completion.zsh.inc

echo

'if [ -f '
~[[../../.nebius]]completion.zsh.inc
' ]; then source '
~[[../../.nebius]]completion.zsh.inc
'; fi'
 >> ~[[../.zshrc]]



























The command below will generate a new completion file each time you create a new session. The example below is for ZSH:




echo

'source <(nebius completion zsh)'
 >> ~[[../.zshrc]]



























Previous
Getting started with the CLI
Next
Setting up the CLI

---

**Related:**

- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/notebooks]]
- [[cli]]
- [[cli/quickstart]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/storage/boot-disk-images]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry/quickstart]]
- [[iam/authorization/add-users]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/federations/configure-sso]]
- [[iam/log-in]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[iam/service-accounts/manage]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/specific-terms/applications]]
- [[mlflow/clusters/manage]]
- [[mlflow/quickstart]]
- [[object-storage/buckets/manage]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[object-storage/quickstart]]
- [[observability/dashboards]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/extensions]]
- [[postgresql/quickstart]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/containers/apptainer]]
- [[slurm-soperator/jobs/containers/docker]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/sessions/manage]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/inference/integrations/aisuite]]
- [[studio/inference/integrations/continue]]
- [[studio/inference/integrations/huggingface]]
- [[studio/inference/integrations/llamaindex/embedding]]
- [[studio/inference/integrations/llamaindex/text-to-text]]
- [[studio/inference/integrations/llamaindex/vision]]
- [[studio/inference/integrations/portkey]]
- [[studio/inference/integrations/postman]]
- [[terraform-provider/authentication]]
- [[terraform-provider/install]]
- [[terraform-provider/quickstart]]
- [[vpc/addressing/custom-private-addresses]]
- [[vpc/addressing/disable-public-addresses]]
- [[vpc/networking/isolation]]