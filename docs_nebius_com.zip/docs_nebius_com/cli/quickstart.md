Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
Getting started with the Nebius AI Cloud CLI: How to install and configure the tool
Install the Nebius AI Cloud CLI
Configure the Nebius AI Cloud CLI
What's next
Nebius AI Cloud provides a unified
command-line interface
 (CLI) for automating your resource management. It helps you efficiently handle repetitive tasks and scale workloads directly from the terminal.


Install the Nebius AI Cloud CLI
Install the Nebius AI Cloud CLI


Note


The old installer script (
https:/[[../../s]]torage.ai.nebius.cloud/nebius/install.sh
) has been deprecated. If you got an error trying to update the Nebius AI Cloud CLI, please reinstall it using the new script:
curl -sSL [[../cli/install.sh]] | bash
.


The Nebius AI Cloud CLI is available for both Ubuntu and macOS.






Open your terminal and run the command:




curl -sSL [[../cli/install.sh]] | bash



























Restart your terminal or run
exec -l $SHELL
 to complete the installation.






Make sure that the installation is successful. Run:




nebius version























In the output, you'll see the version number of your Nebius AI Cloud CLI.






Configure the Nebius AI Cloud CLI
Configure the Nebius AI Cloud CLI


Use one profile per project


Create a separate Nebius AI Cloud CLI profile for each project to ensure correct
region
-specific configuration.






Copy your project ID from the web console
Project settings
 and save it to an environment variable:




export
 NB_PROJECT_ID=<project_ID>



























Run the following command:




nebius profile create --parent-id
$NB_PROJECT_ID




























Set up the new profile:






Using arrow keys, select
Create a new profile
 and press
Enter
.






Specify the profile name and press
Enter
.






Keep the default value for
Select api endpoint
 (
api.nebius.cloud
) and press
Enter
.






Under
Select authorization type
, keep
federation
 and press
Enter
.






Keep the default value for
Select federation endpoint
 (
auth.eu.nebius.com
) and press
Enter
.






In the browser tab that opens, log into the Nebius AI Cloud web console if prompted. After logging in (or if you have already been logged in), you will see the following message:




Login is successful, you may close the browser tab and go to the console



























Close the browser tab and go back to your terminal window. You'll see the message:




Profile "<profile-name>" configured and activated































Check that your new profile has been created and set as the default one:




nebius profile list























You should see the following output:




default
<profile-name> [default]



























What's next
What's next


Create your first resources using the Nebius AI Cloud CLI:




Compute virtual machine


Managed Service for Kubernetes® cluster


Object Storage bucket




Next
Installing the CLI
In this article:
Install the Nebius AI Cloud CLI
Configure the Nebius AI Cloud CLI
What's next

---

**Related:**

- [[compute]]
- [[compute/clusters/gpu]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/resources/pricing]]
- [[compute/resources/quotas-limits]]
- [[compute/storage/boot-disk-images]]
- [[compute/storage/detach-volume]]
- [[compute/storage/manage]]
- [[compute/storage/types]]
- [[compute/storage/use]]
- [[compute/virtual-machines/connect]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/list-platforms]]
- [[compute/virtual-machines/maintenance]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/network]]
- [[compute/virtual-machines/not-enough-resources]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/types]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry]]
- [[container-registry/quickstart]]
- [[container-registry/registries/manage]]
- [[container-registry/resources/pricing]]
- [[container-registry/resources/quotas-limits]]
- [[iam/log-in]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/pricing]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal/sla-levels/compute]]
- [[mlflow]]
- [[mlflow/clusters/manage]]
- [[mlflow/monitoring]]
- [[mlflow/quickstart]]
- [[mlflow/resources/pricing]]
- [[mlflow/resources/quotas-limits]]
- [[object-storage]]
- [[object-storage/buckets/manage]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/monitoring]]
- [[object-storage/objects/lifecycles]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[object-storage/objects/versioning]]
- [[object-storage/overview]]
- [[object-storage/quickstart]]
- [[object-storage/resources/pricing]]
- [[object-storage/resources/quotas-limits]]
- [[postgresql]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/extensions]]
- [[postgresql/databases/manage]]
- [[postgresql/databases/users]]
- [[postgresql/monitoring]]
- [[postgresql/quickstart]]
- [[postgresql/replication/from-external]]
- [[postgresql/resources/pricing]]
- [[postgresql/resources/quotas-limits]]
- [[spark]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/resources/pricing]]
- [[spark/resources/quotas-limits]]
- [[spark/sessions/manage]]
- [[studio]]
- [[studio/api/authentication]]
- [[studio/api/examples]]
- [[studio/billing]]
- [[studio/fine-tuning]]
- [[studio/fine-tuning/datasets]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/fine-tuning/models]]
- [[studio/inference]]
- [[studio/inference/api]]
- [[studio/inference/batch]]
- [[studio/inference/integrations]]
- [[studio/inference/integrations/aisuite]]
- [[studio/inference/integrations/continue]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/huggingface]]
- [[studio/inference/integrations/llamaindex]]
- [[studio/inference/integrations/llamaindex/embedding]]
- [[studio/inference/integrations/llamaindex/text-to-text]]
- [[studio/inference/integrations/llamaindex/vision]]
- [[studio/inference/integrations/portkey]]
- [[studio/inference/integrations/postman]]
- [[studio/inference/json]]
- [[studio/inference/models]]
- [[studio/inference/models/embedding]]
- [[studio/inference/models/safety-guardrails]]
- [[studio/inference/models/text-to-image]]
- [[studio/inference/models/text-to-text]]
- [[studio/inference/models/vision]]
- [[studio/inference/playground]]
- [[studio/inference/quickstart]]
- [[studio/inference/rate-limits]]
- [[studio/inference/tool-calling]]
- [[studio/prompt-presets]]
- [[terraform-provider]]
- [[terraform-provider/authentication]]
- [[terraform-provider/install]]
- [[terraform-provider/quickstart]]
- [[terraform-provider/reference]]
- [[terraform-provider/reference/data-sources/applications_v1alpha1_k8s_release]]
- [[terraform-provider/reference/data-sources/compute_v1_disk]]
- [[terraform-provider/reference/data-sources/compute_v1_filesystem]]
- [[terraform-provider/reference/data-sources/compute_v1_gpu_cluster]]
- [[terraform-provider/reference/data-sources/compute_v1_image]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_disk]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_filesystem]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_gpu_cluster]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_image]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_instance]]
- [[terraform-provider/reference/data-sources/iam_v1_access_permit]]
- [[terraform-provider/reference/data-sources/iam_v1_auth_public_key]]
- [[terraform-provider/reference/data-sources/iam_v1_federated_credentials]]
- [[terraform-provider/reference/data-sources/iam_v1_federation]]
- [[terraform-provider/reference/data-sources/iam_v1_federation_certificate]]
- [[terraform-provider/reference/data-sources/iam_v1_group]]
- [[terraform-provider/reference/data-sources/iam_v1_group_membership]]
- [[terraform-provider/reference/data-sources/iam_v1_invitation]]
- [[terraform-provider/reference/data-sources/iam_v1_project]]
- [[terraform-provider/reference/data-sources/iam_v1_service_account]]
- [[terraform-provider/reference/data-sources/iam_v1_tenant]]
- [[terraform-provider/reference/data-sources/iam_v1_tenant_user_account]]
- [[terraform-provider/reference/data-sources/iam_v2_access_key]]
- [[terraform-provider/reference/data-sources/mk8s_v1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/data-sources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/msp_spark_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/msp_spark_v1alpha1_session]]
- [[terraform-provider/reference/data-sources/registry_v1_registry]]
- [[terraform-provider/reference/data-sources/storage_v1_bucket]]
- [[terraform-provider/reference/data-sources/vpc_v1_allocation]]
- [[terraform-provider/reference/data-sources/vpc_v1_network]]
- [[terraform-provider/reference/data-sources/vpc_v1_pool]]
- [[terraform-provider/reference/data-sources/vpc_v1_subnet]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_allocation]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_network]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_pool]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_scope]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_subnet]]
- [[terraform-provider/reference/ephemeral-resources/iam_token]]
- [[terraform-provider/reference/provider]]
- [[terraform-provider/reference/resources/applications_v1alpha1_k8s_release]]
- [[terraform-provider/reference/resources/compute_v1_disk]]
- [[terraform-provider/reference/resources/compute_v1_filesystem]]
- [[terraform-provider/reference/resources/compute_v1_gpu_cluster]]
- [[terraform-provider/reference/resources/compute_v1_instance]]
- [[terraform-provider/reference/resources/compute_v1alpha1_disk]]
- [[terraform-provider/reference/resources/compute_v1alpha1_filesystem]]
- [[terraform-provider/reference/resources/compute_v1alpha1_gpu_cluster]]
- [[terraform-provider/reference/resources/compute_v1alpha1_instance]]
- [[terraform-provider/reference/resources/hash]]
- [[terraform-provider/reference/resources/iam_v1_access_permit]]
- [[terraform-provider/reference/resources/iam_v1_auth_public_key]]
- [[terraform-provider/reference/resources/iam_v1_federated_credentials]]
- [[terraform-provider/reference/resources/iam_v1_federation]]
- [[terraform-provider/reference/resources/iam_v1_federation_certificate]]
- [[terraform-provider/reference/resources/iam_v1_group]]
- [[terraform-provider/reference/resources/iam_v1_group_membership]]
- [[terraform-provider/reference/resources/iam_v1_invitation]]
- [[terraform-provider/reference/resources/iam_v1_service_account]]
- [[terraform-provider/reference/resources/iam_v2_access_key]]
- [[terraform-provider/reference/resources/mk8s_v1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_spark_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_spark_v1alpha1_session]]
- [[terraform-provider/reference/resources/registry_v1_registry]]
- [[terraform-provider/reference/resources/storage_v1_bucket]]
- [[terraform-provider/reference/resources/vpc_v1_allocation]]
- [[terraform-provider/reference/resources/vpc_v1_network]]
- [[terraform-provider/reference/resources/vpc_v1_pool]]
- [[terraform-provider/reference/resources/vpc_v1_subnet]]
- [[terraform-provider/reference/resources/vpc_v1alpha1_allocation]]
- [[terraform-provider/release-notes]]