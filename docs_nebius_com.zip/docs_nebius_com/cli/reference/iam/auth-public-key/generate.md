Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
activate
create
deactivate
delete
edit
generate
get
list
list-by-account
operation
update
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
auth-public-key
generate
nebius iam auth-public-key generate
Usage
Flags
Global flags
Generates key-pair, uploads the public key as a service account authentication key and outputs the service account authentication credentials


Usage
Usage




nebius iam auth-public-key generate [flags]























Flags
Flags




  --output <value> (string) [required]             Output file path.
  --output-format <value> (string)                 Output file format: 'service-account-json', 'pem'.
  --parent-id <value> (string)                     Container ID to upload auth public key to. A service account parent is used if not set.
  --service-account-id <value> (string) [required] Service account to upload auth public key to.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
edit
Next
get
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[applications/standalone/jupyterlab/deploy]]
- [[cli/install]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/activate]]
- [[cli/reference/iam/auth-public-key/create]]
- [[cli/reference/iam/auth-public-key/deactivate]]
- [[cli/reference/iam/auth-public-key/delete]]
- [[cli/reference/iam/auth-public-key/edit]]
- [[cli/reference/iam/auth-public-key/get]]
- [[cli/reference/iam/auth-public-key/list]]
- [[cli/reference/iam/auth-public-key/list-by-account]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/auth-public-key/operation/get]]
- [[cli/reference/iam/auth-public-key/operation/list]]
- [[cli/reference/iam/auth-public-key/operation/wait]]
- [[cli/reference/iam/auth-public-key/update]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/slurm]]
- [[compute/quickstart]]
- [[compute/virtual-machines/connect]]
- [[iam/service-accounts/authorized-keys]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/integrations/run-ai]]
- [[legal/archive/service-terms-20240830]]
- [[legal/archive/service-terms-20241125]]
- [[legal/aup]]
- [[legal/service-terms]]
- [[legal/studio/archive/privacy-20240828]]
- [[legal/studio/aup/flux-dev]]
- [[legal/studio/privacy]]
- [[mlflow/monitoring]]
- [[postgresql/monitoring]]
- [[slurm-soperator/clusters/connect]]
- [[studio/api/examples]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/huggingface]]
- [[studio/inference/models/text-to-image]]
- [[studio/inference/tool-calling]]
- [[terraform-provider/quickstart]]