Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
create
delete
get
list
operation
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
access-permit
nebius iam access-permit
Usage
Flags
Subcommands
Usage
Usage




nebius iam access-permit [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam access-permit create
	 - Creates access permit for provided resource with provided role.

Subject of access permit is also a parent of access permit.

If resource is unknown - NOT_FOUND will be thrown.

If parent of subject is not from resource's hierarchy - NOT_FOUND will be thrown.


nebius iam access-permit delete
	 - Delete access permit by id.


nebius iam access-permit get
	 - Gets access permit by id.


nebius iam access-permit list
	 - Lists access permits for provided parent.


nebius iam access-permit operation
	 - Manage operations for AccessPermit service.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/iam/access-permit/create]]
- [[cli/reference/iam/access-permit/delete]]
- [[cli/reference/iam/access-permit/get]]
- [[iam/authorization/groups]]
- [[terraform-provider/reference/data-sources/iam_v1_access_permit]]
- [[terraform-provider/reference/resources/iam_v1_access_permit]]