Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
create
edit
edit-by-name
get
get-by-name
list
operation
update
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
project
update
nebius iam project update
Usage
Flags
Global flags
Usage
Usage




nebius iam project update [id] [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --diff [=<true|false>] (bool)  Show diff of resource before commiting update.
  --full [=<true|false>] (bool)  Update full resource state. Automatically set to true if the --file or argument provided.
  --patch [=<true|false>] (bool) Update only specified fields.
  Metadata:
    --id <value> (string)                                          Identifier for the resource, unique for its resource type.
    --parent-id <value> (string)                                   Identifier of the parent resource to which the resource belongs.
    --name <value> (string)                                        Human readable name for the resource.
    --resource-version <value> (int64)                             Version of the resource for safe concurrent modifications and consistent reads.
                                                                   Positive and monotonically increases on each resource spec change (but *not* on each change of the
                                                                   resource's container(s) or status).
                                                                   Service allows zero value or current.
    --labels <[key1=value1[,key2=value2...]]> (string->string)     Labels associated with the resource.
    --labels-add <[key1=value1[,key2=value2...]]> (string->string) Add values to Labels associated with the resource.
    --labels-remove <value1[,value2...]> (string array)            Remove values from Labels associated with the resource.
  --region <value> (string)
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
service-account
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[audit-logs/use-cases]]
- [[cli/install]]
- [[cli/quickstart]]
- [[cli/reference]]
- [[cli/reference/applications]]
- [[cli/reference/applications/v1alpha1]]
- [[cli/reference/applications/v1alpha1/k-8-s-release]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/create]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/delete]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/get]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/list]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/get]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/list]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/wait]]
- [[cli/reference/audit]]
- [[cli/reference/audit/v2]]
- [[cli/reference/audit/v2/audit-event]]
- [[cli/reference/audit/v2/audit-event/list]]
- [[cli/reference/compute]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/delete]]
- [[cli/reference/compute/disk/edit]]
- [[cli/reference/compute/disk/edit-by-name]]
- [[cli/reference/compute/disk/get]]
- [[cli/reference/compute/disk/get-by-name]]
- [[cli/reference/compute/disk/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/delete]]
- [[cli/reference/compute/filesystem/edit]]
- [[cli/reference/compute/filesystem/edit-by-name]]
- [[cli/reference/compute/filesystem/get]]
- [[cli/reference/compute/filesystem/get-by-name]]
- [[cli/reference/compute/filesystem/list]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/edit]]
- [[cli/reference/compute/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/list]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/image]]
- [[cli/reference/compute/image/get]]
- [[cli/reference/compute/image/get-by-name]]
- [[cli/reference/compute/image/get-latest-by-family]]
- [[cli/reference/compute/image/list]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/platform]]
- [[cli/reference/compute/platform/get-by-name]]
- [[cli/reference/compute/platform/list]]
- [[cli/reference/compute/v1alpha1]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/disk/delete]]
- [[cli/reference/compute/v1alpha1/disk/edit]]
- [[cli/reference/compute/v1alpha1/disk/edit-by-name]]
- [[cli/reference/compute/v1alpha1/disk/get]]
- [[cli/reference/compute/v1alpha1/disk/get-by-name]]
- [[cli/reference/compute/v1alpha1/disk/list]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/compute/v1alpha1/filesystem/delete]]
- [[cli/reference/compute/v1alpha1/filesystem/edit]]
- [[cli/reference/compute/v1alpha1/filesystem/edit-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/get]]
- [[cli/reference/compute/v1alpha1/filesystem/get-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/list]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/create]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/delete]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/image]]
- [[cli/reference/compute/v1alpha1/image/get]]
- [[cli/reference/compute/v1alpha1/image/get-by-name]]
- [[cli/reference/compute/v1alpha1/image/get-latest-by-family]]
- [[cli/reference/compute/v1alpha1/image/list]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/config]]
- [[cli/reference/config/get]]
- [[cli/reference/config/list]]
- [[cli/reference/config/set]]
- [[cli/reference/config/unset]]
- [[cli/reference/iam]]
- [[cli/reference/iam/access-key]]
- [[cli/reference/iam/access-key/activate]]
- [[cli/reference/iam/access-key/create]]
- [[cli/reference/iam/access-key/deactivate]]
- [[cli/reference/iam/access-key/delete]]
- [[cli/reference/iam/access-key/get-by-aws-id]]
- [[cli/reference/iam/access-key/get-by-id]]
- [[cli/reference/iam/access-key/get-secret-once]]
- [[cli/reference/iam/access-key/list]]
- [[cli/reference/iam/access-key/list-by-account]]
- [[cli/reference/iam/access-key/operation]]
- [[cli/reference/iam/access-key/operation/get]]
- [[cli/reference/iam/access-key/operation/list]]
- [[cli/reference/iam/access-key/update]]
- [[cli/reference/iam/access-permit]]
- [[cli/reference/iam/access-permit/create]]
- [[cli/reference/iam/access-permit/delete]]
- [[cli/reference/iam/access-permit/get]]
- [[cli/reference/iam/access-permit/list]]
- [[cli/reference/iam/access-permit/operation]]
- [[cli/reference/iam/access-permit/operation/get]]
- [[cli/reference/iam/access-permit/operation/list]]
- [[cli/reference/iam/access-permit/operation/wait]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/activate]]
- [[cli/reference/iam/auth-public-key/create]]
- [[cli/reference/iam/auth-public-key/deactivate]]
- [[cli/reference/iam/auth-public-key/delete]]
- [[cli/reference/iam/auth-public-key/edit]]
- [[cli/reference/iam/auth-public-key/generate]]
- [[cli/reference/iam/auth-public-key/get]]
- [[cli/reference/iam/auth-public-key/list]]
- [[cli/reference/iam/auth-public-key/list-by-account]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/auth-public-key/operation/get]]
- [[cli/reference/iam/auth-public-key/operation/list]]
- [[cli/reference/iam/auth-public-key/operation/wait]]
- [[cli/reference/iam/auth-public-key/update]]
- [[cli/reference/iam/federated-credentials]]
- [[cli/reference/iam/federated-credentials/create]]
- [[cli/reference/iam/federated-credentials/delete]]
- [[cli/reference/iam/federated-credentials/edit]]
- [[cli/reference/iam/federated-credentials/edit-by-name]]
- [[cli/reference/iam/federated-credentials/get]]
- [[cli/reference/iam/federated-credentials/get-by-name]]
- [[cli/reference/iam/federated-credentials/list]]
- [[cli/reference/iam/federated-credentials/operation]]
- [[cli/reference/iam/federated-credentials/operation/get]]
- [[cli/reference/iam/federated-credentials/operation/list]]
- [[cli/reference/iam/federated-credentials/operation/wait]]
- [[cli/reference/iam/federated-credentials/update]]
- [[cli/reference/iam/federation]]
- [[cli/reference/iam/federation-certificate]]
- [[cli/reference/iam/federation-certificate/create]]
- [[cli/reference/iam/federation-certificate/delete]]
- [[cli/reference/iam/federation-certificate/edit]]
- [[cli/reference/iam/federation-certificate/get]]
- [[cli/reference/iam/federation-certificate/list-by-federation]]
- [[cli/reference/iam/federation-certificate/operation]]
- [[cli/reference/iam/federation-certificate/operation/get]]
- [[cli/reference/iam/federation-certificate/operation/list]]
- [[cli/reference/iam/federation-certificate/operation/wait]]
- [[cli/reference/iam/federation-certificate/update]]
- [[cli/reference/iam/federation/create]]
- [[cli/reference/iam/federation/delete]]
- [[cli/reference/iam/federation/edit]]
- [[cli/reference/iam/federation/edit-by-name]]
- [[cli/reference/iam/federation/get]]
- [[cli/reference/iam/federation/get-by-name]]
- [[cli/reference/iam/federation/list]]
- [[cli/reference/iam/federation/operation]]
- [[cli/reference/iam/federation/operation/get]]
- [[cli/reference/iam/federation/operation/list]]
- [[cli/reference/iam/federation/operation/wait]]
- [[cli/reference/iam/federation/update]]
- [[cli/reference/iam/get-access-token]]
- [[cli/reference/iam/group]]
- [[cli/reference/iam/group-membership]]
- [[cli/reference/iam/group-membership/create]]
- [[cli/reference/iam/group-membership/delete]]
- [[cli/reference/iam/group-membership/get]]
- [[cli/reference/iam/group-membership/get-with-attributes]]
- [[cli/reference/iam/group-membership/list-member-of]]
- [[cli/reference/iam/group-membership/list-members]]
- [[cli/reference/iam/group-membership/list-members-with-attributes]]
- [[cli/reference/iam/group-membership/operation]]
- [[cli/reference/iam/group-membership/operation/get]]
- [[cli/reference/iam/group-membership/operation/list]]
- [[cli/reference/iam/group-membership/operation/wait]]
- [[cli/reference/iam/group/create]]
- [[cli/reference/iam/group/delete]]
- [[cli/reference/iam/group/edit]]
- [[cli/reference/iam/group/edit-by-name]]
- [[cli/reference/iam/group/get]]
- [[cli/reference/iam/group/get-by-name]]
- [[cli/reference/iam/group/list]]
- [[cli/reference/iam/group/operation]]
- [[cli/reference/iam/group/operation/get]]
- [[cli/reference/iam/group/operation/list]]
- [[cli/reference/iam/group/operation/wait]]
- [[cli/reference/iam/group/update]]
- [[cli/reference/iam/invitation]]
- [[cli/reference/iam/invitation/create]]
- [[cli/reference/iam/invitation/delete]]
- [[cli/reference/iam/invitation/edit]]
- [[cli/reference/iam/invitation/get]]
- [[cli/reference/iam/invitation/list]]
- [[cli/reference/iam/invitation/operation]]
- [[cli/reference/iam/invitation/operation/get]]
- [[cli/reference/iam/invitation/operation/list]]
- [[cli/reference/iam/invitation/operation/wait]]
- [[cli/reference/iam/invitation/resend]]
- [[cli/reference/iam/invitation/update]]
- [[cli/reference/iam/project]]
- [[cli/reference/iam/project/create]]
- [[cli/reference/iam/project/edit]]
- [[cli/reference/iam/project/edit-by-name]]
- [[cli/reference/iam/project/get]]
- [[cli/reference/iam/project/get-by-name]]
- [[cli/reference/iam/project/list]]
- [[cli/reference/iam/project/operation]]
- [[cli/reference/iam/project/operation/get]]
- [[cli/reference/iam/project/operation/list]]
- [[cli/reference/iam/project/operation/wait]]
- [[cli/reference/iam/service-account]]
- [[cli/reference/iam/service-account/create]]
- [[cli/reference/iam/service-account/delete]]
- [[cli/reference/iam/service-account/edit]]
- [[cli/reference/iam/service-account/edit-by-name]]
- [[cli/reference/iam/service-account/get]]
- [[cli/reference/iam/service-account/get-by-name]]
- [[cli/reference/iam/service-account/list]]
- [[cli/reference/iam/service-account/operation]]
- [[cli/reference/iam/service-account/operation/get]]
- [[cli/reference/iam/service-account/operation/list]]
- [[cli/reference/iam/service-account/operation/wait]]
- [[cli/reference/iam/service-account/update]]
- [[cli/reference/iam/session-management]]
- [[cli/reference/iam/session-management/revoke]]
- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/delete]]
- [[cli/reference/iam/static-key/find]]
- [[cli/reference/iam/static-key/get]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/iam/static-key/issue]]
- [[cli/reference/iam/static-key/list]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/operation/wait]]
- [[cli/reference/iam/static-key/revoke]]
- [[cli/reference/iam/tenant]]
- [[cli/reference/iam/tenant-user-account]]
- [[cli/reference/iam/tenant-user-account-with-attributes]]
- [[cli/reference/iam/tenant-user-account-with-attributes/get]]
- [[cli/reference/iam/tenant-user-account-with-attributes/list]]
- [[cli/reference/iam/tenant-user-account/block]]
- [[cli/reference/iam/tenant-user-account/get]]
- [[cli/reference/iam/tenant-user-account/list]]
- [[cli/reference/iam/tenant-user-account/operation]]
- [[cli/reference/iam/tenant-user-account/operation/get]]
- [[cli/reference/iam/tenant-user-account/operation/list]]
- [[cli/reference/iam/tenant-user-account/operation/wait]]
- [[cli/reference/iam/tenant-user-account/unblock]]
- [[cli/reference/iam/tenant/get]]
- [[cli/reference/iam/tenant/list]]
- [[cli/reference/iam/token-exchange]]
- [[cli/reference/iam/token-exchange/exchange]]
- [[cli/reference/iam/v2]]
- [[cli/reference/iam/v2/access-key]]
- [[cli/reference/iam/v2/access-key/activate]]
- [[cli/reference/iam/v2/access-key/activate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/create]]
- [[cli/reference/iam/v2/access-key/deactivate]]
- [[cli/reference/iam/v2/access-key/deactivate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/delete]]
- [[cli/reference/iam/v2/access-key/delete-by-aws-id]]
- [[cli/reference/iam/v2/access-key/edit]]
- [[cli/reference/iam/v2/access-key/get]]
- [[cli/reference/iam/v2/access-key/get-by-aws-id]]
- [[cli/reference/iam/v2/access-key/list]]
- [[cli/reference/iam/v2/access-key/list-by-account]]
- [[cli/reference/iam/v2/access-key/operation]]
- [[cli/reference/iam/v2/access-key/operation/get]]
- [[cli/reference/iam/v2/access-key/operation/list]]
- [[cli/reference/iam/v2/access-key/operation/wait]]
- [[cli/reference/iam/v2/access-key/update]]
- [[cli/reference/iam/whoami]]
- [[cli/reference/mk8s]]
- [[cli/reference/mk8s/cluster]]
- [[cli/reference/mk8s/cluster/create]]
- [[cli/reference/mk8s/cluster/delete]]
- [[cli/reference/mk8s/cluster/edit]]
- [[cli/reference/mk8s/cluster/edit-by-name]]
- [[cli/reference/mk8s/cluster/get]]
- [[cli/reference/mk8s/cluster/get-by-name]]
- [[cli/reference/mk8s/cluster/get-credentials]]
- [[cli/reference/mk8s/cluster/get-token]]
- [[cli/reference/mk8s/cluster/list]]
- [[cli/reference/mk8s/cluster/operation]]
- [[cli/reference/mk8s/cluster/operation/get]]
- [[cli/reference/mk8s/cluster/operation/list]]
- [[cli/reference/mk8s/cluster/operation/wait]]
- [[cli/reference/mk8s/cluster/update]]
- [[cli/reference/mk8s/node-group]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/delete]]
- [[cli/reference/mk8s/node-group/edit]]
- [[cli/reference/mk8s/node-group/edit-by-name]]
- [[cli/reference/mk8s/node-group/get]]
- [[cli/reference/mk8s/node-group/get-by-name]]
- [[cli/reference/mk8s/node-group/list]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/node-group/operation/get]]
- [[cli/reference/mk8s/node-group/operation/list]]
- [[cli/reference/mk8s/node-group/operation/wait]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/node-group/upgrade]]
- [[cli/reference/mk8s/v1alpha1]]
- [[cli/reference/mk8s/v1alpha1/cluster]]
- [[cli/reference/mk8s/v1alpha1/cluster/create]]
- [[cli/reference/mk8s/v1alpha1/cluster/delete]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-credentials]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-token]]
- [[cli/reference/mk8s/v1alpha1/cluster/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/cluster/update]]
- [[cli/reference/mk8s/v1alpha1/node-group]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/delete]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/upgrade]]
- [[cli/reference/msp]]
- [[cli/reference/msp/mlflow]]
- [[cli/reference/msp/mlflow/v1alpha1]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/create]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/delete]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql]]
- [[cli/reference/msp/postgresql/v1alpha1]]
- [[cli/reference/msp/postgresql/v1alpha1/backup]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/get]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list-by-cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/reference/msp/serverless]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/delete]]
- [[cli/reference/msp/serverless/get]]
- [[cli/reference/msp/serverless/list]]
- [[cli/reference/msp/serverless/logs]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/start]]
- [[cli/reference/msp/serverless/stop]]
- [[cli/reference/msp/serverless/v1alpha1]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/delete]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get-by-name]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/stop]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/cancel]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/delete]]
- [[cli/reference/msp/serverless/v1alpha1/job/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark]]
- [[cli/reference/msp/spark/v1alpha1]]
- [[cli/reference/msp/spark/v1alpha1/cluster]]
- [[cli/reference/msp/spark/v1alpha1/cluster/create]]
- [[cli/reference/msp/spark/v1alpha1/cluster/delete]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/cluster/update]]
- [[cli/reference/msp/spark/v1alpha1/job]]
- [[cli/reference/msp/spark/v1alpha1/job/cancel]]
- [[cli/reference/msp/spark/v1alpha1/job/create]]
- [[cli/reference/msp/spark/v1alpha1/job/get]]
- [[cli/reference/msp/spark/v1alpha1/job/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/session]]
- [[cli/reference/msp/spark/v1alpha1/session/create]]
- [[cli/reference/msp/spark/v1alpha1/session/delete]]
- [[cli/reference/msp/spark/v1alpha1/session/get]]
- [[cli/reference/msp/spark/v1alpha1/session/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/session/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/wait]]
- [[cli/reference/msp/v1alpha1]]
- [[cli/reference/msp/v1alpha1/resource]]
- [[cli/reference/msp/v1alpha1/resource/preset]]
- [[cli/reference/msp/v1alpha1/resource/preset/list]]
- [[cli/reference/msp/v1alpha1/resource/template]]
- [[cli/reference/msp/v1alpha1/resource/template/list]]
- [[cli/reference/profile]]
- [[cli/reference/profile/activate]]
- [[cli/reference/profile/create]]
- [[cli/reference/profile/current]]
- [[cli/reference/profile/delete]]
- [[cli/reference/profile/list]]
- [[cli/reference/profile/update]]
- [[cli/reference/quotas]]
- [[cli/reference/quotas/quota-allowance]]
- [[cli/reference/quotas/quota-allowance/get]]
- [[cli/reference/quotas/quota-allowance/get-by-name]]
- [[cli/reference/quotas/quota-allowance/list]]
- [[cli/reference/registry]]
- [[cli/reference/registry/configure-helper]]
- [[cli/reference/registry/create]]
- [[cli/reference/registry/create-helper]]
- [[cli/reference/registry/delete]]
- [[cli/reference/registry/docker-credential]]
- [[cli/reference/registry/docker-credential/get]]
- [[cli/reference/registry/edit]]
- [[cli/reference/registry/get]]
- [[cli/reference/registry/image]]
- [[cli/reference/registry/image/delete]]
- [[cli/reference/registry/image/get]]
- [[cli/reference/registry/image/list]]
- [[cli/reference/registry/image/operation]]
- [[cli/reference/registry/image/operation/get]]
- [[cli/reference/registry/image/operation/list]]
- [[cli/reference/registry/image/operation/wait]]
- [[cli/reference/registry/list]]
- [[cli/reference/registry/operation]]
- [[cli/reference/registry/operation/get]]
- [[cli/reference/registry/operation/list]]
- [[cli/reference/registry/operation/wait]]
- [[cli/reference/registry/update]]
- [[cli/reference/storage]]
- [[cli/reference/storage/bucket]]
- [[cli/reference/storage/bucket/create]]
- [[cli/reference/storage/bucket/delete]]
- [[cli/reference/storage/bucket/edit]]
- [[cli/reference/storage/bucket/edit-by-name]]
- [[cli/reference/storage/bucket/get]]
- [[cli/reference/storage/bucket/get-by-name]]
- [[cli/reference/storage/bucket/list]]
- [[cli/reference/storage/bucket/operation]]
- [[cli/reference/storage/bucket/operation/get]]
- [[cli/reference/storage/bucket/operation/list]]
- [[cli/reference/storage/bucket/operation/wait]]
- [[cli/reference/storage/bucket/purge]]
- [[cli/reference/storage/bucket/undelete]]
- [[cli/reference/storage/bucket/update]]
- [[cli/reference/storage/v1alpha1]]
- [[cli/reference/storage/v1alpha1/transfer]]
- [[cli/reference/storage/v1alpha1/transfer/create]]
- [[cli/reference/storage/v1alpha1/transfer/delete]]
- [[cli/reference/storage/v1alpha1/transfer/edit]]
- [[cli/reference/storage/v1alpha1/transfer/edit-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get]]
- [[cli/reference/storage/v1alpha1/transfer/get-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get-iteration-history]]
- [[cli/reference/storage/v1alpha1/transfer/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation]]
- [[cli/reference/storage/v1alpha1/transfer/operation/get]]
- [[cli/reference/storage/v1alpha1/transfer/operation/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation/wait]]
- [[cli/reference/storage/v1alpha1/transfer/resume]]
- [[cli/reference/storage/v1alpha1/transfer/stop]]
- [[cli/reference/storage/v1alpha1/transfer/update]]
- [[cli/reference/update]]
- [[cli/reference/version]]
- [[cli/reference/vpc]]
- [[cli/reference/vpc/allocation]]
- [[cli/reference/vpc/allocation/create]]
- [[cli/reference/vpc/allocation/delete]]
- [[cli/reference/vpc/allocation/edit]]
- [[cli/reference/vpc/allocation/edit-by-name]]
- [[cli/reference/vpc/allocation/get]]
- [[cli/reference/vpc/allocation/get-by-name]]
- [[cli/reference/vpc/allocation/list]]
- [[cli/reference/vpc/allocation/list-by-pool]]
- [[cli/reference/vpc/allocation/operation]]
- [[cli/reference/vpc/allocation/operation/get]]
- [[cli/reference/vpc/allocation/operation/list]]
- [[cli/reference/vpc/allocation/operation/wait]]
- [[cli/reference/vpc/allocation/update]]
- [[cli/reference/vpc/network]]
- [[cli/reference/vpc/network/create]]
- [[cli/reference/vpc/network/create-default]]
- [[cli/reference/vpc/network/delete]]
- [[cli/reference/vpc/network/edit]]
- [[cli/reference/vpc/network/edit-by-name]]
- [[cli/reference/vpc/network/get]]
- [[cli/reference/vpc/network/get-by-name]]
- [[cli/reference/vpc/network/list]]
- [[cli/reference/vpc/network/operation]]
- [[cli/reference/vpc/network/operation/get]]
- [[cli/reference/vpc/network/operation/list]]
- [[cli/reference/vpc/network/operation/wait]]
- [[cli/reference/vpc/network/update]]
- [[cli/reference/vpc/pool]]
- [[cli/reference/vpc/pool/create]]
- [[cli/reference/vpc/pool/delete]]
- [[cli/reference/vpc/pool/edit]]
- [[cli/reference/vpc/pool/edit-by-name]]
- [[cli/reference/vpc/pool/get]]
- [[cli/reference/vpc/pool/get-by-name]]
- [[cli/reference/vpc/pool/list]]
- [[cli/reference/vpc/pool/list-by-source-pool]]
- [[cli/reference/vpc/pool/operation]]
- [[cli/reference/vpc/pool/operation/get]]
- [[cli/reference/vpc/pool/operation/list]]
- [[cli/reference/vpc/pool/operation/wait]]
- [[cli/reference/vpc/pool/update]]
- [[cli/reference/vpc/subnet]]
- [[cli/reference/vpc/subnet/create]]
- [[cli/reference/vpc/subnet/delete]]
- [[cli/reference/vpc/subnet/edit]]
- [[cli/reference/vpc/subnet/edit-by-name]]
- [[cli/reference/vpc/subnet/get]]
- [[cli/reference/vpc/subnet/get-by-name]]
- [[cli/reference/vpc/subnet/list]]
- [[cli/reference/vpc/subnet/list-by-network]]
- [[cli/reference/vpc/subnet/operation]]
- [[cli/reference/vpc/subnet/operation/get]]
- [[cli/reference/vpc/subnet/operation/list]]
- [[cli/reference/vpc/subnet/operation/wait]]
- [[cli/reference/vpc/subnet/update]]
- [[cli/reference/vpc/v1alpha1]]
- [[cli/reference/vpc/v1alpha1/allocation]]
- [[cli/reference/vpc/v1alpha1/allocation/create]]
- [[cli/reference/vpc/v1alpha1/allocation/delete]]
- [[cli/reference/vpc/v1alpha1/allocation/edit]]
- [[cli/reference/vpc/v1alpha1/allocation/edit-by-name]]
- [[cli/reference/vpc/v1alpha1/allocation/get]]
- [[cli/reference/vpc/v1alpha1/allocation/get-by-name]]
- [[cli/reference/vpc/v1alpha1/allocation/list]]
- [[cli/reference/vpc/v1alpha1/allocation/operation]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/get]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/list]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/wait]]
- [[cli/reference/vpc/v1alpha1/allocation/update]]
- [[cli/reference/vpc/v1alpha1/network]]
- [[cli/reference/vpc/v1alpha1/network/get]]
- [[cli/reference/vpc/v1alpha1/network/get-by-name]]
- [[cli/reference/vpc/v1alpha1/network/list]]
- [[cli/reference/vpc/v1alpha1/pool]]
- [[cli/reference/vpc/v1alpha1/pool/get]]
- [[cli/reference/vpc/v1alpha1/pool/get-by-name]]
- [[cli/reference/vpc/v1alpha1/pool/list]]
- [[cli/reference/vpc/v1alpha1/scope]]
- [[cli/reference/vpc/v1alpha1/scope/get]]
- [[cli/reference/vpc/v1alpha1/scope/get-by-name]]
- [[cli/reference/vpc/v1alpha1/scope/list]]
- [[cli/reference/vpc/v1alpha1/subnet]]
- [[cli/reference/vpc/v1alpha1/subnet/get]]
- [[cli/reference/vpc/v1alpha1/subnet/get-by-name]]
- [[cli/reference/vpc/v1alpha1/subnet/list]]
- [[cli/reference/vpc/v1alpha1/subnet/list-by-network]]
- [[cli/release-notes]]
- [[compute/clusters/gpu]]
- [[compute/clusters/skypilot]]
- [[compute/monitoring/virtual-machines]]
- [[compute/storage/detach-volume]]
- [[compute/storage/manage]]
- [[compute/storage/use]]
- [[compute/virtual-machines/manage]]
- [[iam/authorization/groups]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/archive/privacy-20240828]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/specific-terms/managed-postgresql-20240925]]
- [[legal/hr-privacy-policy]]
- [[legal/privacy]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/studio/archive/privacy-20240828]]
- [[legal/studio/archive/terms-of-use-20240828]]
- [[legal/studio/archive/terms-of-use-20241220]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/privacy]]
- [[legal/studio/terms-of-use]]
- [[object-storage/buckets/manage]]
- [[object-storage/objects/manage]]
- [[observability/logs/ingest]]
- [[observability/metrics/ingest]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/users]]
- [[postgresql/quickstart]]
- [[signup-billing/payments/invoices]]
- [[slurm-soperator/jobs/containers/apptainer]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/monitoring/statuses]]
- [[slurm-soperator/storage/download-data]]
- [[spark/clusters/manage]]
- [[studio/billing]]
- [[studio/inference/integrations/postman]]
- [[terraform-provider/reference/data-sources/mk8s_v1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/applications_v1alpha1_k8s_release]]
- [[terraform-provider/reference/resources/mk8s_v1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]
- [[vpc/addressing/custom-private-addresses]]