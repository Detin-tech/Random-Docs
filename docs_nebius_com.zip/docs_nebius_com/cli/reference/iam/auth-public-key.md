Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
activate
create
deactivate
delete
edit
generate
get
list
list-by-account
operation
update
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
auth-public-key
nebius iam auth-public-key
Usage
Flags
Subcommands
Usage
Usage




nebius iam auth-public-key [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam auth-public-key activate


nebius iam auth-public-key create


nebius iam auth-public-key deactivate


nebius iam auth-public-key delete


nebius iam auth-public-key edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius iam auth-public-key generate
	 - Generates key-pair, uploads the public key as a service account authentication key and outputs the service account authentication credentials


nebius iam auth-public-key get


nebius iam auth-public-key list


nebius iam auth-public-key list-by-account


nebius iam auth-public-key operation
	 - Manage operations for AuthPublicKey service.


nebius iam auth-public-key update




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
activate
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/iam/auth-public-key/generate]]