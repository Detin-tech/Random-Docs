Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
get
list
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
tenant
nebius iam tenant
Usage
Flags
Subcommands
Usage
Usage




nebius iam tenant [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam tenant get


nebius iam tenant list




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
revoke
Next
get
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[applications/kubernetes/manage]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/manage]]
- [[applications/standalone/stop-start]]
- [[audit-logs]]
- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[audit-logs/use-cases]]
- [[cli/configure]]
- [[cli/reference/audit/v2/audit-event/list]]
- [[cli/reference/iam]]
- [[cli/reference/iam/access-key]]
- [[cli/reference/iam/access-key/activate]]
- [[cli/reference/iam/access-key/create]]
- [[cli/reference/iam/access-key/deactivate]]
- [[cli/reference/iam/access-key/delete]]
- [[cli/reference/iam/access-key/get-by-aws-id]]
- [[cli/reference/iam/access-key/get-by-id]]
- [[cli/reference/iam/access-key/get-secret-once]]
- [[cli/reference/iam/access-key/list]]
- [[cli/reference/iam/access-key/list-by-account]]
- [[cli/reference/iam/access-key/operation]]
- [[cli/reference/iam/access-key/operation/get]]
- [[cli/reference/iam/access-key/operation/list]]
- [[cli/reference/iam/access-key/update]]
- [[cli/reference/iam/access-permit]]
- [[cli/reference/iam/access-permit/create]]
- [[cli/reference/iam/access-permit/delete]]
- [[cli/reference/iam/access-permit/get]]
- [[cli/reference/iam/access-permit/list]]
- [[cli/reference/iam/access-permit/operation]]
- [[cli/reference/iam/access-permit/operation/get]]
- [[cli/reference/iam/access-permit/operation/list]]
- [[cli/reference/iam/access-permit/operation/wait]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/activate]]
- [[cli/reference/iam/auth-public-key/create]]
- [[cli/reference/iam/auth-public-key/deactivate]]
- [[cli/reference/iam/auth-public-key/delete]]
- [[cli/reference/iam/auth-public-key/edit]]
- [[cli/reference/iam/auth-public-key/generate]]
- [[cli/reference/iam/auth-public-key/get]]
- [[cli/reference/iam/auth-public-key/list]]
- [[cli/reference/iam/auth-public-key/list-by-account]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/auth-public-key/operation/get]]
- [[cli/reference/iam/auth-public-key/operation/list]]
- [[cli/reference/iam/auth-public-key/operation/wait]]
- [[cli/reference/iam/auth-public-key/update]]
- [[cli/reference/iam/federated-credentials]]
- [[cli/reference/iam/federated-credentials/create]]
- [[cli/reference/iam/federated-credentials/delete]]
- [[cli/reference/iam/federated-credentials/edit]]
- [[cli/reference/iam/federated-credentials/edit-by-name]]
- [[cli/reference/iam/federated-credentials/get]]
- [[cli/reference/iam/federated-credentials/get-by-name]]
- [[cli/reference/iam/federated-credentials/list]]
- [[cli/reference/iam/federated-credentials/operation]]
- [[cli/reference/iam/federated-credentials/operation/get]]
- [[cli/reference/iam/federated-credentials/operation/list]]
- [[cli/reference/iam/federated-credentials/operation/wait]]
- [[cli/reference/iam/federated-credentials/update]]
- [[cli/reference/iam/federation]]
- [[cli/reference/iam/federation-certificate]]
- [[cli/reference/iam/federation-certificate/create]]
- [[cli/reference/iam/federation-certificate/delete]]
- [[cli/reference/iam/federation-certificate/edit]]
- [[cli/reference/iam/federation-certificate/get]]
- [[cli/reference/iam/federation-certificate/list-by-federation]]
- [[cli/reference/iam/federation-certificate/operation]]
- [[cli/reference/iam/federation-certificate/operation/get]]
- [[cli/reference/iam/federation-certificate/operation/list]]
- [[cli/reference/iam/federation-certificate/operation/wait]]
- [[cli/reference/iam/federation-certificate/update]]
- [[cli/reference/iam/federation/create]]
- [[cli/reference/iam/federation/delete]]
- [[cli/reference/iam/federation/edit]]
- [[cli/reference/iam/federation/edit-by-name]]
- [[cli/reference/iam/federation/get]]
- [[cli/reference/iam/federation/get-by-name]]
- [[cli/reference/iam/federation/list]]
- [[cli/reference/iam/federation/operation]]
- [[cli/reference/iam/federation/operation/get]]
- [[cli/reference/iam/federation/operation/list]]
- [[cli/reference/iam/federation/operation/wait]]
- [[cli/reference/iam/federation/update]]
- [[cli/reference/iam/get-access-token]]
- [[cli/reference/iam/group]]
- [[cli/reference/iam/group-membership]]
- [[cli/reference/iam/group-membership/create]]
- [[cli/reference/iam/group-membership/delete]]
- [[cli/reference/iam/group-membership/get]]
- [[cli/reference/iam/group-membership/get-with-attributes]]
- [[cli/reference/iam/group-membership/list-member-of]]
- [[cli/reference/iam/group-membership/list-members]]
- [[cli/reference/iam/group-membership/list-members-with-attributes]]
- [[cli/reference/iam/group-membership/operation]]
- [[cli/reference/iam/group-membership/operation/get]]
- [[cli/reference/iam/group-membership/operation/list]]
- [[cli/reference/iam/group-membership/operation/wait]]
- [[cli/reference/iam/group/create]]
- [[cli/reference/iam/group/delete]]
- [[cli/reference/iam/group/edit]]
- [[cli/reference/iam/group/edit-by-name]]
- [[cli/reference/iam/group/get]]
- [[cli/reference/iam/group/get-by-name]]
- [[cli/reference/iam/group/list]]
- [[cli/reference/iam/group/operation]]
- [[cli/reference/iam/group/operation/get]]
- [[cli/reference/iam/group/operation/list]]
- [[cli/reference/iam/group/operation/wait]]
- [[cli/reference/iam/group/update]]
- [[cli/reference/iam/invitation]]
- [[cli/reference/iam/invitation/create]]
- [[cli/reference/iam/invitation/delete]]
- [[cli/reference/iam/invitation/edit]]
- [[cli/reference/iam/invitation/get]]
- [[cli/reference/iam/invitation/list]]
- [[cli/reference/iam/invitation/operation]]
- [[cli/reference/iam/invitation/operation/get]]
- [[cli/reference/iam/invitation/operation/list]]
- [[cli/reference/iam/invitation/operation/wait]]
- [[cli/reference/iam/invitation/resend]]
- [[cli/reference/iam/invitation/update]]
- [[cli/reference/iam/project]]
- [[cli/reference/iam/project/create]]
- [[cli/reference/iam/project/edit]]
- [[cli/reference/iam/project/edit-by-name]]
- [[cli/reference/iam/project/get]]
- [[cli/reference/iam/project/get-by-name]]
- [[cli/reference/iam/project/list]]
- [[cli/reference/iam/project/operation]]
- [[cli/reference/iam/project/operation/get]]
- [[cli/reference/iam/project/operation/list]]
- [[cli/reference/iam/project/operation/wait]]
- [[cli/reference/iam/project/update]]
- [[cli/reference/iam/service-account]]
- [[cli/reference/iam/service-account/create]]
- [[cli/reference/iam/service-account/delete]]
- [[cli/reference/iam/service-account/edit]]
- [[cli/reference/iam/service-account/edit-by-name]]
- [[cli/reference/iam/service-account/get]]
- [[cli/reference/iam/service-account/get-by-name]]
- [[cli/reference/iam/service-account/list]]
- [[cli/reference/iam/service-account/operation]]
- [[cli/reference/iam/service-account/operation/get]]
- [[cli/reference/iam/service-account/operation/list]]
- [[cli/reference/iam/service-account/operation/wait]]
- [[cli/reference/iam/service-account/update]]
- [[cli/reference/iam/session-management]]
- [[cli/reference/iam/session-management/revoke]]
- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/delete]]
- [[cli/reference/iam/static-key/find]]
- [[cli/reference/iam/static-key/get]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/iam/static-key/issue]]
- [[cli/reference/iam/static-key/list]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/operation/wait]]
- [[cli/reference/iam/static-key/revoke]]
- [[cli/reference/iam/tenant-user-account]]
- [[cli/reference/iam/tenant-user-account-with-attributes]]
- [[cli/reference/iam/tenant-user-account-with-attributes/get]]
- [[cli/reference/iam/tenant-user-account-with-attributes/list]]
- [[cli/reference/iam/tenant-user-account/block]]
- [[cli/reference/iam/tenant-user-account/get]]
- [[cli/reference/iam/tenant-user-account/list]]
- [[cli/reference/iam/tenant-user-account/operation]]
- [[cli/reference/iam/tenant-user-account/operation/get]]
- [[cli/reference/iam/tenant-user-account/operation/list]]
- [[cli/reference/iam/tenant-user-account/operation/wait]]
- [[cli/reference/iam/tenant-user-account/unblock]]
- [[cli/reference/iam/tenant/get]]
- [[cli/reference/iam/tenant/list]]
- [[cli/reference/iam/token-exchange]]
- [[cli/reference/iam/token-exchange/exchange]]
- [[cli/reference/iam/v2]]
- [[cli/reference/iam/v2/access-key]]
- [[cli/reference/iam/v2/access-key/activate]]
- [[cli/reference/iam/v2/access-key/activate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/create]]
- [[cli/reference/iam/v2/access-key/deactivate]]
- [[cli/reference/iam/v2/access-key/deactivate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/delete]]
- [[cli/reference/iam/v2/access-key/delete-by-aws-id]]
- [[cli/reference/iam/v2/access-key/edit]]
- [[cli/reference/iam/v2/access-key/get]]
- [[cli/reference/iam/v2/access-key/get-by-aws-id]]
- [[cli/reference/iam/v2/access-key/list]]
- [[cli/reference/iam/v2/access-key/list-by-account]]
- [[cli/reference/iam/v2/access-key/operation]]
- [[cli/reference/iam/v2/access-key/operation/get]]
- [[cli/reference/iam/v2/access-key/operation/list]]
- [[cli/reference/iam/v2/access-key/operation/wait]]
- [[cli/reference/iam/v2/access-key/update]]
- [[cli/reference/iam/whoami]]
- [[cli/reference/quotas/quota-allowance]]
- [[cli/reference/quotas/quota-allowance/get-by-name]]
- [[cli/reference/quotas/quota-allowance/list]]
- [[cli/release-notes]]
- [[compute/storage/manage]]
- [[compute/virtual-machines/list-platforms]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry/resources/quotas-limits]]
- [[iam/authorization/add-users]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/federations/configure-sso]]
- [[iam/manage-projects]]
- [[iam/overview]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[iam/service-accounts/manage]]
- [[kubernetes/manage-applications]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/workloads/images-container-registry]]
- [[mlflow/quickstart]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/quickstart]]
- [[object-storage/resources/quotas-limits]]
- [[observability/alerts]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[overview/data-deletion]]
- [[overview/services]]
- [[overview/subscriptions]]
- [[overview/subscriptions/manage-subscriptions]]
- [[signup-billing/sign-up]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/sessions/manage]]
- [[terraform-provider/quickstart]]
- [[terraform-provider/reference/data-sources/iam_v1_group_membership]]
- [[terraform-provider/reference/data-sources/iam_v1_tenant_user_account]]
- [[terraform-provider/reference/resources/iam_v1_group_membership]]
- [[vpc/addressing/custom-private-addresses]]
- [[vpc/addressing/disable-public-addresses]]
- [[vpc/networking/isolation]]
- [[vpc/networking/resources]]
- [[vpc/overview]]