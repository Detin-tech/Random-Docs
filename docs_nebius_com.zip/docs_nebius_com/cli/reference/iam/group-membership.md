Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
create
delete
get
get-with-attributes
list-member-of
list-members
list-members-with-attributes
operation
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
group-membership
nebius iam group-membership
Usage
Flags
Subcommands
Usage
Usage




nebius iam group-membership [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam group-membership create


nebius iam group-membership delete


nebius iam group-membership get


nebius iam group-membership get-with-attributes


nebius iam group-membership list-member-of


nebius iam group-membership list-members


nebius iam group-membership list-members-with-attributes


nebius iam group-membership operation
	 - Manage operations for GroupMembership service.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands