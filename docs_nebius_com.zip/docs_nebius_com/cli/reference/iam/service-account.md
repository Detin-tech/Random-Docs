Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
create
delete
edit
edit-by-name
get
get-by-name
list
operation
update
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
service-account
nebius iam service-account
Usage
Flags
Subcommands
Usage
Usage




nebius iam service-account [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam service-account create


nebius iam service-account delete


nebius iam service-account edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius iam service-account edit-by-name
	 - Edit resource via external text editor. Uses get-by-name command to receive the current state.


nebius iam service-account get


nebius iam service-account get-by-name


nebius iam service-account list


nebius iam service-account operation
	 - Manage operations for ServiceAccount service.


nebius iam service-account update




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[audit-logs/events/reference]]
- [[audit-logs/events/view]]
- [[cli]]
- [[cli/configure]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/generate]]
- [[cli/reference/iam/federated-credentials/create]]
- [[cli/reference/iam/federated-credentials/update]]
- [[cli/reference/iam/group-membership/create]]
- [[cli/reference/iam/group-membership/list-member-of]]
- [[cli/reference/iam/session-management/revoke]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/create]]
- [[cli/reference/msp/spark/v1alpha1/cluster/create]]
- [[cli/reference/profile/create]]
- [[cli/reference/profile/update]]
- [[compute/clusters/skypilot]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/wireguard]]
- [[iam]]
- [[iam/authorization/groups/members]]
- [[iam/overview]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authentication]]
- [[iam/service-accounts/authorized-keys]]
- [[iam/service-accounts/manage]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/workloads/images-container-registry]]
- [[mlflow/clusters/manage]]
- [[mlflow/quickstart]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/quickstart]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/sessions/manage]]
- [[terraform-provider]]
- [[terraform-provider/authentication]]
- [[terraform-provider/quickstart]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/data-sources/iam_v1_federated_credentials]]
- [[terraform-provider/reference/data-sources/iam_v1_group_membership]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/data-sources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/msp_spark_v1alpha1_cluster]]
- [[terraform-provider/reference/provider]]
- [[terraform-provider/reference/resources/compute_v1_instance]]
- [[terraform-provider/reference/resources/iam_v1_federated_credentials]]
- [[terraform-provider/reference/resources/iam_v1_group_membership]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/msp_mlflow_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_spark_v1alpha1_cluster]]