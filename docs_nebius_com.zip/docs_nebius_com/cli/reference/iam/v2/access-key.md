Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
access-key
activate
activate-by-aws-id
create
deactivate
deactivate-by-aws-id
delete
delete-by-aws-id
edit
get
get-by-aws-id
list
list-by-account
operation
update
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
v2
access-key
nebius iam v2 access-key
Usage
Flags
Subcommands
Usage
Usage




nebius iam v2 access-key [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius iam v2 access-key activate


nebius iam v2 access-key activate-by-aws-id


nebius iam v2 access-key create


nebius iam v2 access-key deactivate


nebius iam v2 access-key deactivate-by-aws-id


nebius iam v2 access-key delete


nebius iam v2 access-key delete-by-aws-id


nebius iam v2 access-key edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius iam v2 access-key get


nebius iam v2 access-key get-by-aws-id


nebius iam v2 access-key list


nebius iam v2 access-key list-by-account


nebius iam v2 access-key operation
	 - Manage operations for AccessKey service.


nebius iam v2 access-key update




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
v2
Next
activate
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[audit-logs/events/reference]]
- [[iam/service-accounts/access-keys]]
- [[object-storage/interfaces/aws-cli]]
- [[object-storage/quickstart]]
- [[spark/quickstart]]