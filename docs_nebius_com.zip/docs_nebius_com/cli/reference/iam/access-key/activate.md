Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
activate
create
deactivate
delete
get-by-aws-id
get-by-id
get-secret-once
list
list-by-account
operation
update
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
access-key
activate
nebius iam access-key activate
Usage
Flags
Global flags
Usage
Usage




nebius iam access-key activate [data] [flags]























Flags
Flags




  Id:
    Identity one of:
      --id-id <value> (string)
    or:
      --id-aws-access-key-id <value> (string)
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
access-key
Next
create
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/iam/access-key]]
- [[cli/reference/iam/access-key/create]]
- [[cli/reference/iam/access-key/deactivate]]
- [[cli/reference/iam/access-key/delete]]
- [[cli/reference/iam/access-key/get-by-aws-id]]
- [[cli/reference/iam/access-key/get-by-id]]
- [[cli/reference/iam/access-key/get-secret-once]]
- [[cli/reference/iam/access-key/list]]
- [[cli/reference/iam/access-key/list-by-account]]
- [[cli/reference/iam/access-key/operation]]
- [[cli/reference/iam/access-key/operation/get]]
- [[cli/reference/iam/access-key/operation/list]]
- [[cli/reference/iam/access-key/update]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/activate]]
- [[cli/reference/iam/auth-public-key/create]]
- [[cli/reference/iam/auth-public-key/deactivate]]
- [[cli/reference/iam/auth-public-key/delete]]
- [[cli/reference/iam/auth-public-key/edit]]
- [[cli/reference/iam/auth-public-key/generate]]
- [[cli/reference/iam/auth-public-key/get]]
- [[cli/reference/iam/auth-public-key/list]]
- [[cli/reference/iam/auth-public-key/list-by-account]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/auth-public-key/operation/get]]
- [[cli/reference/iam/auth-public-key/operation/list]]
- [[cli/reference/iam/auth-public-key/operation/wait]]
- [[cli/reference/iam/auth-public-key/update]]
- [[cli/reference/iam/v2/access-key]]
- [[cli/reference/iam/v2/access-key/activate]]
- [[cli/reference/iam/v2/access-key/activate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/create]]
- [[cli/reference/iam/v2/access-key/deactivate]]
- [[cli/reference/iam/v2/access-key/deactivate-by-aws-id]]
- [[cli/reference/iam/v2/access-key/delete]]
- [[cli/reference/iam/v2/access-key/delete-by-aws-id]]
- [[cli/reference/iam/v2/access-key/edit]]
- [[cli/reference/iam/v2/access-key/get]]
- [[cli/reference/iam/v2/access-key/get-by-aws-id]]
- [[cli/reference/iam/v2/access-key/list]]
- [[cli/reference/iam/v2/access-key/list-by-account]]
- [[cli/reference/iam/v2/access-key/operation]]
- [[cli/reference/iam/v2/access-key/operation/get]]
- [[cli/reference/iam/v2/access-key/operation/list]]
- [[cli/reference/iam/v2/access-key/operation/wait]]
- [[cli/reference/iam/v2/access-key/update]]
- [[cli/reference/profile]]
- [[cli/reference/profile/activate]]
- [[cli/reference/profile/create]]
- [[cli/reference/profile/current]]
- [[cli/reference/profile/delete]]
- [[cli/reference/profile/list]]
- [[cli/reference/profile/update]]
- [[compute/quickstart-host-model]]
- [[legal/archive/agreement-20240917]]
- [[postgresql/data-transfers/migrate-data]]
- [[studio/inference/integrations/llamaindex/embedding]]
- [[studio/inference/integrations/llamaindex/text-to-text]]
- [[studio/inference/integrations/llamaindex/vision]]