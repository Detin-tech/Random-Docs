Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
create
delete
edit
edit-by-name
get
get-by-name
list
operation
update
session-management
static-key
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
service-account
edit-by-name
nebius iam service-account edit-by-name
Usage
Flags
Global flags
Edit resource via external text editor. Uses get-by-name command to receive the current state.


Usage
Usage




nebius iam service-account edit-by-name [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --editor <value> (string)      Editor to run for action. Default: vi.
  --name <value> (string)
  --parent-id <value> (string)
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
edit
Next
get
In this article:
Usage
Flags
Global flags