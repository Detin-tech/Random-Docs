Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
delete
find
get
get-by-name
issue
list
operation
revoke
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
static-key
issue
nebius iam static-key issue
Usage
Flags
Global flags
Usage
Usage




nebius iam static-key issue [data] [flags]























Flags
Flags




  Metadata:
    --id <value> (string)                                      Identifier for the resource, unique for its resource type.
    --parent-id <value> (string) [required]                    Identifier of the parent resource to which the resource belongs.
    --name <value> (string)                                    Human readable name for the resource.
    --resource-version <value> (int64)                         Version of the resource for safe concurrent modifications and consistent reads.
                                                               Positive and monotonically increases on each resource spec change (but *not* on each change of the
                                                               resource's container(s) or status).
                                                               Service allows zero value or current.
    --labels <[key1=value1[,key2=value2...]]> (string->string) Labels associated with the resource.
  Spec:
    Account:
      Type one of:
        --account-user-account-id <value> (string)
      or:
        --account-service-account-id <value> (string)
      or:
        AnonymousAccount:
    --service <observability|container_registry> (enum) [required] Service static key is to be used for.
    --expires-at <value> (timestamp: 1970-01-31T02:30:59Z)         When will the static key expire.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
get-by-name
Next
list
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/delete]]
- [[cli/reference/iam/static-key/find]]
- [[cli/reference/iam/static-key/get]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/iam/static-key/list]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/operation/wait]]
- [[cli/reference/iam/static-key/revoke]]
- [[compute/monitoring/virtual-machines]]
- [[compute/monitoring/volumes]]
- [[compute/storage/boot-disk-images]]
- [[compute/virtual-machines/cuda-init-error]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[kubernetes/monitoring]]
- [[kubernetes/node-groups/autoscaling]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/pentest]]
- [[legal/sla-levels/applications/standalone]]
- [[legal/specific-terms/applications]]
- [[object-storage/monitoring]]
- [[observability/logs/grafana]]
- [[observability/logs/ingest]]
- [[observability/logs/logcli]]
- [[observability/metrics/grafana]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]