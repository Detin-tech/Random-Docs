Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
delete
find
get
get-by-name
issue
list
operation
revoke
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
static-key
find
nebius iam static-key find
Usage
Flags
Global flags
Usage
Usage




nebius iam static-key find [data] [flags]























Flags
Flags




  --token <value> (string) The method accepts a static key token with and without signature as an input.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
delete
Next
get
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/standalone/jupyterlab/connect]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/manage]]
- [[applications/standalone/stop-start]]
- [[audit-logs/use-cases]]
- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/delete]]
- [[cli/reference/iam/static-key/get]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/iam/static-key/issue]]
- [[cli/reference/iam/static-key/list]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/operation/wait]]
- [[cli/reference/iam/static-key/revoke]]
- [[compute/clusters/gpu]]
- [[compute/clusters/skypilot]]
- [[compute/monitoring/virtual-machines]]
- [[compute/storage/manage]]
- [[compute/storage/use]]
- [[compute/virtual-machines/list-platforms]]
- [[compute/virtual-machines/not-enough-resources]]
- [[compute/virtual-machines/stop-start]]
- [[compute/virtual-machines/wireguard]]
- [[iam/authorization/add-users]]
- [[iam/authorization/groups]]
- [[iam/federations/configure-sso]]
- [[kubernetes/components]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/manage-applications]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/archive/privacy-20240828]]
- [[legal/archive/specific-terms/applications-20241023]]
- [[legal/aup]]
- [[legal/hr-privacy-policy]]
- [[legal/privacy]]
- [[legal/specific-terms/applications]]
- [[legal/studio/archive/privacy-20240828]]
- [[legal/studio/privacy]]
- [[object-storage/objects/manage]]
- [[object-storage/objects/upload-download]]
- [[observability/dashboards]]
- [[observability/metrics/grafana]]
- [[overview]]
- [[postgresql/backups]]
- [[signup-billing]]
- [[signup-billing/payments/bank-transfers]]
- [[signup-billing/sign-up]]
- [[slurm-soperator]]
- [[slurm-soperator/jobs/manage]]
- [[studio]]
- [[studio/fine-tuning/datasets]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/inference/integrations/postman]]
- [[studio/inference/models]]
- [[studio/inference/tool-calling]]
- [[terraform-provider/reference/provider]]
- [[vpc]]
- [[vpc/networking/resources]]