Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
delete
find
get
get-by-name
issue
list
operation
get
list
wait
revoke
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
static-key
operation
wait
nebius iam static-key operation wait
Usage
Flags
Global flags
Wait for operation to complete.


Usage
Usage




nebius iam static-key operation wait [id] [flags]























Flags
Flags




  --id <value> (string) Id of the operation to wait.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
list
Next
revoke
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[applications/kubernetes/manage]]
- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/manage]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/get]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/list]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/wait]]
- [[cli/reference/audit]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/iam/access-permit/operation]]
- [[cli/reference/iam/access-permit/operation/get]]
- [[cli/reference/iam/access-permit/operation/list]]
- [[cli/reference/iam/access-permit/operation/wait]]
- [[cli/reference/iam/auth-public-key]]
- [[cli/reference/iam/auth-public-key/operation]]
- [[cli/reference/iam/auth-public-key/operation/get]]
- [[cli/reference/iam/auth-public-key/operation/list]]
- [[cli/reference/iam/auth-public-key/operation/wait]]
- [[cli/reference/iam/auth-public-key/update]]
- [[cli/reference/iam/federated-credentials/operation]]
- [[cli/reference/iam/federated-credentials/operation/get]]
- [[cli/reference/iam/federated-credentials/operation/list]]
- [[cli/reference/iam/federated-credentials/operation/wait]]
- [[cli/reference/iam/federated-credentials/update]]
- [[cli/reference/iam/federation-certificate/operation]]
- [[cli/reference/iam/federation-certificate/operation/get]]
- [[cli/reference/iam/federation-certificate/operation/list]]
- [[cli/reference/iam/federation-certificate/operation/wait]]
- [[cli/reference/iam/federation-certificate/update]]
- [[cli/reference/iam/federation/operation]]
- [[cli/reference/iam/federation/operation/get]]
- [[cli/reference/iam/federation/operation/list]]
- [[cli/reference/iam/federation/operation/wait]]
- [[cli/reference/iam/federation/update]]
- [[cli/reference/iam/group-membership/operation]]
- [[cli/reference/iam/group-membership/operation/get]]
- [[cli/reference/iam/group-membership/operation/list]]
- [[cli/reference/iam/group-membership/operation/wait]]
- [[cli/reference/iam/group/operation]]
- [[cli/reference/iam/group/operation/get]]
- [[cli/reference/iam/group/operation/list]]
- [[cli/reference/iam/group/operation/wait]]
- [[cli/reference/iam/group/update]]
- [[cli/reference/iam/invitation]]
- [[cli/reference/iam/invitation/operation]]
- [[cli/reference/iam/invitation/operation/get]]
- [[cli/reference/iam/invitation/operation/list]]
- [[cli/reference/iam/invitation/operation/wait]]
- [[cli/reference/iam/invitation/resend]]
- [[cli/reference/iam/project/operation]]
- [[cli/reference/iam/project/operation/get]]
- [[cli/reference/iam/project/operation/list]]
- [[cli/reference/iam/project/operation/wait]]
- [[cli/reference/iam/project/update]]
- [[cli/reference/iam/service-account/operation]]
- [[cli/reference/iam/service-account/operation/get]]
- [[cli/reference/iam/service-account/operation/list]]
- [[cli/reference/iam/service-account/operation/wait]]
- [[cli/reference/iam/service-account/update]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/revoke]]
- [[cli/reference/iam/tenant-user-account/operation]]
- [[cli/reference/iam/tenant-user-account/operation/get]]
- [[cli/reference/iam/tenant-user-account/operation/list]]
- [[cli/reference/iam/tenant-user-account/operation/wait]]
- [[cli/reference/iam/tenant-user-account/unblock]]
- [[cli/reference/iam/v2/access-key/operation]]
- [[cli/reference/iam/v2/access-key/operation/get]]
- [[cli/reference/iam/v2/access-key/operation/list]]
- [[cli/reference/iam/v2/access-key/operation/wait]]
- [[cli/reference/iam/v2/access-key/update]]
- [[cli/reference/mk8s/cluster/operation]]
- [[cli/reference/mk8s/cluster/operation/get]]
- [[cli/reference/mk8s/cluster/operation/list]]
- [[cli/reference/mk8s/cluster/operation/wait]]
- [[cli/reference/mk8s/cluster/update]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/node-group/operation/get]]
- [[cli/reference/mk8s/node-group/operation/list]]
- [[cli/reference/mk8s/node-group/operation/wait]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/cluster/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/cluster/update]]
- [[cli/reference/msp/spark/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/session]]
- [[cli/reference/msp/spark/v1alpha1/session/operation]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/wait]]
- [[cli/reference/msp/v1alpha1]]
- [[cli/reference/registry/image/operation]]
- [[cli/reference/registry/image/operation/get]]
- [[cli/reference/registry/image/operation/list]]
- [[cli/reference/registry/image/operation/wait]]
- [[cli/reference/registry/list]]
- [[cli/reference/registry/operation]]
- [[cli/reference/registry/operation/get]]
- [[cli/reference/registry/operation/list]]
- [[cli/reference/registry/operation/wait]]
- [[cli/reference/registry/update]]
- [[cli/reference/storage/bucket/operation]]
- [[cli/reference/storage/bucket/operation/get]]
- [[cli/reference/storage/bucket/operation/list]]
- [[cli/reference/storage/bucket/operation/wait]]
- [[cli/reference/storage/bucket/purge]]
- [[cli/reference/storage/v1alpha1]]
- [[cli/reference/storage/v1alpha1/transfer]]
- [[cli/reference/storage/v1alpha1/transfer/create]]
- [[cli/reference/storage/v1alpha1/transfer/operation]]
- [[cli/reference/storage/v1alpha1/transfer/operation/get]]
- [[cli/reference/storage/v1alpha1/transfer/operation/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation/wait]]
- [[cli/reference/storage/v1alpha1/transfer/resume]]
- [[cli/reference/storage/v1alpha1/transfer/update]]
- [[cli/reference/vpc/allocation/operation]]
- [[cli/reference/vpc/allocation/operation/get]]
- [[cli/reference/vpc/allocation/operation/list]]
- [[cli/reference/vpc/allocation/operation/wait]]
- [[cli/reference/vpc/allocation/update]]
- [[cli/reference/vpc/network/operation]]
- [[cli/reference/vpc/network/operation/get]]
- [[cli/reference/vpc/network/operation/list]]
- [[cli/reference/vpc/network/operation/wait]]
- [[cli/reference/vpc/network/update]]
- [[cli/reference/vpc/pool/operation]]
- [[cli/reference/vpc/pool/operation/get]]
- [[cli/reference/vpc/pool/operation/list]]
- [[cli/reference/vpc/pool/operation/wait]]
- [[cli/reference/vpc/pool/update]]
- [[cli/reference/vpc/subnet/operation]]
- [[cli/reference/vpc/subnet/operation/get]]
- [[cli/reference/vpc/subnet/operation/list]]
- [[cli/reference/vpc/subnet/operation/wait]]
- [[cli/reference/vpc/subnet/update]]
- [[cli/reference/vpc/v1alpha1/allocation/operation]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/get]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/list]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/wait]]
- [[cli/reference/vpc/v1alpha1/allocation/update]]
- [[cli/release-notes]]
- [[compute/quickstart-host-model]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/storage/disk-over-csi]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/quickstart]]
- [[spark/clusters/manage]]
- [[spark/sessions/manage]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/inference/integrations/llamaindex/embedding]]
- [[studio/inference/integrations/llamaindex/vision]]
- [[terraform-provider/reference/data-sources/storage_v1_bucket]]
- [[terraform-provider/reference/resources/storage_v1_bucket]]