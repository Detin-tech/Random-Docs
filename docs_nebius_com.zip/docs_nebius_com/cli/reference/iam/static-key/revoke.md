Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
delete
find
get
get-by-name
issue
list
operation
revoke
tenant
tenant-user-account
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
static-key
revoke
nebius iam static-key revoke
Usage
Flags
Global flags
Usage
Usage




nebius iam static-key revoke [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --token <value> (string) The method accepts a static key token with and without signature as an input.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
tenant
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/iam/group-membership/create]]
- [[cli/reference/iam/session-management]]
- [[cli/reference/iam/session-management/revoke]]
- [[cli/reference/iam/static-key]]
- [[cli/reference/iam/static-key/delete]]
- [[cli/reference/iam/static-key/find]]
- [[cli/reference/iam/static-key/get]]
- [[cli/reference/iam/static-key/get-by-name]]
- [[cli/reference/iam/static-key/issue]]
- [[cli/reference/iam/static-key/list]]
- [[cli/reference/iam/static-key/operation]]
- [[cli/reference/iam/static-key/operation/get]]
- [[cli/reference/iam/static-key/operation/list]]
- [[cli/reference/iam/static-key/operation/wait]]
- [[cli/reference/iam/tenant]]
- [[iam/authorization/groups]]
- [[legal/archive/hr-privacy-policy-20241015]]
- [[legal/hr-privacy-policy]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/terms-of-use]]
- [[postgresql/databases/users]]
- [[studio/api/authentication]]