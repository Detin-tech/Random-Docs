Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
access-key
access-permit
auth-public-key
federated-credentials
federation
federation-certificate
get-access-token
group
group-membership
invitation
project
service-account
session-management
static-key
tenant
tenant-user-account
block
get
list
operation
unblock
tenant-user-account-with-attributes
token-exchange
v2
whoami
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
iam
tenant-user-account
block
nebius iam tenant-user-account block
Usage
Flags
Global flags
Usage
Usage




nebius iam tenant-user-account block [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --id <value> (string)
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
tenant-user-account
Next
get
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/iam/tenant-user-account]]
- [[cli/reference/iam/tenant-user-account/get]]
- [[cli/reference/iam/tenant-user-account/list]]
- [[cli/reference/iam/tenant-user-account/operation]]
- [[cli/reference/iam/tenant-user-account/operation/get]]
- [[cli/reference/iam/tenant-user-account/operation/list]]
- [[cli/reference/iam/tenant-user-account/operation/wait]]
- [[cli/reference/iam/tenant-user-account/unblock]]
- [[cli/reference/mk8s/cluster/create]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/cluster/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/vpc/allocation/create]]
- [[cli/reference/vpc/v1alpha1/allocation/create]]
- [[compute/clusters/gpu]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/storage/manage]]
- [[compute/storage/types]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/network]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[legal/agreement]]
- [[legal/archive/agreement-20240917]]
- [[legal/archive/cookie-policy-20240830]]
- [[legal/archive/cookies-list-20240930]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/terms-of-use-20240828]]
- [[legal/cookie-policy]]
- [[legal/cookies-list]]
- [[legal/specific-terms/compute]]
- [[legal/terms-of-use]]
- [[mlflow/clusters/manage]]
- [[mlflow/quickstart]]
- [[object-storage/objects/upload-download]]
- [[object-storage/quickstart]]
- [[spark/quickstart]]
- [[terraform-provider/authentication]]
- [[terraform-provider/reference/data-sources/compute_v1_disk]]
- [[terraform-provider/reference/data-sources/compute_v1_filesystem]]
- [[terraform-provider/reference/data-sources/mk8s_v1_cluster]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/data-sources/vpc_v1_allocation]]
- [[terraform-provider/reference/data-sources/vpc_v1_pool]]
- [[terraform-provider/reference/data-sources/vpc_v1_subnet]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_allocation]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_pool]]
- [[terraform-provider/reference/data-sources/vpc_v1alpha1_subnet]]
- [[terraform-provider/reference/provider]]
- [[terraform-provider/reference/resources/compute_v1_disk]]
- [[terraform-provider/reference/resources/compute_v1_filesystem]]
- [[terraform-provider/reference/resources/mk8s_v1_cluster]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/vpc_v1_allocation]]
- [[terraform-provider/reference/resources/vpc_v1_pool]]
- [[terraform-provider/reference/resources/vpc_v1_subnet]]
- [[terraform-provider/reference/resources/vpc_v1alpha1_allocation]]
- [[vpc/addressing/available-addresses]]
- [[vpc/addressing/custom-private-addresses]]
- [[vpc/overview]]