Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
image
instance
node
set-unhealthy
platform
v1alpha1
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
node
set-unhealthy
nebius compute node set-unhealthy
Usage
Flags
Global flags
SetUnhealthy marks the node underlying the Compute VM as unhealthy,

which has the following effect:




Scheduler makes its best effort not to assign new VMs to the unhealthy node,

but in case of no capacity the VM can be assigned there.


The existing VMs continue to work on the node, but after stop[[../../s]]tart via

Compute API they most probably will be assigned to different node (see 1.)




If the node was already marked unhealthy, the consecutive calls to SetUnhealthy

will return grpc code AlreadyExists.


To use this rpc one needs to obtain
compute.node.setUnhealthy
 permission

for the VM's parent container. The permission is granted to the TSA inside the VM.


Usage
Usage




nebius compute node set-unhealthy [data] [flags]























Flags
Flags




  HealthCheckInfo [required]:
    --health-check-info-observed-at <value> (timestamp: 1970-01-31T02:30:59Z) [required] Time when the unhealthy node was observed.
    --health-check-info-check-id <value> (string) [required]                             Identifies specific GPU check that failed in soperator (key for observability).
    --health-check-info-description <value> (string) [required]                          Human-readable description of the error for further investigation.
  --instance-id <value> (string) [required]
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
node
Next
platform
In this article:
Usage
Flags
Global flags