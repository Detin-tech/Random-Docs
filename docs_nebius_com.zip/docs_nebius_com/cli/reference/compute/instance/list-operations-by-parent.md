Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
image
instance
create
delete
edit
edit-by-name
get
get-by-name
list
list-operations-by-parent
operation
start
stop
update
node
platform
v1alpha1
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
instance
list-operations-by-parent
nebius compute instance list-operations-by-parent
Usage
Flags
Global flags
Lists all operations that were performed within a specific parent resource.


Usage
Usage




nebius compute instance list-operations-by-parent [data] [flags]























Flags
Flags




  --parent-id <value> (string) [required] ID of the parent to list operations for resource type at.
  --page-size <value> (int64)             Page size. [1...1000]. Optional, if not specified, a reasonable default will be chosen by the service.
  --page-token <value> (string)           Listing continuation token. Empty to start listing from the first page.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
list
Next
operation
In this article:
Usage
Flags
Global flags