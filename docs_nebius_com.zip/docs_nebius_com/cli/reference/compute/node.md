Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
image
instance
node
set-unhealthy
platform
v1alpha1
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
node
nebius compute node
Usage
Flags
Subcommands
Usage
Usage




nebius compute node [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius compute node set-unhealthy
	 - SetUnhealthy marks the node underlying the Compute VM as unhealthy,

which has the following effect:






Scheduler makes its best effort not to assign new VMs to the unhealthy node,

but in case of no capacity the VM can be assigned there.


The existing VMs continue to work on the node, but after stop[[../../s]]tart via

Compute API they most probably will be assigned to different node (see 1.)




If the node was already marked unhealthy, the consecutive calls to SetUnhealthy

will return grpc code AlreadyExists.


To use this rpc one needs to obtain
compute.node.setUnhealthy
 permission

for the VM's parent container. The permission is granted to the TSA inside the VM.


Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
set-unhealthy
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/kubernetes/manage]]
- [[applications/types]]
- [[cli/reference/compute]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/delete]]
- [[cli/reference/compute/disk/edit]]
- [[cli/reference/compute/disk/edit-by-name]]
- [[cli/reference/compute/disk/get]]
- [[cli/reference/compute/disk/get-by-name]]
- [[cli/reference/compute/disk/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/delete]]
- [[cli/reference/compute/filesystem/edit]]
- [[cli/reference/compute/filesystem/edit-by-name]]
- [[cli/reference/compute/filesystem/get]]
- [[cli/reference/compute/filesystem/get-by-name]]
- [[cli/reference/compute/filesystem/list]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/edit]]
- [[cli/reference/compute/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/list]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/image]]
- [[cli/reference/compute/image/get]]
- [[cli/reference/compute/image/get-by-name]]
- [[cli/reference/compute/image/get-latest-by-family]]
- [[cli/reference/compute/image/list]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/platform]]
- [[cli/reference/compute/platform/get-by-name]]
- [[cli/reference/compute/platform/list]]
- [[cli/reference/compute/v1alpha1]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/disk/delete]]
- [[cli/reference/compute/v1alpha1/disk/edit]]
- [[cli/reference/compute/v1alpha1/disk/edit-by-name]]
- [[cli/reference/compute/v1alpha1/disk/get]]
- [[cli/reference/compute/v1alpha1/disk/get-by-name]]
- [[cli/reference/compute/v1alpha1/disk/list]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/compute/v1alpha1/filesystem/delete]]
- [[cli/reference/compute/v1alpha1/filesystem/edit]]
- [[cli/reference/compute/v1alpha1/filesystem/edit-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/get]]
- [[cli/reference/compute/v1alpha1/filesystem/get-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/list]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/create]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/delete]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/image]]
- [[cli/reference/compute/v1alpha1/image/get]]
- [[cli/reference/compute/v1alpha1/image/get-by-name]]
- [[cli/reference/compute/v1alpha1/image/get-latest-by-family]]
- [[cli/reference/compute/v1alpha1/image/list]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/mk8s]]
- [[cli/reference/mk8s/cluster]]
- [[cli/reference/mk8s/cluster/create]]
- [[cli/reference/mk8s/cluster/delete]]
- [[cli/reference/mk8s/cluster/edit]]
- [[cli/reference/mk8s/cluster/edit-by-name]]
- [[cli/reference/mk8s/cluster/get]]
- [[cli/reference/mk8s/cluster/get-by-name]]
- [[cli/reference/mk8s/cluster/get-credentials]]
- [[cli/reference/mk8s/cluster/get-token]]
- [[cli/reference/mk8s/cluster/list]]
- [[cli/reference/mk8s/cluster/operation]]
- [[cli/reference/mk8s/cluster/operation/get]]
- [[cli/reference/mk8s/cluster/operation/list]]
- [[cli/reference/mk8s/cluster/operation/wait]]
- [[cli/reference/mk8s/cluster/update]]
- [[cli/reference/mk8s/node-group]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/delete]]
- [[cli/reference/mk8s/node-group/edit]]
- [[cli/reference/mk8s/node-group/edit-by-name]]
- [[cli/reference/mk8s/node-group/get]]
- [[cli/reference/mk8s/node-group/get-by-name]]
- [[cli/reference/mk8s/node-group/list]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/node-group/operation/get]]
- [[cli/reference/mk8s/node-group/operation/list]]
- [[cli/reference/mk8s/node-group/operation/wait]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/node-group/upgrade]]
- [[cli/reference/mk8s/v1alpha1]]
- [[cli/reference/mk8s/v1alpha1/cluster]]
- [[cli/reference/mk8s/v1alpha1/cluster/create]]
- [[cli/reference/mk8s/v1alpha1/cluster/delete]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-credentials]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-token]]
- [[cli/reference/mk8s/v1alpha1/cluster/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/cluster/update]]
- [[cli/reference/mk8s/v1alpha1/node-group]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/delete]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/upgrade]]
- [[cli/release-notes]]
- [[compute/clusters/gpu]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/quickstart]]
- [[compute/storage/types]]
- [[compute/virtual-machines/cuda-init-error]]
- [[iam/authorization/groups]]
- [[kubernetes]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/clusters/manage]]
- [[kubernetes/components]]
- [[kubernetes/connect]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/resources/pricing]]
- [[kubernetes/resources/quotas-limits]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[observability/dashboards]]
- [[overview/data-deletion]]
- [[slurm-soperator]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/containers]]
- [[slurm-soperator/jobs/containers/apptainer]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/jobs/containers/pyxis-enroot]]
- [[slurm-soperator/jobs/manage]]
- [[slurm-soperator/monitoring/statuses]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/overview/why-slurm-soperator]]
- [[slurm-soperator/storage/download-data]]
- [[slurm-soperator/users/manage]]
- [[studio/inference/integrations]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/huggingface]]
- [[studio/inference/integrations/portkey]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]