Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
create
delete
edit
edit-by-name
get
get-by-name
list
list-operations-by-parent
operation
update
image
instance
node
platform
v1alpha1
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
gpu-cluster
nebius compute gpu-cluster
Usage
Flags
Subcommands
Usage
Usage




nebius compute gpu-cluster [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius compute gpu-cluster create
	 - Creates a new GPU Cluster.

For details, see [[../../../compute/clusters/gpu]]


nebius compute gpu-cluster delete
	 - Deletes a GPU Cluster by its ID.


nebius compute gpu-cluster edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius compute gpu-cluster edit-by-name
	 - Edit resource via external text editor. Uses get-by-name command to receive the current state.


nebius compute gpu-cluster get
	 - Retrieves the specified GPU Cluster by its ID.


nebius compute gpu-cluster get-by-name
	 - Retrieves the specified GPU Cluster by its parent and name.


nebius compute gpu-cluster list
	 - Lists GPU Clusters in the specified parent.


nebius compute gpu-cluster list-operations-by-parent
	 - Lists all operations that were performed within a specific parent resource.


nebius compute gpu-cluster operation
	 - Manage operations for GpuCluster service.


nebius compute gpu-cluster update
	 - Modifies the configuration of an existing GPU Cluster.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[compute]]
- [[compute/clusters/gpu]]
- [[compute/clusters/gpu/test]]
- [[compute/clusters/mpirun]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/virtual-machines]]
- [[compute/quickstart]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/types]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/resources/compute_v1_instance]]