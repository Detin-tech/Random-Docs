Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
create
delete
edit
edit-by-name
get
get-by-name
list
list-operations-by-parent
operation
update
gpu-cluster
image
instance
node
platform
v1alpha1
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
filesystem
nebius compute filesystem
Usage
Flags
Subcommands
Usage
Usage




nebius compute filesystem [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius compute filesystem create
	 - Creates a new filesystem with the specified configuration.

For details, see https://docs.nebius.com/compute[[../../s]]torage/manage.


nebius compute filesystem delete
	 - Deletes a disk by its ID.


nebius compute filesystem edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius compute filesystem edit-by-name
	 - Edit resource via external text editor. Uses get-by-name command to receive the current state.


nebius compute filesystem get
	 - Retrieves information about a filesystem by its ID.


nebius compute filesystem get-by-name
	 - Retrieves information about a filesystem by its parent and name.


nebius compute filesystem list
	 - Lists all filesystems within a specified parent.


nebius compute filesystem list-operations-by-parent
	 - Lists all operations that were performed within a specific parent resource.


nebius compute filesystem operation
	 - Manage operations for Filesystem service.


nebius compute filesystem update
	 - Updates an existing filesystem with new configuration parameters.

For details, see https://docs.nebius.com/compute[[../../s]]torage/manage#parameters.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/compute]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/delete]]
- [[cli/reference/compute/disk/edit]]
- [[cli/reference/compute/disk/edit-by-name]]
- [[cli/reference/compute/disk/get]]
- [[cli/reference/compute/disk/get-by-name]]
- [[cli/reference/compute/disk/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/delete]]
- [[cli/reference/compute/filesystem/edit]]
- [[cli/reference/compute/filesystem/edit-by-name]]
- [[cli/reference/compute/filesystem/get]]
- [[cli/reference/compute/filesystem/get-by-name]]
- [[cli/reference/compute/filesystem/list]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/edit]]
- [[cli/reference/compute/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/list]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/image]]
- [[cli/reference/compute/image/get]]
- [[cli/reference/compute/image/get-by-name]]
- [[cli/reference/compute/image/get-latest-by-family]]
- [[cli/reference/compute/image/list]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/platform]]
- [[cli/reference/compute/platform/get-by-name]]
- [[cli/reference/compute/platform/list]]
- [[cli/reference/compute/v1alpha1]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/disk/delete]]
- [[cli/reference/compute/v1alpha1/disk/edit]]
- [[cli/reference/compute/v1alpha1/disk/edit-by-name]]
- [[cli/reference/compute/v1alpha1/disk/get]]
- [[cli/reference/compute/v1alpha1/disk/get-by-name]]
- [[cli/reference/compute/v1alpha1/disk/list]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/compute/v1alpha1/filesystem/delete]]
- [[cli/reference/compute/v1alpha1/filesystem/edit]]
- [[cli/reference/compute/v1alpha1/filesystem/edit-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/get]]
- [[cli/reference/compute/v1alpha1/filesystem/get-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/list]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/create]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/delete]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/image]]
- [[cli/reference/compute/v1alpha1/image/get]]
- [[cli/reference/compute/v1alpha1/image/get-by-name]]
- [[cli/reference/compute/v1alpha1/image/get-latest-by-family]]
- [[cli/reference/compute/v1alpha1/image/list]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/release-notes]]
- [[compute/clusters/slurm]]
- [[compute/monitoring/volumes]]
- [[compute/quickstart]]
- [[compute/resources/pricing]]
- [[compute/storage/detach-volume]]
- [[compute/storage/manage]]
- [[compute/storage/types]]
- [[compute/storage/use]]
- [[compute/virtual-machines/manage]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/specific-terms/compute]]
- [[overview/data-deletion]]
- [[signup-billing/billing-models/committed-usage]]
- [[slurm-soperator/clusters/connect]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/jobs/containers/pyxis-enroot]]
- [[slurm-soperator/overview/architecture]]
- [[slurm-soperator/overview/why-slurm-soperator]]
- [[slurm-soperator/storage/download-data]]
- [[terraform-provider/reference/data-sources/compute_v1_filesystem]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/compute_v1_filesystem]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]