Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
image
instance
node
platform
v1alpha1
disk
filesystem
gpu-cluster
image
get
get-by-name
get-latest-by-family
list
list-operations-by-parent
instance
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
v1alpha1
image
nebius compute v1alpha1 image
Deprecated
Usage
Flags
Subcommands
Deprecated
Deprecated


Command 'image' is deprecated.


Usage
Usage




nebius compute v1alpha1 image [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius compute v1alpha1 image get


nebius compute v1alpha1 image get-by-name


nebius compute v1alpha1 image get-latest-by-family


nebius compute v1alpha1 image list


nebius compute v1alpha1 image list-operations-by-parent




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
get
In this article:
Deprecated
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/compute]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/delete]]
- [[cli/reference/compute/disk/edit]]
- [[cli/reference/compute/disk/edit-by-name]]
- [[cli/reference/compute/disk/get]]
- [[cli/reference/compute/disk/get-by-name]]
- [[cli/reference/compute/disk/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/delete]]
- [[cli/reference/compute/filesystem/edit]]
- [[cli/reference/compute/filesystem/edit-by-name]]
- [[cli/reference/compute/filesystem/get]]
- [[cli/reference/compute/filesystem/get-by-name]]
- [[cli/reference/compute/filesystem/list]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/edit]]
- [[cli/reference/compute/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/list]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/image]]
- [[cli/reference/compute/image/get]]
- [[cli/reference/compute/image/get-by-name]]
- [[cli/reference/compute/image/get-latest-by-family]]
- [[cli/reference/compute/image/list]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/platform]]
- [[cli/reference/compute/platform/get-by-name]]
- [[cli/reference/compute/platform/list]]
- [[cli/reference/compute/v1alpha1]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/disk/delete]]
- [[cli/reference/compute/v1alpha1/disk/edit]]
- [[cli/reference/compute/v1alpha1/disk/edit-by-name]]
- [[cli/reference/compute/v1alpha1/disk/get]]
- [[cli/reference/compute/v1alpha1/disk/get-by-name]]
- [[cli/reference/compute/v1alpha1/disk/list]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/compute/v1alpha1/filesystem/delete]]
- [[cli/reference/compute/v1alpha1/filesystem/edit]]
- [[cli/reference/compute/v1alpha1/filesystem/edit-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/get]]
- [[cli/reference/compute/v1alpha1/filesystem/get-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/list]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/create]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/delete]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/image/get]]
- [[cli/reference/compute/v1alpha1/image/get-by-name]]
- [[cli/reference/compute/v1alpha1/image/get-latest-by-family]]
- [[cli/reference/compute/v1alpha1/image/list]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/registry]]
- [[cli/reference/registry/configure-helper]]
- [[cli/reference/registry/create]]
- [[cli/reference/registry/create-helper]]
- [[cli/reference/registry/delete]]
- [[cli/reference/registry/docker-credential]]
- [[cli/reference/registry/docker-credential/get]]
- [[cli/reference/registry/edit]]
- [[cli/reference/registry/get]]
- [[cli/reference/registry/image]]
- [[cli/reference/registry/image/delete]]
- [[cli/reference/registry/image/get]]
- [[cli/reference/registry/image/list]]
- [[cli/reference/registry/image/operation]]
- [[cli/reference/registry/image/operation/get]]
- [[cli/reference/registry/image/operation/list]]
- [[cli/reference/registry/image/operation/wait]]
- [[cli/reference/registry/list]]
- [[cli/reference/registry/operation]]
- [[cli/reference/registry/operation/get]]
- [[cli/reference/registry/operation/list]]
- [[cli/reference/registry/operation/wait]]
- [[cli/reference/registry/update]]
- [[compute/clusters/gpu]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/storage/boot-disk-images]]
- [[compute/storage/manage]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/types]]
- [[compute/virtual-machines/wireguard]]
- [[container-registry]]
- [[container-registry/quickstart]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/networking/nodelocal-dns-cache]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/workloads/images-container-registry]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/archive/specific-terms/container-registry-20240925]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/studio/archive/terms-of-use-20250120]]
- [[legal/studio/archive/terms-of-use-20250304]]
- [[legal/studio/terms-of-use]]
- [[slurm-soperator/jobs/containers]]
- [[slurm-soperator/jobs/containers/apptainer]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/jobs/containers/pyxis-enroot]]
- [[studio/api/examples]]
- [[studio/inference]]
- [[studio/inference/integrations]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/huggingface]]
- [[studio/inference/integrations/llamaindex]]
- [[studio/inference/integrations/llamaindex/vision]]
- [[studio/inference/integrations/postman]]
- [[studio/inference/models]]
- [[studio/inference/models/embedding]]
- [[studio/inference/models/safety-guardrails]]
- [[studio/inference/models/text-to-image]]
- [[studio/inference/models/text-to-text]]
- [[studio/inference/models/vision]]
- [[studio/inference/rate-limits]]