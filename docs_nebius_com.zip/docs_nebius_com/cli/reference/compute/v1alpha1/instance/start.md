Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
disk
filesystem
gpu-cluster
image
instance
node
platform
v1alpha1
disk
filesystem
gpu-cluster
image
instance
create
delete
edit
edit-by-name
get
get-by-name
list
list-operations-by-parent
operation
start
stop
update
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
compute
v1alpha1
instance
start
nebius compute v1alpha1 instance start
Deprecated
Usage
Flags
Global flags
Deprecated
Deprecated


Command 'instance' is deprecated.


Usage
Usage




nebius compute v1alpha1 instance start [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --id <value> (string)
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
stop
In this article:
Deprecated
Usage
Flags
Global flags

---

**Related:**

- [[applications/standalone/jupyterlab/deploy]]
- [[applications/standalone/stop-start]]
- [[audit-logs/events/view]]
- [[audit-logs/use-cases]]
- [[cli/reference/audit/v2/audit-event/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/reference/msp/serverless]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/delete]]
- [[cli/reference/msp/serverless/get]]
- [[cli/reference/msp/serverless/list]]
- [[cli/reference/msp/serverless/logs]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/start]]
- [[cli/reference/msp/serverless/stop]]
- [[cli/reference/msp/serverless/v1alpha1]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/delete]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get-by-name]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/stop]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/cancel]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/delete]]
- [[cli/reference/msp/serverless/v1alpha1/job/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/quotas/quota-allowance/list]]
- [[cli/release-notes]]
- [[compute/clusters/skypilot]]
- [[compute/clusters/slurm]]
- [[compute/quickstart]]
- [[compute/quickstart-host-model]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/maintenance]]
- [[compute/virtual-machines/manage]]
- [[compute/virtual-machines/stop-start]]
- [[iam/authorization/groups]]
- [[iam/authorization/groups/members]]
- [[iam/service-accounts/access-keys]]
- [[iam/service-accounts/authorized-keys]]
- [[iam/service-accounts/manage]]
- [[kubernetes/clusters/load-balancer]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/storage/disk-over-csi]]
- [[legal/agreement]]
- [[legal/archive/agreement-20240917]]
- [[object-storage/quickstart]]
- [[observability/metrics/ingest]]
- [[observability/metrics/prometheus]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[signup-billing/payments/card]]
- [[slurm-soperator]]
- [[slurm-soperator/jobs/containers/docker]]
- [[slurm-soperator/jobs/containers/pyxis-enroot]]
- [[slurm-soperator/storage/download-data]]
- [[studio/billing]]
- [[studio/fine-tuning/host-model]]
- [[studio/fine-tuning/how-to-fine-tune]]
- [[studio/inference/integrations/continue]]
- [[studio/inference/models]]
- [[studio/inference/playground]]
- [[terraform-provider/reference/data-sources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]