Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
cluster
node-group
v1alpha1
cluster
node-group
create
delete
edit
edit-by-name
get
get-by-name
list
operation
update
upgrade
msp
profile
quotas
registry
storage
update
version
vpc
Reference
mk8s
v1alpha1
node-group
nebius mk8s v1alpha1 node-group
Usage
Flags
Subcommands
Usage
Usage




nebius mk8s v1alpha1 node-group [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius mk8s v1alpha1 node-group create


nebius mk8s v1alpha1 node-group delete


nebius mk8s v1alpha1 node-group edit
	 - Edit resource via external text editor. Uses get command to receive the current state.


nebius mk8s v1alpha1 node-group edit-by-name
	 - Edit resource via external text editor. Uses get-by-name command to receive the current state.


nebius mk8s v1alpha1 node-group get


nebius mk8s v1alpha1 node-group get-by-name


nebius mk8s v1alpha1 node-group list


nebius mk8s v1alpha1 node-group operation
	 - Manage operations for NodeGroup service.


nebius mk8s v1alpha1 node-group update


nebius mk8s v1alpha1 node-group upgrade




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
create
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[applications]]
- [[applications/kubernetes]]
- [[applications/types]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[compute/clusters/mpirun]]
- [[kubernetes/components]]
- [[kubernetes/gpu/clusters]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/gpu/set-up]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/manage-applications]]
- [[kubernetes/monitoring]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/node-groups/autoscaling]]
- [[kubernetes/node-groups/manage]]
- [[kubernetes/node-groups/moving-workload]]
- [[kubernetes/quickstart]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]
- [[kubernetes/versions]]
- [[kubernetes/workloads/images-container-registry]]
- [[terraform-provider/reference/data-sources/mk8s_v1_node_group]]
- [[terraform-provider/reference/data-sources/mk8s_v1alpha1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1_node_group]]
- [[terraform-provider/reference/resources/mk8s_v1alpha1_node_group]]