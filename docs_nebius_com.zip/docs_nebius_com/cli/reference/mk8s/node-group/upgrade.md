Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
cluster
node-group
create
delete
edit
edit-by-name
get
get-by-name
list
operation
update
upgrade
v1alpha1
msp
profile
quotas
registry
storage
update
version
vpc
Reference
mk8s
node-group
upgrade
nebius mk8s node-group upgrade
Usage
Flags
Global flags
Usage
Usage




nebius mk8s node-group upgrade [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --latest-infra-version [=<true|false>] (bool) Upgrades to the latest infra version, which includes latest supported kubernetes patch version. Kubernetes minor version remain the same.
  --id <value> (string) [required]
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
update
Next
v1alpha1
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/mk8s/node-group]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/delete]]
- [[cli/reference/mk8s/node-group/edit]]
- [[cli/reference/mk8s/node-group/edit-by-name]]
- [[cli/reference/mk8s/node-group/get]]
- [[cli/reference/mk8s/node-group/get-by-name]]
- [[cli/reference/mk8s/node-group/list]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/node-group/operation/get]]
- [[cli/reference/mk8s/node-group/operation/list]]
- [[cli/reference/mk8s/node-group/operation/wait]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/v1alpha1]]
- [[cli/reference/mk8s/v1alpha1/node-group]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/delete]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/upgrade]]
- [[cli/reference/msp]]
- [[kubernetes/integrations/run-ai]]
- [[kubernetes/networking/add-ons]]
- [[kubernetes/storage/disk-over-csi]]
- [[kubernetes/storage/filesystem-over-csi]]