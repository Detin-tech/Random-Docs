Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
v2
audit-event
list
compute
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
audit
v2
audit-event
nebius audit v2 audit-event
Usage
Flags
Subcommands
Usage
Usage




nebius audit v2 audit-event [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius audit v2 audit-event list




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
v2
Next
list
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[audit-logs/events/view]]