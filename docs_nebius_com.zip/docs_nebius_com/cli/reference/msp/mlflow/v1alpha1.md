Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
msp
mlflow
v1alpha1
cluster
postgresql
serverless
spark
v1alpha1
profile
quotas
registry
storage
update
version
vpc
Reference
msp
mlflow
v1alpha1
nebius msp mlflow v1alpha1
Usage
Flags
Subcommands
Usage
Usage




nebius msp mlflow v1alpha1 [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius msp mlflow v1alpha1 cluster




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
mlflow
Next
cluster
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/applications]]
- [[cli/reference/applications/v1alpha1]]
- [[cli/reference/applications/v1alpha1/k-8-s-release]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/create]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/delete]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/get]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/list]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/get]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/list]]
- [[cli/reference/applications/v1alpha1/k-8-s-release/operation/wait]]
- [[cli/reference/compute]]
- [[cli/reference/compute/disk]]
- [[cli/reference/compute/disk/create]]
- [[cli/reference/compute/disk/delete]]
- [[cli/reference/compute/disk/edit]]
- [[cli/reference/compute/disk/edit-by-name]]
- [[cli/reference/compute/disk/get]]
- [[cli/reference/compute/disk/get-by-name]]
- [[cli/reference/compute/disk/list]]
- [[cli/reference/compute/disk/list-operations-by-parent]]
- [[cli/reference/compute/disk/operation]]
- [[cli/reference/compute/disk/operation/get]]
- [[cli/reference/compute/disk/operation/list]]
- [[cli/reference/compute/disk/operation/wait]]
- [[cli/reference/compute/disk/update]]
- [[cli/reference/compute/filesystem]]
- [[cli/reference/compute/filesystem/create]]
- [[cli/reference/compute/filesystem/delete]]
- [[cli/reference/compute/filesystem/edit]]
- [[cli/reference/compute/filesystem/edit-by-name]]
- [[cli/reference/compute/filesystem/get]]
- [[cli/reference/compute/filesystem/get-by-name]]
- [[cli/reference/compute/filesystem/list]]
- [[cli/reference/compute/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/filesystem/operation]]
- [[cli/reference/compute/filesystem/operation/get]]
- [[cli/reference/compute/filesystem/operation/list]]
- [[cli/reference/compute/filesystem/operation/wait]]
- [[cli/reference/compute/filesystem/update]]
- [[cli/reference/compute/gpu-cluster]]
- [[cli/reference/compute/gpu-cluster/create]]
- [[cli/reference/compute/gpu-cluster/delete]]
- [[cli/reference/compute/gpu-cluster/edit]]
- [[cli/reference/compute/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/gpu-cluster/get]]
- [[cli/reference/compute/gpu-cluster/get-by-name]]
- [[cli/reference/compute/gpu-cluster/list]]
- [[cli/reference/compute/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/gpu-cluster/operation]]
- [[cli/reference/compute/gpu-cluster/operation/get]]
- [[cli/reference/compute/gpu-cluster/operation/list]]
- [[cli/reference/compute/gpu-cluster/operation/wait]]
- [[cli/reference/compute/gpu-cluster/update]]
- [[cli/reference/compute/image]]
- [[cli/reference/compute/image/get]]
- [[cli/reference/compute/image/get-by-name]]
- [[cli/reference/compute/image/get-latest-by-family]]
- [[cli/reference/compute/image/list]]
- [[cli/reference/compute/image/list-operations-by-parent]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/platform]]
- [[cli/reference/compute/platform/get-by-name]]
- [[cli/reference/compute/platform/list]]
- [[cli/reference/compute/v1alpha1]]
- [[cli/reference/compute/v1alpha1/disk]]
- [[cli/reference/compute/v1alpha1/disk/create]]
- [[cli/reference/compute/v1alpha1/disk/delete]]
- [[cli/reference/compute/v1alpha1/disk/edit]]
- [[cli/reference/compute/v1alpha1/disk/edit-by-name]]
- [[cli/reference/compute/v1alpha1/disk/get]]
- [[cli/reference/compute/v1alpha1/disk/get-by-name]]
- [[cli/reference/compute/v1alpha1/disk/list]]
- [[cli/reference/compute/v1alpha1/disk/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/disk/operation]]
- [[cli/reference/compute/v1alpha1/disk/operation/get]]
- [[cli/reference/compute/v1alpha1/disk/operation/list]]
- [[cli/reference/compute/v1alpha1/disk/operation/wait]]
- [[cli/reference/compute/v1alpha1/disk/update]]
- [[cli/reference/compute/v1alpha1/filesystem]]
- [[cli/reference/compute/v1alpha1/filesystem/create]]
- [[cli/reference/compute/v1alpha1/filesystem/delete]]
- [[cli/reference/compute/v1alpha1/filesystem/edit]]
- [[cli/reference/compute/v1alpha1/filesystem/edit-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/get]]
- [[cli/reference/compute/v1alpha1/filesystem/get-by-name]]
- [[cli/reference/compute/v1alpha1/filesystem/list]]
- [[cli/reference/compute/v1alpha1/filesystem/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/filesystem/operation]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/get]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/list]]
- [[cli/reference/compute/v1alpha1/filesystem/operation/wait]]
- [[cli/reference/compute/v1alpha1/filesystem/update]]
- [[cli/reference/compute/v1alpha1/gpu-cluster]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/create]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/delete]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/edit-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/get-by-name]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/get]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/list]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/operation/wait]]
- [[cli/reference/compute/v1alpha1/gpu-cluster/update]]
- [[cli/reference/compute/v1alpha1/image]]
- [[cli/reference/compute/v1alpha1/image/get]]
- [[cli/reference/compute/v1alpha1/image/get-by-name]]
- [[cli/reference/compute/v1alpha1/image/get-latest-by-family]]
- [[cli/reference/compute/v1alpha1/image/list]]
- [[cli/reference/compute/v1alpha1/image/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/mk8s]]
- [[cli/reference/mk8s/cluster]]
- [[cli/reference/mk8s/cluster/create]]
- [[cli/reference/mk8s/cluster/delete]]
- [[cli/reference/mk8s/cluster/edit]]
- [[cli/reference/mk8s/cluster/edit-by-name]]
- [[cli/reference/mk8s/cluster/get]]
- [[cli/reference/mk8s/cluster/get-by-name]]
- [[cli/reference/mk8s/cluster/get-credentials]]
- [[cli/reference/mk8s/cluster/get-token]]
- [[cli/reference/mk8s/cluster/list]]
- [[cli/reference/mk8s/cluster/operation]]
- [[cli/reference/mk8s/cluster/operation/get]]
- [[cli/reference/mk8s/cluster/operation/list]]
- [[cli/reference/mk8s/cluster/operation/wait]]
- [[cli/reference/mk8s/cluster/update]]
- [[cli/reference/mk8s/node-group]]
- [[cli/reference/mk8s/node-group/create]]
- [[cli/reference/mk8s/node-group/delete]]
- [[cli/reference/mk8s/node-group/edit]]
- [[cli/reference/mk8s/node-group/edit-by-name]]
- [[cli/reference/mk8s/node-group/get]]
- [[cli/reference/mk8s/node-group/get-by-name]]
- [[cli/reference/mk8s/node-group/list]]
- [[cli/reference/mk8s/node-group/operation]]
- [[cli/reference/mk8s/node-group/operation/get]]
- [[cli/reference/mk8s/node-group/operation/list]]
- [[cli/reference/mk8s/node-group/operation/wait]]
- [[cli/reference/mk8s/node-group/update]]
- [[cli/reference/mk8s/node-group/upgrade]]
- [[cli/reference/mk8s/v1alpha1]]
- [[cli/reference/mk8s/v1alpha1/cluster]]
- [[cli/reference/mk8s/v1alpha1/cluster/create]]
- [[cli/reference/mk8s/v1alpha1/cluster/delete]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit]]
- [[cli/reference/mk8s/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-credentials]]
- [[cli/reference/mk8s/v1alpha1/cluster/get-token]]
- [[cli/reference/mk8s/v1alpha1/cluster/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/get]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/list]]
- [[cli/reference/mk8s/v1alpha1/cluster/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/cluster/update]]
- [[cli/reference/mk8s/v1alpha1/node-group]]
- [[cli/reference/mk8s/v1alpha1/node-group/create]]
- [[cli/reference/mk8s/v1alpha1/node-group/delete]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit]]
- [[cli/reference/mk8s/v1alpha1/node-group/edit-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/get-by-name]]
- [[cli/reference/mk8s/v1alpha1/node-group/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/get]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/list]]
- [[cli/reference/mk8s/v1alpha1/node-group/operation/wait]]
- [[cli/reference/mk8s/v1alpha1/node-group/update]]
- [[cli/reference/mk8s/v1alpha1/node-group/upgrade]]
- [[cli/reference/msp]]
- [[cli/reference/msp/mlflow]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/create]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/delete]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql]]
- [[cli/reference/msp/postgresql/v1alpha1]]
- [[cli/reference/msp/postgresql/v1alpha1/backup]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/get]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list-by-cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/reference/msp/serverless]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/delete]]
- [[cli/reference/msp/serverless/get]]
- [[cli/reference/msp/serverless/list]]
- [[cli/reference/msp/serverless/logs]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/start]]
- [[cli/reference/msp/serverless/stop]]
- [[cli/reference/msp/serverless/v1alpha1]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/delete]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get-by-name]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/stop]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/cancel]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/delete]]
- [[cli/reference/msp/serverless/v1alpha1/job/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark]]
- [[cli/reference/msp/spark/v1alpha1]]
- [[cli/reference/msp/spark/v1alpha1/cluster]]
- [[cli/reference/msp/spark/v1alpha1/cluster/create]]
- [[cli/reference/msp/spark/v1alpha1/cluster/delete]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/cluster/update]]
- [[cli/reference/msp/spark/v1alpha1/job]]
- [[cli/reference/msp/spark/v1alpha1/job/cancel]]
- [[cli/reference/msp/spark/v1alpha1/job/create]]
- [[cli/reference/msp/spark/v1alpha1/job/get]]
- [[cli/reference/msp/spark/v1alpha1/job/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/session]]
- [[cli/reference/msp/spark/v1alpha1/session/create]]
- [[cli/reference/msp/spark/v1alpha1/session/delete]]
- [[cli/reference/msp/spark/v1alpha1/session/get]]
- [[cli/reference/msp/spark/v1alpha1/session/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/session/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/wait]]
- [[cli/reference/msp/v1alpha1]]
- [[cli/reference/msp/v1alpha1/resource]]
- [[cli/reference/msp/v1alpha1/resource/preset]]
- [[cli/reference/msp/v1alpha1/resource/preset/list]]
- [[cli/reference/msp/v1alpha1/resource/template]]
- [[cli/reference/msp/v1alpha1/resource/template/list]]
- [[cli/reference/storage]]
- [[cli/reference/storage/bucket]]
- [[cli/reference/storage/bucket/create]]
- [[cli/reference/storage/bucket/delete]]
- [[cli/reference/storage/bucket/edit]]
- [[cli/reference/storage/bucket/edit-by-name]]
- [[cli/reference/storage/bucket/get]]
- [[cli/reference/storage/bucket/get-by-name]]
- [[cli/reference/storage/bucket/list]]
- [[cli/reference/storage/bucket/operation]]
- [[cli/reference/storage/bucket/operation/get]]
- [[cli/reference/storage/bucket/operation/list]]
- [[cli/reference/storage/bucket/operation/wait]]
- [[cli/reference/storage/bucket/purge]]
- [[cli/reference/storage/bucket/undelete]]
- [[cli/reference/storage/bucket/update]]
- [[cli/reference/storage/v1alpha1]]
- [[cli/reference/storage/v1alpha1/transfer]]
- [[cli/reference/storage/v1alpha1/transfer/create]]
- [[cli/reference/storage/v1alpha1/transfer/delete]]
- [[cli/reference/storage/v1alpha1/transfer/edit]]
- [[cli/reference/storage/v1alpha1/transfer/edit-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get]]
- [[cli/reference/storage/v1alpha1/transfer/get-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get-iteration-history]]
- [[cli/reference/storage/v1alpha1/transfer/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation]]
- [[cli/reference/storage/v1alpha1/transfer/operation/get]]
- [[cli/reference/storage/v1alpha1/transfer/operation/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation/wait]]
- [[cli/reference/storage/v1alpha1/transfer/resume]]
- [[cli/reference/storage/v1alpha1/transfer/stop]]
- [[cli/reference/storage/v1alpha1/transfer/update]]
- [[cli/reference/vpc]]
- [[cli/reference/vpc/allocation]]
- [[cli/reference/vpc/allocation/create]]
- [[cli/reference/vpc/allocation/delete]]
- [[cli/reference/vpc/allocation/edit]]
- [[cli/reference/vpc/allocation/edit-by-name]]
- [[cli/reference/vpc/allocation/get]]
- [[cli/reference/vpc/allocation/get-by-name]]
- [[cli/reference/vpc/allocation/list]]
- [[cli/reference/vpc/allocation/list-by-pool]]
- [[cli/reference/vpc/allocation/operation]]
- [[cli/reference/vpc/allocation/operation/get]]
- [[cli/reference/vpc/allocation/operation/list]]
- [[cli/reference/vpc/allocation/operation/wait]]
- [[cli/reference/vpc/allocation/update]]
- [[cli/reference/vpc/network]]
- [[cli/reference/vpc/network/create]]
- [[cli/reference/vpc/network/create-default]]
- [[cli/reference/vpc/network/delete]]
- [[cli/reference/vpc/network/edit]]
- [[cli/reference/vpc/network/edit-by-name]]
- [[cli/reference/vpc/network/get]]
- [[cli/reference/vpc/network/get-by-name]]
- [[cli/reference/vpc/network/list]]
- [[cli/reference/vpc/network/operation]]
- [[cli/reference/vpc/network/operation/get]]
- [[cli/reference/vpc/network/operation/list]]
- [[cli/reference/vpc/network/operation/wait]]
- [[cli/reference/vpc/network/update]]
- [[cli/reference/vpc/pool]]
- [[cli/reference/vpc/pool/create]]
- [[cli/reference/vpc/pool/delete]]
- [[cli/reference/vpc/pool/edit]]
- [[cli/reference/vpc/pool/edit-by-name]]
- [[cli/reference/vpc/pool/get]]
- [[cli/reference/vpc/pool/get-by-name]]
- [[cli/reference/vpc/pool/list]]
- [[cli/reference/vpc/pool/list-by-source-pool]]
- [[cli/reference/vpc/pool/operation]]
- [[cli/reference/vpc/pool/operation/get]]
- [[cli/reference/vpc/pool/operation/list]]
- [[cli/reference/vpc/pool/operation/wait]]
- [[cli/reference/vpc/pool/update]]
- [[cli/reference/vpc/subnet]]
- [[cli/reference/vpc/subnet/create]]
- [[cli/reference/vpc/subnet/delete]]
- [[cli/reference/vpc/subnet/edit]]
- [[cli/reference/vpc/subnet/edit-by-name]]
- [[cli/reference/vpc/subnet/get]]
- [[cli/reference/vpc/subnet/get-by-name]]
- [[cli/reference/vpc/subnet/list]]
- [[cli/reference/vpc/subnet/list-by-network]]
- [[cli/reference/vpc/subnet/operation]]
- [[cli/reference/vpc/subnet/operation/get]]
- [[cli/reference/vpc/subnet/operation/list]]
- [[cli/reference/vpc/subnet/operation/wait]]
- [[cli/reference/vpc/subnet/update]]
- [[cli/reference/vpc/v1alpha1]]
- [[cli/reference/vpc/v1alpha1/allocation]]
- [[cli/reference/vpc/v1alpha1/allocation/create]]
- [[cli/reference/vpc/v1alpha1/allocation/delete]]
- [[cli/reference/vpc/v1alpha1/allocation/edit]]
- [[cli/reference/vpc/v1alpha1/allocation/edit-by-name]]
- [[cli/reference/vpc/v1alpha1/allocation/get]]
- [[cli/reference/vpc/v1alpha1/allocation/get-by-name]]
- [[cli/reference/vpc/v1alpha1/allocation/list]]
- [[cli/reference/vpc/v1alpha1/allocation/operation]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/get]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/list]]
- [[cli/reference/vpc/v1alpha1/allocation/operation/wait]]
- [[cli/reference/vpc/v1alpha1/allocation/update]]
- [[cli/reference/vpc/v1alpha1/network]]
- [[cli/reference/vpc/v1alpha1/network/get]]
- [[cli/reference/vpc/v1alpha1/network/get-by-name]]
- [[cli/reference/vpc/v1alpha1/network/list]]
- [[cli/reference/vpc/v1alpha1/pool]]
- [[cli/reference/vpc/v1alpha1/pool/get]]
- [[cli/reference/vpc/v1alpha1/pool/get-by-name]]
- [[cli/reference/vpc/v1alpha1/pool/list]]
- [[cli/reference/vpc/v1alpha1/scope]]
- [[cli/reference/vpc/v1alpha1/scope/get]]
- [[cli/reference/vpc/v1alpha1/scope/get-by-name]]
- [[cli/reference/vpc/v1alpha1/scope/list]]
- [[cli/reference/vpc/v1alpha1/subnet]]
- [[cli/reference/vpc/v1alpha1/subnet/get]]
- [[cli/reference/vpc/v1alpha1/subnet/get-by-name]]
- [[cli/reference/vpc/v1alpha1/subnet/list]]
- [[cli/reference/vpc/v1alpha1/subnet/list-by-network]]
- [[cli/release-notes]]
- [[kubernetes/integrations/run-ai]]
- [[mlflow/clusters/manage]]
- [[mlflow/quickstart]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/users]]
- [[postgresql/quickstart]]
- [[spark/clusters/manage]]
- [[spark/jobs/run]]
- [[spark/quickstart]]
- [[spark/sessions/manage]]
- [[terraform-provider/reference/data-sources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]