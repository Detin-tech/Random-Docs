Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
msp
mlflow
postgresql
v1alpha1
serverless
spark
v1alpha1
profile
quotas
registry
storage
update
version
vpc
Reference
msp
postgresql
nebius msp postgresql
Usage
Flags
Subcommands
Usage
Usage




nebius msp postgresql [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius msp postgresql v1alpha1




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
v1alpha1
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[audit-logs/events/reference]]
- [[audit-logs/services]]
- [[cli/reference/msp]]
- [[cli/reference/msp/mlflow]]
- [[cli/reference/msp/mlflow/v1alpha1]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/create]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/delete]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/mlflow/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1]]
- [[cli/reference/msp/postgresql/v1alpha1/backup]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/get]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list-by-cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/reference/msp/serverless]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/delete]]
- [[cli/reference/msp/serverless/get]]
- [[cli/reference/msp/serverless/list]]
- [[cli/reference/msp/serverless/logs]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/start]]
- [[cli/reference/msp/serverless/stop]]
- [[cli/reference/msp/serverless/v1alpha1]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/delete]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get-by-name]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/stop]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/cancel]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/delete]]
- [[cli/reference/msp/serverless/v1alpha1/job/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark]]
- [[cli/reference/msp/spark/v1alpha1]]
- [[cli/reference/msp/spark/v1alpha1/cluster]]
- [[cli/reference/msp/spark/v1alpha1/cluster/create]]
- [[cli/reference/msp/spark/v1alpha1/cluster/delete]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit]]
- [[cli/reference/msp/spark/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/cluster/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/cluster/update]]
- [[cli/reference/msp/spark/v1alpha1/job]]
- [[cli/reference/msp/spark/v1alpha1/job/cancel]]
- [[cli/reference/msp/spark/v1alpha1/job/create]]
- [[cli/reference/msp/spark/v1alpha1/job/get]]
- [[cli/reference/msp/spark/v1alpha1/job/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/job/operation/wait]]
- [[cli/reference/msp/spark/v1alpha1/session]]
- [[cli/reference/msp/spark/v1alpha1/session/create]]
- [[cli/reference/msp/spark/v1alpha1/session/delete]]
- [[cli/reference/msp/spark/v1alpha1/session/get]]
- [[cli/reference/msp/spark/v1alpha1/session/get-by-name]]
- [[cli/reference/msp/spark/v1alpha1/session/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/get]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/list]]
- [[cli/reference/msp/spark/v1alpha1/session/operation/wait]]
- [[cli/reference/msp/v1alpha1]]
- [[cli/reference/msp/v1alpha1/resource]]
- [[cli/reference/msp/v1alpha1/resource/preset]]
- [[cli/reference/msp/v1alpha1/resource/preset/list]]
- [[cli/reference/msp/v1alpha1/resource/template]]
- [[cli/reference/msp/v1alpha1/resource/template/list]]
- [[cli/release-notes]]
- [[index]]
- [[kubernetes/integrations/run-ai]]
- [[legal/archive/sla-levels/index-20250219]]
- [[legal/archive/sla-levels/index-20250304]]
- [[legal/archive/sla-levels/index-20250313]]
- [[legal/archive/specific-terms/index-20240925]]
- [[legal/archive/specific-terms/index-20241023]]
- [[legal/archive/specific-terms/index-20250313]]
- [[legal/archive/specific-terms/index-20250410]]
- [[legal/archive/specific-terms/managed-postgresql-20240925]]
- [[legal/sla-levels]]
- [[legal/sla-levels/applications/standalone]]
- [[legal/sla-levels/compute]]
- [[legal/sla-levels/managed-kubernetes]]
- [[legal/sla-levels/managed-mlflow]]
- [[legal/sla-levels/managed-postgresql]]
- [[legal/sla-levels/storage]]
- [[legal/sla-levels/vpc]]
- [[legal/specific-terms]]
- [[legal/specific-terms/applications]]
- [[legal/specific-terms/applications/standalone]]
- [[legal/specific-terms/audit-logs]]
- [[legal/specific-terms/compute]]
- [[legal/specific-terms/container-registry]]
- [[legal/specific-terms/iam]]
- [[legal/specific-terms/logging]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/specific-terms/managed-mlflow]]
- [[legal/specific-terms/managed-postgresql]]
- [[legal/specific-terms/managed-spark]]
- [[legal/specific-terms/monitoring]]
- [[legal/specific-terms/storage]]
- [[legal/specific-terms/vpc]]
- [[observability/logging]]
- [[observability/logs/grafana]]
- [[observability/logs/logcli]]
- [[observability/logs/query-language]]
- [[observability/metrics/prometheus]]
- [[observability/services]]
- [[overview/quotas]]
- [[overview/services]]
- [[postgresql]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]
- [[postgresql/databases/connect]]
- [[postgresql/databases/extensions]]
- [[postgresql/databases/manage]]
- [[postgresql/databases/users]]
- [[postgresql/monitoring]]
- [[postgresql/quickstart]]
- [[postgresql/replication/from-external]]
- [[postgresql/resources/pricing]]
- [[postgresql/resources/quotas-limits]]
- [[signup-billing/billing-models/payg]]
- [[terraform-provider/reference/data-sources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]
- [[vpc/networking/isolation]]
- [[vpc/overview]]