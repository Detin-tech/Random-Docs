Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
msp
mlflow
postgresql
v1alpha1
backup
get
list
list-by-cluster
cluster
serverless
spark
v1alpha1
profile
quotas
registry
storage
update
version
vpc
Reference
msp
postgresql
v1alpha1
backup
nebius msp postgresql v1alpha1 backup
Usage
Flags
Subcommands
A set of methods for managing PostgreSQL Cluster backups.


Usage
Usage




nebius msp postgresql v1alpha1 backup [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius msp postgresql v1alpha1 backup get
	 - Returns the specified PostgreSQL Cluster backup.

To get the list of available PostgreSQL Cluster backups, make a [List] or [ListByCluster] request.


nebius msp postgresql v1alpha1 backup list
	 - Retrieves the list of PostgreSQL Cluster backups by project.


nebius msp postgresql v1alpha1 backup list-by-cluster
	 - Retrieves the list of PostgreSQL Cluster backups by cluster.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
v1alpha1
Next
get
In this article:
Usage
Flags
Subcommands

---

**Related:**

- [[cli/reference/msp/postgresql/v1alpha1]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/get]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list]]
- [[cli/reference/msp/postgresql/v1alpha1/backup/list-by-cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/release-notes]]
- [[kubernetes/integrations/run-ai]]
- [[legal/archive/agreement-20240917]]
- [[legal/archive/terms-of-use-20240828]]
- [[legal/specific-terms/managed-kubernetes]]
- [[legal/terms-of-use]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/monitoring]]
- [[slurm-soperator/users/manage]]
- [[terraform-provider/reference/data-sources/msp_postgresql_v1alpha1_cluster]]
- [[terraform-provider/reference/resources/msp_postgresql_v1alpha1_cluster]]