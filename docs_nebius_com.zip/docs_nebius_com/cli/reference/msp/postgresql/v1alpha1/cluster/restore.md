Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
msp
mlflow
postgresql
v1alpha1
backup
cluster
create
delete
edit
edit-by-name
get
get-by-name
get-for-backup
list
operation
restore
start
stop
update
serverless
spark
v1alpha1
profile
quotas
registry
storage
update
version
vpc
Reference
msp
postgresql
v1alpha1
cluster
restore
nebius msp postgresql v1alpha1 cluster restore
Usage
Flags
Global flags
Creates a new PostgreSQL cluster from a previously created backup.


Usage
Usage




nebius msp postgresql v1alpha1 cluster restore [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  Metadata [required]:
    --id <value> (string)                                      Identifier for the resource, unique for its resource type.
    --parent-id <value> (string) [required]                    Identifier of the parent resource to which the resource belongs.
    --name <value> (string)                                    Human readable name for the resource.
    --resource-version <value> (int64)                         Version of the resource for safe concurrent modifications and consistent reads.
                                                               Positive and monotonically increases on each resource spec change (but *not* on each change of the
                                                               resource's container(s) or status).
                                                               Service allows zero value or current.
    --labels <[key1=value1[,key2=value2...]]> (string->string) Labels associated with the resource.
  Spec [required]:
    Backup:
      --backup-backup-window-start <value> (string) Backup window start in "HH:MM:SS" format (UTC Time).
      --backup-retention-policy <value> (string)    Retention policy to be used for backups and WALs (i.e. '7d').
    Bootstrap [required]:
      --bootstrap-user-name <value> (string) [required] Name of the bootstrap PostgreSQL user.
      --bootstrap-user-password <value> (string)        Password of the bootstrap PostgreSQL user.
      --bootstrap-db-name <value> (string) [required]   Name of the PostgreSQL database. 1-63 characters long.
    Config [required]:
      PoolerConfig:
        --config-pooler-config-pooling-mode <pooling_mode_unspecified|session|transaction> (enum) Mode that the connection pooler is working in.
        --config-pooler-config-max-pool-size <value> (int64)                                      Maximum number of connections in the pool for a single database.
      Template [required]:
        Disk [required]:
          --config-template-disk-type <value> (string) [required]
          --config-template-disk-size-gibibytes <value> (int64) [required]
        Resources [required]:
          --config-template-resources-platform <value> (string) [required]
          --config-template-resources-preset <value> (string) [required]
        --config-template-hosts-count <value> (int64) [required]
      PostgresqlConfig_16:
        --config-postgresql-config-16-autovacuum-work-mem <value> (int64)                  In kilobytes.
        --config-postgresql-config-16-statement-timeout <value> (int64)                    In milliseconds.
        --config-postgresql-config-16-idle-in-transaction-session-timeout <value> (int64)  In milliseconds.
        --config-postgresql-config-16-autovacuum-vacuum-cost-delay <value> (int64)         In milliseconds.
        --config-postgresql-config-16-autovacuum-vacuum-cost-limit <value> (int64)
        --config-postgresql-config-16-autovacuum-naptime <value> (int64)                   In seconds.
        --config-postgresql-config-16-autovacuum-vacuum-scale-factor <value> (float64)
        --config-postgresql-config-16-autovacuum-analyze-scale-factor <value> (float64)
        --config-postgresql-config-16-default-transaction-read-only [=<true|false>] (bool)
        --config-postgresql-config-16-search-path <value> (string)
        --config-postgresql-config-16-max-connections <value> (int64)
        --config-postgresql-config-16-shared-buffers <value> (int64)                       In kilobytes.
      --config-version <value> (string) [required]  Version of PostgreSQL used in the cluster.
                                                    Possible values: `16`.
      --config-public-access [=<true|false>] (bool) Either make cluster public accessible or accessible only via private VPC.
    --description <value> (string)           Description of the PostgreSQL cluster.
    --network-id <value> (string) [required] Network ID in which the cluster is created.
  --backup-id <value> (string) [required]                   ID of the backup to restore from.
  --source-cluster-id <value> (string) [required]           ID of the PostgreSQL cluster to restore from.
  --recovery-time <value> (timestamp: 1970-01-31T02:30:59Z) Timestamp for point in time recovery.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
wait
Next
start
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/stop]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/release-notes]]
- [[iam/authorization/groups]]
- [[legal/archive/sla-20241125]]
- [[legal/dpa]]
- [[legal/sla]]
- [[object-storage/objects/manage]]
- [[overview/data-deletion]]
- [[overview/support]]
- [[postgresql/backups]]
- [[postgresql/clusters/manage]]
- [[postgresql/data-transfers/migrate-data]]