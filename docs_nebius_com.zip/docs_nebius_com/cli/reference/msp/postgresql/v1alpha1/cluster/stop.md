Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
audit
compute
config
iam
mk8s
msp
mlflow
postgresql
v1alpha1
backup
cluster
create
delete
edit
edit-by-name
get
get-by-name
get-for-backup
list
operation
restore
start
stop
update
serverless
spark
v1alpha1
profile
quotas
registry
storage
update
version
vpc
Reference
msp
postgresql
v1alpha1
cluster
stop
nebius msp postgresql v1alpha1 cluster stop
Usage
Flags
Global flags
Suspends the PostgreSQL cluster to save resources.


Usage
Usage




nebius msp postgresql v1alpha1 cluster stop [data] [flags]























Flags
Flags




  --async [=<true|false>] (bool) If set, returns operation id. Otherwise, waits for the operation to complete and returns its resource.
  --id <value> (string) [required] ID of the PostgreSQL Cluster resource to pause.
                                   To get the cluster ID use a [ClusterService.List] request.
























Global flags
Global flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
start
Next
update
In this article:
Usage
Flags
Global flags

---

**Related:**

- [[applications/standalone/manage]]
- [[applications/standalone/stop-start]]
- [[audit-logs/events/view]]
- [[cli/reference/compute/instance]]
- [[cli/reference/compute/instance/create]]
- [[cli/reference/compute/instance/delete]]
- [[cli/reference/compute/instance/edit]]
- [[cli/reference/compute/instance/edit-by-name]]
- [[cli/reference/compute/instance/get]]
- [[cli/reference/compute/instance/get-by-name]]
- [[cli/reference/compute/instance/list]]
- [[cli/reference/compute/instance/list-operations-by-parent]]
- [[cli/reference/compute/instance/operation]]
- [[cli/reference/compute/instance/operation/get]]
- [[cli/reference/compute/instance/operation/list]]
- [[cli/reference/compute/instance/operation/wait]]
- [[cli/reference/compute/instance/start]]
- [[cli/reference/compute/instance/stop]]
- [[cli/reference/compute/instance/update]]
- [[cli/reference/compute/node]]
- [[cli/reference/compute/node/set-unhealthy]]
- [[cli/reference/compute/v1alpha1/instance]]
- [[cli/reference/compute/v1alpha1/instance/create]]
- [[cli/reference/compute/v1alpha1/instance/delete]]
- [[cli/reference/compute/v1alpha1/instance/edit]]
- [[cli/reference/compute/v1alpha1/instance/edit-by-name]]
- [[cli/reference/compute/v1alpha1/instance/get]]
- [[cli/reference/compute/v1alpha1/instance/get-by-name]]
- [[cli/reference/compute/v1alpha1/instance/list]]
- [[cli/reference/compute/v1alpha1/instance/list-operations-by-parent]]
- [[cli/reference/compute/v1alpha1/instance/operation]]
- [[cli/reference/compute/v1alpha1/instance/operation/get]]
- [[cli/reference/compute/v1alpha1/instance/operation/list]]
- [[cli/reference/compute/v1alpha1/instance/operation/wait]]
- [[cli/reference/compute/v1alpha1/instance/start]]
- [[cli/reference/compute/v1alpha1/instance/stop]]
- [[cli/reference/compute/v1alpha1/instance/update]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/create]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/delete]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/edit-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-by-name]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/get-for-backup]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/get]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/list]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/operation/wait]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/restore]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/start]]
- [[cli/reference/msp/postgresql/v1alpha1/cluster/update]]
- [[cli/reference/msp/serverless]]
- [[cli/reference/msp/serverless/create]]
- [[cli/reference/msp/serverless/delete]]
- [[cli/reference/msp/serverless/get]]
- [[cli/reference/msp/serverless/list]]
- [[cli/reference/msp/serverless/logs]]
- [[cli/reference/msp/serverless/run]]
- [[cli/reference/msp/serverless/start]]
- [[cli/reference/msp/serverless/stop]]
- [[cli/reference/msp/serverless/v1alpha1]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/create]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/delete]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/get-by-name]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/operation/wait]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/start]]
- [[cli/reference/msp/serverless/v1alpha1/endpoint/stop]]
- [[cli/reference/msp/serverless/v1alpha1/job]]
- [[cli/reference/msp/serverless/v1alpha1/job/cancel]]
- [[cli/reference/msp/serverless/v1alpha1/job/create]]
- [[cli/reference/msp/serverless/v1alpha1/job/delete]]
- [[cli/reference/msp/serverless/v1alpha1/job/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/get]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/list]]
- [[cli/reference/msp/serverless/v1alpha1/job/operation/wait]]
- [[cli/reference/storage/v1alpha1]]
- [[cli/reference/storage/v1alpha1/transfer]]
- [[cli/reference/storage/v1alpha1/transfer/create]]
- [[cli/reference/storage/v1alpha1/transfer/delete]]
- [[cli/reference/storage/v1alpha1/transfer/edit]]
- [[cli/reference/storage/v1alpha1/transfer/edit-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get]]
- [[cli/reference/storage/v1alpha1/transfer/get-by-name]]
- [[cli/reference/storage/v1alpha1/transfer/get-iteration-history]]
- [[cli/reference/storage/v1alpha1/transfer/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation]]
- [[cli/reference/storage/v1alpha1/transfer/operation/get]]
- [[cli/reference/storage/v1alpha1/transfer/operation/list]]
- [[cli/reference/storage/v1alpha1/transfer/operation/wait]]
- [[cli/reference/storage/v1alpha1/transfer/resume]]
- [[cli/reference/storage/v1alpha1/transfer/stop]]
- [[cli/reference/storage/v1alpha1/transfer/update]]
- [[cli/release-notes]]
- [[compute/clusters/skypilot]]
- [[compute/monitoring/virtual-machines]]
- [[compute/storage/detach-volume]]
- [[compute/virtual-machines/cuda-init-error]]
- [[compute/virtual-machines/maintenance]]
- [[compute/virtual-machines/stop-start]]
- [[iam/authorization/groups]]
- [[kubernetes/gpu/nccl-test]]
- [[kubernetes/storage/disk-over-csi]]
- [[legal/archive/specific-terms/compute-20240925]]
- [[legal/pentest]]
- [[legal/specific-terms/compute]]
- [[overview/subscriptions]]
- [[slurm-soperator/monitoring/statuses]]
- [[spark/quickstart]]
- [[studio/api/examples]]
- [[studio/inference/api]]
- [[studio/inference/batch]]
- [[studio/inference/integrations/helicone]]
- [[studio/inference/integrations/portkey]]
- [[studio/inference/playground]]
- [[studio/inference/quickstart]]
- [[terraform-provider/reference/data-sources/compute_v1_instance]]
- [[terraform-provider/reference/data-sources/compute_v1alpha1_instance]]
- [[terraform-provider/reference/resources/compute_v1_instance]]
- [[terraform-provider/reference/resources/compute_v1alpha1_instance]]