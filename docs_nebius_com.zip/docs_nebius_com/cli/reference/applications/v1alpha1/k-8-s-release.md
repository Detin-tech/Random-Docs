Nebius AI Cloud CLI
Getting started with the CLI
Installing the CLI
Setting up the CLI
Release notes
Reference
applications
v1alpha1
k-8-s-release
create
delete
get
list
operation
audit
compute
config
iam
mk8s
msp
profile
quotas
registry
storage
update
version
vpc
Reference
applications
v1alpha1
k-8-s-release
nebius applications v1alpha1 k-8-s-release
Usage
Flags
Subcommands
Usage
Usage




nebius applications v1alpha1 k-8-s-release [flags]























Flags
Flags




      --color [=<true|false>] (bool)      Enable colored output.
  -c, --config <value> (string)           Provide path to config file.
      --debug [=<true|false>] (bool)      Enable debug logs.
  -f, --file <value> (string)             Input file. For 'update' commands automatically set --full=true.
      --format <value> (string)           Output format. Supported values: json|yaml|table|text.
  -h, --help [=<true|false>] (bool)       Show this message.
      --insecure [=<true|false>] (bool)   Disable transport security.
      --no-browser [=<true|false>] (bool) Do not open browser automatically on auth.
  -p, --profile <value> (string)          Set a profile for interacting with the cloud.























Subcommands
Subcommands




nebius applications v1alpha1 k-8-s-release create


nebius applications v1alpha1 k-8-s-release delete


nebius applications v1alpha1 k-8-s-release get


nebius applications v1alpha1 k-8-s-release list


nebius applications v1alpha1 k-8-s-release operation
	 - Manage operations for K8SRelease service.




Auto generated on 6-Jun-2025
Auto generated on 6-Jun-2025


Previous
v1alpha1
Next
create
In this article:
Usage
Flags
Subcommands